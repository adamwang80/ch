import os
import mercantile
from CanopyHeightEngine import CanopyHeightEngine
from ImageDownloadEngine import ImageDownloadEngine
from utils import overlay_canopy_on_image, side_by_side_canopy_image
from config import OUTPUT_DIR, OVERLAY_IMAGE_DIR, SIDE_BY_SIDE_IMAGE_DIR, GOOGLE_MAPS_IMAGE_DIR, LOCAL_IMAGE_DIR
import os
import shutil
import random

sample_size = 10
folder_path = '/home/azureuser/cloudfiles/code/Users/geospatial/PL_Dec11_2023/chunk66'
file_names = os.listdir(folder_path)

# if LOCAL_IMAGE_DIR does not exist, create it
if not os.path.exists(LOCAL_IMAGE_DIR):
    os.makedirs(LOCAL_IMAGE_DIR, exist_ok=True)


# Randomly pick sample_size files from file_names
file_names = random.sample(file_names, min(sample_size, len(file_names)))

bboxes = []

for file_name in file_names:
    parts = file_name.split('_')

    if len(parts) < 5:
        print(f"Skipping file (unexpected format): {file_name}")
        continue

    tile_numbers = parts[1:5]
    print(f"Processing file: {file_name}")
    
    try:
        tile_pairs = [(int(tile_numbers[i]), int(tile_numbers[i+1])) for i in range(0, len(tile_numbers), 2)]
    except ValueError as e:
        print(f"Error parsing tile numbers in {file_name}: {e}")
        continue

    bounds_list = []
    for x, y in tile_pairs:
        try:
            bounds = mercantile.bounds(mercantile.Tile(x=x, y=y, z=21))
            bounds_list.append(bounds)
        except Exception as e:
            print(f"Error getting bounds for tile ({x}, {y}): {e}")

    if not bounds_list:
        print(f"No valid bounds found for {file_name}, skipping.")
        continue

    north = max(b.north for b in bounds_list)
    south = min(b.south for b in bounds_list)
    west = min(b.west for b in bounds_list)
    east = max(b.east for b in bounds_list)

    print(f"Image bounding box:")
    print(f"  Northwest corner: lat={north}, lon={west}")
    print(f"  Southeast corner: lat={south}, lon={east}")

    bounding_box = [north, west, south, east]
    bboxes.append(bounding_box)
    bbox_filename = '_'.join([str(coord) for coord in bounding_box])

    original_file_path = f"{folder_path}/{file_name}"
    destination_file_path = f"{LOCAL_IMAGE_DIR}/{bbox_filename}.png"
    shutil.copy(original_file_path, destination_file_path)

engine = CanopyHeightEngine()


# image_engine = ImageDownloadEngine()
# image_engine.download_image(bounding_box, overwrite=False)

for bounding_box in bboxes:
    engine.get_canopy_height(bounding_box, method="chm", data_source="local")
    bbox_filename = '_'.join([str(coord) for coord in bounding_box])
    canopy_height_file = f"data/chm/{bbox_filename}_crop.tif"
    satellite_image_file = f"{LOCAL_IMAGE_DIR}/{bbox_filename}.png"

    if not os.path.exists(OVERLAY_IMAGE_DIR):
        os.makedirs(OVERLAY_IMAGE_DIR, exist_ok=True)
    output_file = f"{OVERLAY_IMAGE_DIR}/overlay_{bbox_filename}.png"

    overlay_canopy_on_image(canopy_height_file, satellite_image_file, output_file)

    if not os.path.exists(SIDE_BY_SIDE_IMAGE_DIR):
        os.makedirs(SIDE_BY_SIDE_IMAGE_DIR, exist_ok=True)
    output_file = f"{SIDE_BY_SIDE_IMAGE_DIR}/side_by_side_{bbox_filename}.png"

    side_by_side_canopy_image(canopy_height_file, satellite_image_file, output_file)