#!/usr/bin/env python3
"""
Simple test script to verify the refactored code works correctly.
This script tests the main functionality without requiring actual data or API keys.
"""

import os
import sys
import logging
from typing import List

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config import VisualizationConfig, DataProcessingConfig
from utils import generate_bbox_filename, clean_canopy_data, normalize_canopy_data
import numpy as np

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_config_classes():
    """Test that configuration classes work correctly"""
    logger.info("Testing configuration classes...")
    
    # Test VisualizationConfig
    assert VisualizationConfig.CANOPY_COLOR == [255, 0, 0]
    assert VisualizationConfig.IMAGE_QUALITY == 95
    assert VisualizationConfig.DPI == 300
    assert VisualizationConfig.CANOPY_NODATA_THRESHOLD == 200
    
    # Test DataProcessingConfig
    assert DataProcessingConfig.DEFAULT_NODATA == 255
    assert DataProcessingConfig.DEFAULT_CRS == 'EPSG:4326'
    assert DataProcessingConfig.COMPRESSION == "DEFLATE"
    
    logger.info("✓ Configuration classes working correctly")

def test_utility_functions():
    """Test utility functions"""
    logger.info("Testing utility functions...")
    
    # Test generate_bbox_filename
    bbox = [39.30076705472572, -84.5023961988198, 39.30029432276294, -84.50183394864057]
    filename = generate_bbox_filename(bbox)
    expected = "39.30076705472572_-84.5023961988198_39.30029432276294_-84.50183394864057"
    assert filename == expected
    logger.info(f"✓ Generated filename: {filename}")
    
    # Test clean_canopy_data
    test_data = np.array([[0, 50, 100], [150, 200, 250], [300, -10, 0]])
    cleaned_data = clean_canopy_data(test_data)
    
    # Check that negative values are set to 0
    assert cleaned_data[2, 1] == 0  # -10 should become 0
    
    # Check that values > 200 are set to NaN
    assert np.isnan(cleaned_data[1, 2])  # 250 should become NaN
    assert np.isnan(cleaned_data[2, 0])  # 300 should become NaN
    
    logger.info("✓ Data cleaning working correctly")
    
    # Test normalize_canopy_data
    test_data = np.array([[0, 50, 100], [150, 200, 0]])
    normalized_data = normalize_canopy_data(test_data)
    
    # Check that max value is 255
    assert np.nanmax(normalized_data) == 255
    
    logger.info("✓ Data normalization working correctly")

def test_imports():
    """Test that all modules can be imported correctly"""
    logger.info("Testing imports...")
    
    try:
        from CanopyHeightEngine import CanopyHeightEngine
        logger.info("✓ CanopyHeightEngine imported successfully")
    except Exception as e:
        logger.error(f"✗ Failed to import CanopyHeightEngine: {e}")
        return False
    
    try:
        from ImageDownloadEngine import ImageDownloadEngine
        logger.info("✓ ImageDownloadEngine imported successfully")
    except Exception as e:
        logger.error(f"✗ Failed to import ImageDownloadEngine: {e}")
        return False
    
    try:
        from utils import overlay_canopy_on_image, side_by_side_canopy_image
        logger.info("✓ Utils functions imported successfully")
    except Exception as e:
        logger.error(f"✗ Failed to import utils functions: {e}")
        return False
    
    return True

def main():
    """Run all tests"""
    logger.info("Starting refactored code tests...")
    
    try:
        test_config_classes()
        test_utility_functions()
        
        if test_imports():
            logger.info("✓ All tests passed! Refactored code is working correctly.")
        else:
            logger.error("✗ Some imports failed!")
            return False
            
    except Exception as e:
        logger.error(f"✗ Test failed with error: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 