from config import TILE_DATA_PATH, LOCAL_CHM_DIR, S3_CHM_PATH, S3_MSK_PATH, S3_META_PATH, S3_BUCKET, TARGET_PLOY_FILE_DIR, S3_TILE_DATA_PATH, CANOPY_HEIGHT_IMAGE_DIR, LOCAL_TIF_DIR, LOCAL_MSK_DIR, LOCAL_META_DIR,  VisualizationConfig, DataProcessingConfig, MODEL_WINDOW_SIZE, MODEL_DIR
import geopandas as gp
import matplotlib.pyplot as plt
import os
import shutil
import boto3
from botocore import UNSIGNED
from botocore.config import Config
import json
import numpy as np
import rasterio
from PIL import Image
from shapely.geometry import box
from pyproj import Transformer
from rasterio.merge import merge
import rasterio.mask
from shapely.geometry import GeometryCollection, MultiPolygon, shape, polygon
import logging
from typing import List, Tuple, Optional, Dict, Any
import time
from torch.utils.data import DataLoader
import src.transforms as transforms
import src.raster_utils as raster_utils
from tqdm.notebook import tqdm
from CustomImageDataset import CustomImageDataset
from SSLModule3 import SSLModule3
from rasterio.windows import Window
from rasterio.transform import from_origin
import requests
from dotenv import load_dotenv

load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class CanopyHeightEngine:
    def __init__(self):        
        self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
        
        self._ensure_directories()
        self._initialize_tiles()
    
    def _ensure_directories(self) -> None:
        """Ensure all required directories exist"""
        directories = [
            LOCAL_CHM_DIR,
            TARGET_PLOY_FILE_DIR,
            CANOPY_HEIGHT_IMAGE_DIR,
            os.path.dirname(TILE_DATA_PATH),
            MODEL_DIR
        ]
        
        for directory in directories:
            if not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
                logger.info(f"Created directory: {directory}")
    
    def _initialize_tiles(self) -> None:
        """Initialize tile data from S3 or local file"""
        if not os.path.exists(TILE_DATA_PATH):
            logger.info("Downloading tile data from S3...")
            self._download_tile_data()
        
        self.tiles = gp.read_file(TILE_DATA_PATH)
        self.tiles = self.tiles.set_crs(DataProcessingConfig.DEFAULT_CRS)
        logger.info(f"Loaded {len(self.tiles)} tiles")
    
    def _download_tile_data(self) -> None:
        """Download tile data from S3 with retry logic"""
        for attempt in range(VisualizationConfig.S3_MAX_RETRIES):
            try:
                self.s3_client.download_file(S3_BUCKET, S3_TILE_DATA_PATH, TILE_DATA_PATH)
                logger.info("Successfully downloaded tile data from S3")
                return
            except Exception as e:
                logger.warning(f"Failed to download tile data (attempt {attempt + 1}): {e}")
                if attempt == VisualizationConfig.S3_MAX_RETRIES - 1:
                    raise
                time.sleep(VisualizationConfig.S3_RETRY_DELAY)

    def get_canopy_height(
        self, 
        bounding_box: List[float], 
        method: str = "chm", 
        data_source: str = "aws"
    ) -> str:
        """
        Get canopy height data for specified bounding box
        
        Args:
            bounding_box: List of coordinates [lat1, lon1, lat2, lon2]
            method: Processing method ("chm")
            data_source: Data source ("aws" or "local")
            
        Returns:
            Path to cropped canopy height file
        """
        if method == "chm":
            return self.get_canopy_height_chm(bounding_box, data_source)
        elif method == "model":
            return self.get_canopy_height_model(bounding_box)
        else:
            raise ValueError(f"Unsupported method: {method}")
    
    def get_canopy_height_model(
        self, 
        bounding_box: List[float],
        MODEL_ID = "compressed_SSLhuge"
    ) -> str:
        center_lat, center_lon = self.get_center_lat_lon(bounding_box)
        local_rgb_file = self.get_local_rgb_file(center_lat, center_lon, output_dir=LOCAL_CHM_DIR, zoom=18, size=MODEL_WINDOW_SIZE)
        #get model
        s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
        bucket='dataforgood-fb-data'
        localdir='data/models'
        s3file='forests/v1/models/saved_checkpoints/compressed_SSLhuge.pth'
        local_model_file=f"{localdir}/{os.path.basename(s3file)}"
        if not os.path.exists(local_model_file):
            s3_client.download_file(bucket, s3file, local_model_file)
        model=SSLModule3(local_model_file)
        model.eval()

        chm_path=self.windowed_infer_loop(local_rgb_file, model, window_size=1024)
        
        #plot result
        with rasterio.open(local_rgb_file) as src:
            data=src.read()
            image = np.moveaxis(data[0:3], 0, -1)
        with rasterio.open(chm_path) as src:
            chm=src.read().squeeze()
            
        plt.figure(figsize=(16,6))
        plt.subplot(1,2,1)
        plt.imshow(image)
        plt.title('input RGB')
        plt.subplot(1,2,2)
        plt.imshow(chm, vmin=0, vmax=15)
        plt.title('Canopy Height')

        return chm_path
    
    def get_local_rgb_file(self, lat, lon, output_dir="downloaded_images", zoom=20, size=448):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        filename = f"{lat}_{lon}_z{zoom}_{size}x{size}.tif"
        output_path = os.path.join(output_dir, filename)

        if os.path.exists(output_path):
            return output_path

        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")

        params = {
            'center': f"{lat},{lon}",
            'zoom': zoom,
            'size': f"{size}x{size}",
            'scale': 1,
            'maptype': 'satellite',
            'key': api_key,
            'format': 'png'
        }

        response = requests.get("https://maps.googleapis.com/maps/api/staticmap", params=params, timeout=30)
        response.raise_for_status()

        temp_png_path = os.path.join(output_dir, f"temp_{lat}_{lon}.png")
        with open(temp_png_path, 'wb') as f:
            f.write(response.content)

        img = Image.open(temp_png_path).convert("RGB")
        img_np = np.array(img)

        height, width, channels = img_np.shape
        transform = from_origin(0, 0, 1, 1)

        with rasterio.open(
            output_path,
            'w',
            driver='GTiff',
            height=height,
            width=width,
            count=3,
            dtype=img_np.dtype,
            transform=transform
        ) as dst:
            for i in range(3):
                dst.write(img_np[:, :, i], i + 1)

        os.remove(temp_png_path)
        return output_path
    
    def get_center_lat_lon(self, bounding_box: List[float]) -> Tuple[float, float]:
        """Get the center latitude and longitude from bounding box"""
        lat1, lon1, lat2, lon2 = bounding_box
        center_lat = (lat1 + lat2) / 2
        center_lon = (lon1 + lon2) / 2
        return center_lat, center_lon
    
    def run_inference_blocks(self, img, model, winsize=256):
    
        print(f"Running inference on image block of shape: {img.shape}")

        #this is how we breakup large images into batches for model inference
        step = int(winsize * 3 / 4)
        print(f"Blocking with window size: {winsize}, step: {step}")
        stack, vx, vy = raster_utils.blocking(img, (winsize, winsize, 3), step)

        transform = transforms.SSLNorm().Trans

        data = CustomImageDataset(stack, transform=transform)
        dl = DataLoader(data, shuffle=False, batch_size=stack.shape[0])
        batch = next(iter(dl))
        
        output, _ = model.predict(batch)
        weight = raster_utils.create_apodization((winsize, winsize))


        pred_stack = output.detach().numpy().squeeze()
        pred_stack = np.expand_dims(pred_stack, -1)
        out_size = img.shape[0:2]
        pred_im, weights = raster_utils.inverse_blocking(
            pred_stack, out_size, winsize, weight, step, vx, vy
        )
        pred_im = pred_im.squeeze()
        return pred_im


    def windowed_infer_loop(self, image_path, model, out_path=None, window_size=448):
        #suggested window sizes: 448, 1024
        if not out_path:
            out_path=image_path.replace('.tif', '_chm.tif')
        with rasterio.open(image_path) as src:
            print(f"Image size: {src.width} x {src.height}")
            meta=src.meta
            meta.update({'count':1,
                        "dtype": np.float32,
                        "driver":'GTiff',
                        "nodata": np.nan,
                        })
            with rasterio.open(out_path, 'w', **meta) as dst:
                row_coords=list(np.arange(0,src.height,window_size)[:-1])+[src.height-window_size]
                col_coords=list(np.arange(0,src.width,window_size)[:-1])+[src.width-window_size]
                for row in tqdm(row_coords, desc="inference_progress", position=0):
                    for col in col_coords:
                        window = Window(col, row, window_size, window_size)
                        data = src.read(window=window)
                        mask=src.read_masks(1, window=window)
                        image = np.moveaxis(data, 0, -1)
                        chm_block=self.run_inference_blocks(image, model)
                        chm_block=chm_block.astype(meta['dtype'])
                        chm_block[~mask==src.nodata]=meta['nodata']
                        dst.write(chm_block, window=window, indexes=1)
                
        return out_path
    
    def get_canopy_height_chm(
        self, 
        bounding_box: List[float], 
        data_source: str = "aws"
    ) -> str:
        """
        Get canopy height data using CHM method
        
        Args:
            bounding_box: List of coordinates [lat1, lon1, lat2, lon2]
            data_source: Data source ("aws" or "local")
            
        Returns:
            Path to cropped canopy height file
        """
        cropfile = self.get_crop_file(bounding_box, data_source)

        # Save canopy height data as text file
        # self._save_canopy_data(cropfile)
        
        # Generate visualization plot
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        title = f"canopy_height_{bbox_filename}"
        self.plot_canopy_height(cropfile, title=title, output_dir=CANOPY_HEIGHT_IMAGE_DIR)
        
        return cropfile
    
    def _save_canopy_data(self, cropfile: str) -> None:
        """Save canopy height data as text file for analysis"""
        with rasterio.open(cropfile) as src:
            canopy_height_data = src.read(1)
            logger.info(f"Canopy height data shape: {canopy_height_data.shape}")
            output_file = os.path.join(LOCAL_CHM_DIR, 'output.txt')
            np.savetxt(output_file, canopy_height_data, fmt='%.2f')
            logger.info(f"Saved canopy height data to: {output_file}")
    
    def get_crop_file(self, bounding_box: List[float], data_source: str = "aws") -> str:
        """
        Process bounding box and return cropped file path
        
        Args:
            bounding_box: List of coordinates [lat1, lon1, lat2, lon2]
            data_source: Data source ("aws" or "local")
            
        Returns:
            Path to cropped canopy height file
        """
        # Create target polygon file
        target_polyfile = self._create_target_polyfile(bounding_box)
        
        # Get intersecting tiles
        target_tiles = self._get_intersecting_tiles(target_polyfile)
        
        # Download and process tiles
        tifs = self._process_tiles(target_tiles, data_source)
        
        # Merge tiles
        mergefile = self._merge_tiles(tifs, target_tiles)
        
        # Crop to bounding box
        cropfile = self._crop_to_bounding_box(mergefile, target_polyfile, bounding_box)
        
        return cropfile
    
    def _create_target_polyfile(self, bounding_box: List[float]) -> str:
        """Create target polygon file from bounding box"""
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        target_polyfile = f"{TARGET_PLOY_FILE_DIR}/{bbox_filename}.geojson"
        
        if not os.path.exists(target_polyfile):
            os.makedirs(TARGET_PLOY_FILE_DIR, exist_ok=True)
            geojson = self.bounding_box_to_geojson(bounding_box)
            with open(target_polyfile, 'w') as f:
                json.dump(geojson, f)
            logger.info(f"Created target polygon file: {target_polyfile}")
        
        return target_polyfile
    
    def _get_intersecting_tiles(self, target_polyfile: str) -> gp.GeoDataFrame:
        """Get tiles that intersect with target area"""
        target = gp.read_file(target_polyfile)
        target = target.set_crs(DataProcessingConfig.DEFAULT_CRS)
        target_tiles = gp.sjoin(self.tiles, target)
        logger.info(f"Found {len(target_tiles)} intersecting tiles")
        return target_tiles
    
    def _process_tiles(self, target_tiles: gp.GeoDataFrame, data_source: str) -> List[str]:
        """Download and process tiles based on data source"""
        tifs = []
        tile_numbers = []
        
        for ii, row in target_tiles.iterrows():
            tile_numbers.append(row.tile)
            
            if data_source == "aws":
                tif_file = self._process_aws_tile(row)
            elif data_source == "local":
                tif_file = self._process_local_tile(row)
            else:
                raise ValueError(f"Unsupported data source: {data_source}")
            
            tifs.append(tif_file)
        
        logger.info(f"Processed {len(tifs)} tiles")
        return tifs
    
    def _process_aws_tile(self, row: Any) -> str:
        """Process a single AWS tile"""
        tile = row.tile
        
        # Download CHM file
        s3file = f"{S3_CHM_PATH}/{tile}.tif"
        localfile = f"{LOCAL_CHM_DIR}/{os.path.basename(s3file)}"
        self._download_s3_file(s3file, localfile)
        
        # Download cloud mask
        mskfile = f"{S3_MSK_PATH}/{tile}.tif.msk"
        localmskfile = f"{LOCAL_CHM_DIR}/{os.path.basename(mskfile)}"
        self._download_s3_file(mskfile, localmskfile)
        
        # Download metadata
        jsonfile = f"{S3_META_PATH}/{tile}.geojson"
        localjsonfile = f"{LOCAL_CHM_DIR}/{os.path.basename(jsonfile)}"
        self._download_s3_file(jsonfile, localjsonfile)
        
        # Apply mask
        outfile = localfile.replace('.tif', 'masked.tif')
        if not os.path.exists(outfile):
            self.enforce_mask(localfile, outfile)
        
        return outfile
    
    def _process_local_tile(self, row: Any) -> str:
        """Process a single local tile"""
        tile = row.tile
        
        # Copy CHM file
        localfile = f"{LOCAL_CHM_DIR}/{tile}.tif"
        if not os.path.exists(localfile):
            logger.info(f"Copying {tile}.tif to {localfile}")
            shutil.copy(f"{LOCAL_TIF_DIR}/{tile}.tif", localfile)
        
        # Copy cloud mask
        localmskfile = f"{LOCAL_CHM_DIR}/{tile}.tif.msk"
        if not os.path.exists(localmskfile):
            logger.info(f"Copying {tile}.tif.msk to {localmskfile}")
            shutil.copy(f"{LOCAL_MSK_DIR}/{tile}.tif.msk", localmskfile)
        
        # Copy metadata
        localjsonfile = f"{LOCAL_CHM_DIR}/{tile}.geojson"
        if not os.path.exists(localjsonfile):
            logger.info(f"Copying {tile}.geojson to {localjsonfile}")
            shutil.copy(f"{LOCAL_META_DIR}/{tile}.geojson", localjsonfile)
        
        # Apply mask
        outfile = f"{LOCAL_CHM_DIR}/{tile}masked.tif"
        if not os.path.exists(outfile):
            self.enforce_mask(localfile, outfile)
        
        return outfile
    
    def _download_s3_file(self, s3_key: str, local_path: str) -> None:
        """Download file from S3 with retry logic"""
        if not os.path.exists(local_path):
            logger.info(f"Downloading {s3_key} to {local_path}")
            for attempt in range(VisualizationConfig.S3_MAX_RETRIES):
                try:
                    self.s3_client.download_file(S3_BUCKET, s3_key, local_path)
                    return
                except Exception as e:
                    logger.warning(f"Failed to download {s3_key} (attempt {attempt + 1}): {e}")
                    if attempt == VisualizationConfig.S3_MAX_RETRIES - 1:
                        raise
                    time.sleep(VisualizationConfig.S3_RETRY_DELAY)
    
    def _merge_tiles(self, tifs: List[str], target_tiles: gp.GeoDataFrame) -> str:
        """Merge multiple tile files into one"""
        tile_numbers = [row.tile for _, row in target_tiles.iterrows()]
        tile_numbers_str = '_'.join(tile_numbers)
        mergefile = f"{LOCAL_CHM_DIR}/{tile_numbers_str}_alltiles.tif"
        
        if not os.path.exists(mergefile):
            logger.info(f"Merging {len(tifs)} tiles into {mergefile}")
            self.merge_rasters(tifs, outfile=mergefile)
        
        return mergefile
    
    def _crop_to_bounding_box(self, mergefile: str, target_polyfile: str, bounding_box: List[float]) -> str:
        """Crop merged file to bounding box"""
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        cropfile = f"{LOCAL_CHM_DIR}/{bbox_filename}_crop.tif"
        
        if not os.path.exists(cropfile):
            logger.info(f"Cropping to bounding box: {cropfile}")
            self.crop_raster(mergefile, target_polyfile, cropfile)
        
        return cropfile

    def bounding_box_to_geojson(self, bbox: List[float]) -> Dict[str, Any]:
        """
        Convert a bounding box [lat1, lon1, lat2, lon2] to a GeoJSON Polygon.
        Assumes lat1/lon1 is one corner, lat2/lon2 is the opposite corner.
        """
        lat1, lon1, lat2, lon2 = bbox

        # Ensure correct ordering: south, west, north, east
        south = min(lat1, lat2)
        north = max(lat1, lat2)
        west = min(lon1, lon2)
        east = max(lon1, lon2)

        # Define the polygon coordinates (must be closed: first point == last point)
        coordinates = [[
            [west, south],
            [east, south],
            [east, north],
            [west, north],
            [west, south]
        ]]

        geojson = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": coordinates
            },
            "properties": {}
        }

        return geojson

    # Raster processing functions

    def merge_rasters(self, files: List[str], outfile: str = "test.tif") -> None:
        """
        Merge a list of geotiffs into one file
        """
        src_files_to_mosaic = []
        for fp in files:
            src = rasterio.open(fp)
            src_files_to_mosaic.append(src)

        crs = src.crs
        out_meta = src.meta.copy()
        mosaic, out_trans = merge(src_files_to_mosaic)

        # Update the metadata
        out_meta.update(
            {
                "driver": "GTiff",
                "height": mosaic.shape[1],
                "width": mosaic.shape[2],
                "transform": out_trans,
                "crs": crs,
            }
        )

        with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION, BIGTIFF=DataProcessingConfig.BIGTIFF) as dest:
            dest.write(mosaic)

    def crop_raster(self, rasterfile: str, aoifile: str, outfile: str = "test.tif", nodata: int = None) -> None:
        """Crop raster to area of interest"""
        if nodata is None:
            nodata = DataProcessingConfig.DEFAULT_NODATA
            
        gdf_aoi = gp.read_file(aoifile)
        with rasterio.open(rasterfile) as src:
            out_meta = src.meta.copy()
            if not src.crs == gdf_aoi.crs:
                gdf_aoi = gdf_aoi.to_crs(src.crs)
            aoi = gdf_aoi.iloc[0].geometry
            im, trans = rasterio.mask.mask(
                src, [aoi], crop=True, nodata=nodata, all_touched=True
            )
            # Update the metadata
            out_meta.update(
                {
                    "driver": "GTiff",
                    "height": im.shape[1],
                    "width": im.shape[2],
                    "transform": trans,
                    "crs": src.crs,
                    "nodata": nodata,
                }
            )
        with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION, BIGTIFF=DataProcessingConfig.BIGTIFF) as dest:
            dest.write(im)

    def enforce_mask(self, file: str, outfile: Optional[str] = None, nodata: int = None) -> None:
        """Apply cloud mask to raster file"""
        if not outfile:
            outfile = file.replace('.tif', 'masked.tif')
        if nodata is None:
            nodata = DataProcessingConfig.DEFAULT_NODATA
            
        with rasterio.open(file) as src:
            mask = src.read_masks()
            data = src.read()
            # nodata has been assigned as 255 in the S3 .msk files
            data[mask == 255] = nodata
            out_meta = src.meta
            out_meta.update({"nodata": nodata})
            with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION) as dest:
                dest.write(data)
                
    # Visualization functions

    def mercator_to_latlon_ax(self, ax: plt.Axes, dec: int = 2) -> None:
        """Convert Mercator coordinates to lat/lon for axis labels"""
        xt = ax.get_xticks()
        yt = ax.get_yticks()
        trans = Transformer.from_proj(DataProcessingConfig.MERCATOR_CRS, DataProcessingConfig.DEFAULT_CRS)
        # can do this because 3857 has parallel lat and lon
        zlon = [yt[0] for _ in range(len(xt))]
        zlat = [xt[0] for _ in range(len(yt))]
        _, lon = trans.transform(xt, zlon)
        lat, _ = trans.transform(zlat, yt)
        lons = []
        for l in lon:
            if l < 0:
                hem = 'W'
            else:
                hem = 'E'
            lons.append(f"{np.abs(np.round(l, dec))}{chr(176)}{hem}")
        lats = []
        for l in lat:
            if l < 0:
                hem = 'S'
            else:
                hem = 'N'
            lats.append(f"{np.abs(np.round(l, dec))}{chr(176)}{hem}")

        ax.set_yticklabels(lats, fontsize=18, fontweight="bold")
        ax.set_xticklabels(lons, fontsize=18, fontweight="bold")
        ax.yaxis.set_tick_params(rotation=90)

    def geojson_to_poly(self, geojson: Dict[str, Any]) -> Any:
        """
        Given a geojson with a polygon shape,
        return the shapely object
        """
        if len(geojson["features"]) > 1:
            poly = GeometryCollection(
                [shape(feature["geometry"]).buffer(0) for feature in geojson["features"]]
            )
        else:
            f = geojson["features"][0]
            poly = shape(f["geometry"]).buffer(0)
        if poly.geom_type != "Polygon":
            pps = []
            for pp in poly.geoms:
                pp = polygon.orient(pp)  # correct winding
                pps.append(pp)
            out_geom = MultiPolygon(pps)
        else:
            out_geom = polygon.orient(poly)  # correct winding
        return out_geom

    def plot_canopy_height(
        self, 
        cropfile: str, 
        title: str = 'canopy_height', 
        output_dir: str = 'data/images/canopy_height', 
        dpi: int = None
    ) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot canopy height data from a cropped raster file
        
        Parameters:
        -----------
        cropfile : str
            Path to the cropped raster file
        title : str
            Title for the plot and output filename
        output_dir : str
            Directory to save the output image
        dpi : int
            Resolution for the output image
        """
        if dpi is None:
            dpi = VisualizationConfig.DPI
            
        with rasterio.open(cropfile) as src:
            data = src.read().squeeze()
            bounds = src.bounds
            width = src.width
            height = src.height

        factor = 1
        new_width = int(width/factor)
        new_height = int(height/factor)
        xx = Image.fromarray(data).resize(
            (new_width, new_height), Image.BICUBIC
        )
        chm = np.array(xx).astype('float')
        # set nodata (with interp fuzziness)
        chm[chm > VisualizationConfig.CANOPY_NODATA_THRESHOLD] = np.nan
        
        fig, ax = plt.subplots(1, 1, figsize=[14, 10])
        bbox = box(*bounds)
        extent = (bbox.bounds[0], bbox.bounds[2], bbox.bounds[1], bbox.bounds[3])
        colors = ax.imshow(chm, vmax=np.nanpercentile(chm, 99.5), extent=extent)
        tt = ax.get_xticks()[1:-1]
        ax.set_xticks(tt[::3])
        tt = ax.get_yticks()[1:-1]
        ax.set_yticks(tt[::3])
        self.mercator_to_latlon_ax(ax, dec=2)
        cax = plt.gca().inset_axes([1.05, 0.3, 0.03, 0.4])
        plt.colorbar(colors, cax=cax, label='canopy height [meters]')
        ax.set_title(title)
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        plt.savefig(f'{output_dir}/{title}.png', dpi=dpi, bbox_inches='tight')
        plt.close()  # Close the figure to free memory
        
        logger.info(f"Saved canopy height plot: {output_dir}/{title}.png")
        return fig, ax