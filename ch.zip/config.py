OUTPUT_DIR = "test_image_2"
TILE_DATA_PATH = "data/chm/metadata/tiles.geojson"
LOCAL_CHM_DIR = "data/chm/chm"
S3_CHM_PATH = 'forests/v1/alsgedi_global_v6_float/chm'
S3_MSK_PATH = 'forests/v1/alsgedi_global_v6_float/msk'
S3_META_PATH = 'forests/v1/alsgedi_global_v6_float/metadata'
S3_TILE_DATA_PATH = 'forests/v1/alsgedi_global_v6_float/tiles.geojson'
S3_BUCKET = 'dataforgood-fb-data'
TARGET_PLOY_FILE_DIR = "data/chm/target"
GOOGLE_MAPS_IMAGE_DIR = OUTPUT_DIR + "/images/building/google_maps_image"
LOCAL_IMAGE_DIR = OUTPUT_DIR + "/images/building/local"
CANOPY_HEIGHT_IMAGE_DIR = OUTPUT_DIR + "/images/canopy_height"
OVERLAY_IMAGE_DIR = OUTPUT_DIR + "/images/overlay"
SIDE_BY_SIDE_IMAGE_DIR = OUTPUT_DIR + "/images/side_by_side"
LOCAL_TIF_DIR= '/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/chm'
LOCAL_MSK_DIR= '/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/msk'
LOCAL_META_DIR= '/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/metadata'

MODEL_DIR = "data/models"
MODEL_WINDOW_SIZE=448

# New configuration class for better organization
class VisualizationConfig:
    """Configuration class for visualization settings"""
    # Color settings
    CANOPY_COLOR = [255, 0, 0]  # Red color for canopy overlay
    CANOPY_COLORMAP = 'viridis'  # Colormap for side-by-side visualization
    
    # Image quality settings
    IMAGE_QUALITY = 95
    DPI = 300
    FIGURE_SIZE = (14, 7)
    
    # Data processing thresholds
    CANOPY_NODATA_THRESHOLD = 200
    CANOPY_MIN_THRESHOLD = 0
    
    # Overlay settings
    DEFAULT_ALPHA = 0.3
    DEFAULT_CANOPY_THRESHOLD = 0
    
    # Google Maps API settings
    GOOGLE_MAPS_IMAGE_SIZE = '4096x4096'
    GOOGLE_MAPS_MAPTYPE = 'satellite'
    GOOGLE_MAPS_FORMAT = 'png'
    REQUEST_TIMEOUT = 30
    
    # Zoom level thresholds
    ZOOM_LEVELS = {
        'large': (0.1, 10),      # max_diff > 0.1
        'medium': (0.01, 15),    # max_diff > 0.01
        'small': (0.001, 18),    # max_diff > 0.001
        'precise': (0, 20)       # max_diff <= 0.001
    }
    
    # S3 settings
    S3_MAX_RETRIES = 3
    S3_RETRY_DELAY = 1  # seconds

class DataProcessingConfig:
    """Configuration class for data processing settings"""
    # Raster processing
    DEFAULT_NODATA = 255
    COMPRESSION = "DEFLATE"
    BIGTIFF = 'YES'
    
    # Coordinate systems
    DEFAULT_CRS = 'EPSG:4326'
    MERCATOR_CRS = 'EPSG:3857'
    
    # File naming
    TILE_SEPARATOR = '_'
    COORD_SEPARATOR = '_'