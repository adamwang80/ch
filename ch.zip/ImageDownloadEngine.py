import os
import requests
from PIL import Image
from config import GOOGLE_MAPS_IMAGE_DIR, VisualizationConfig
from dotenv import load_dotenv
import logging
from typing import List, Tuple, Optional
import time

load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class ImageDownloadEngine:
    def __init__(self):
        self.google_maps_image_dir = GOOGLE_MAPS_IMAGE_DIR
        self._ensure_directories()
    
    def _ensure_directories(self) -> None:
        """Ensure required directories exist"""
        if not os.path.exists(self.google_maps_image_dir):
            os.makedirs(self.google_maps_image_dir, exist_ok=True)
            logger.info(f"Created directory: {self.google_maps_image_dir}")
    
    def download_image(
        self, 
        bounding_box: List[float], 
        data_source: str = "google_maps", 
        overwrite: bool = False
    ) -> str:
        """
        Download satellite image using specified data source
        
        Args:
            bounding_box: List of coordinates [lat1, lon1, lat2, lon2]
            data_source: Source for satellite images ("google_maps")
            overwrite: Whether to overwrite existing files
            
        Returns:
            Path to downloaded image file
            
        Raises:
            ValueError: If data source is not supported
        """
        if data_source == "google_maps":
            if not overwrite:
                output_filename = self._get_output_filename(bounding_box)
                if os.path.exists(output_filename):
                    logger.info(f"Image already exists: {output_filename}")
                    return output_filename
            return self.download_google_static_maps(bounding_box)
        else:
            raise ValueError(f"Unsupported data source: {data_source}")
    
    def _get_output_filename(self, bounding_box: List[float]) -> str:
        """Generate output filename from bounding box"""
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        return f"{self.google_maps_image_dir}/{bbox_filename}.png"
    
    def _calculate_zoom_level(self, bounding_box: List[float]) -> int:
        """Calculate appropriate zoom level based on area size"""
        lat1, lon1, lat2, lon2 = bounding_box
        max_diff = max(abs(lat2 - lat1), abs(lon2 - lon1))
        
        for threshold, zoom in VisualizationConfig.ZOOM_LEVELS.values():
            if max_diff > threshold:
                return zoom
        
        return VisualizationConfig.ZOOM_LEVELS['precise'][1]
    
    def _calculate_center_point(self, bounding_box: List[float]) -> Tuple[float, float]:
        """Calculate center point of bounding box"""
        lat1, lon1, lat2, lon2 = bounding_box
        center_lat = (lat1 + lat2) / 2
        center_lon = (lon1 + lon2) / 2
        return center_lat, center_lon
    
    def _get_api_key(self) -> str:
        """Get Google Maps API key from environment variables"""
        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")
        return api_key
    
    def _make_api_request(self, params: dict) -> requests.Response:
        """Make API request with retry logic"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    "https://maps.googleapis.com/maps/api/staticmap", 
                    params=params, 
                    timeout=VisualizationConfig.REQUEST_TIMEOUT
                )
                response.raise_for_status()
                logger.info(f"Successfully downloaded image from Google Maps API (attempt {attempt + 1})")
                return response
            except requests.exceptions.RequestException as e:
                logger.warning(f"API request failed (attempt {attempt + 1}): {e}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(1)  # Wait before retry
    
    def _calculate_crop_coordinates(
        self, 
        img: Image.Image, 
        bounding_box: List[float], 
        zoom: int
    ) -> Tuple[int, int, int, int]:
        """Calculate pixel coordinates for cropping"""
        lat1, lon1, lat2, lon2 = bounding_box
        
        # Calculate pixels per degree at this zoom level
        pixels_per_degree = 2 ** zoom * 256 / 360
        center_x = img.width // 2
        center_y = img.height // 2
        
        # Calculate crop dimensions
        crop_width = int(abs(lon2 - lon1) * pixels_per_degree)
        crop_height = int(abs(lat2 - lat1) * pixels_per_degree)
        
        # Calculate crop boundaries
        left = max(0, center_x - crop_width // 2)
        top = max(0, center_y - crop_height // 2)
        right = min(img.width, left + crop_width)
        bottom = min(img.height, top + crop_height)
        
        return left, top, right, bottom
    
    def download_google_static_maps(self, bounding_box: List[float]) -> str:
        """
        Download and crop satellite image from Google Static Maps API
        
        Args:
            bounding_box: List of coordinates [lat1, lon1, lat2, lon2]
            
        Returns:
            Path to the cropped satellite image
            
        Raises:
            ValueError: If API key is not found
            requests.RequestException: If API request fails
        """
        # Calculate parameters
        center_lat, center_lon = self._calculate_center_point(bounding_box)
        zoom = self._calculate_zoom_level(bounding_box)
        
        # Create filenames
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        temp_filename = f"{self.google_maps_image_dir}/temp_{bbox_filename}.png"
        output_filename = f"{self.google_maps_image_dir}/{bbox_filename}.png"
        
        # Check if output already exists
        if os.path.exists(output_filename):
            logger.info(f"Output file already exists: {output_filename}")
            return output_filename
        
        # Ensure directory exists
        os.makedirs(self.google_maps_image_dir, exist_ok=True)
        
        # Get API key
        api_key = self._get_api_key()
        
        # Prepare API request parameters
        params = {
            'center': f"{center_lat},{center_lon}",
            'zoom': zoom,
            'size': VisualizationConfig.GOOGLE_MAPS_IMAGE_SIZE,
            'maptype': VisualizationConfig.GOOGLE_MAPS_MAPTYPE,
            'key': api_key,
            'format': VisualizationConfig.GOOGLE_MAPS_FORMAT
        }
        
        try:
            # Make API request
            response = self._make_api_request(params)
            
            # Save original image
            with open(temp_filename, 'wb') as f:
                f.write(response.content)
            
            # Crop to exact bounding box
            img = Image.open(temp_filename)
            crop_coords = self._calculate_crop_coordinates(img, bounding_box, zoom)
            cropped_img = img.crop(crop_coords)
            
            # Save cropped image
            cropped_img.save(output_filename, 'PNG', quality=VisualizationConfig.IMAGE_QUALITY)
            
            # Clean up temporary file
            os.remove(temp_filename)
            
            logger.info(f"Successfully created cropped satellite image: {output_filename}")
            return output_filename
            
        except Exception as e:
            # Clean up temp file if it exists
            if os.path.exists(temp_filename):
                os.remove(temp_filename)
            logger.error(f"Failed to download satellite image: {e}")
            raise