from torch.utils.data import Dataset

class CustomImageDataset(Dataset):
    def __init__(self, stack, transform=None) -> None:
        self.len = stack.shape[0]
        self.transform = transform
        self.stack = stack
        self.im_shape = stack.shape[1:]

    def __len__(self):
        return self.len

    def __getitem__(self, idx):
        self.idx = idx
        im = self.stack[idx]
        if self.transform:
            im = self.transform(im)

        data = {"image": im}
        return data
    
