#!/usr/bin/env python3
"""
测试Google Maps API密钥是否有效
"""

import os
import requests
from dotenv import load_dotenv

load_dotenv()

def test_google_maps_api():
    """测试Google Maps API密钥"""
    api_key = os.getenv('GOOGLE_MAPS_API_KEY')
    
    if not api_key:
        print("❌ GOOGLE_MAPS_API_KEY not found in environment variables")
        return False
    
    print(f"🔑 API Key found: {api_key[:10]}...")
    
    # 测试API调用
    params = {
        'center': '39.30247393341169,-84.50006314687037',
        'zoom': 18,
        'size': '100x100',
        'maptype': 'satellite',
        'key': api_key,
        'format': 'png'
    }
    
    try:
        response = requests.get("https://maps.googleapis.com/maps/api/staticmap", 
                              params=params, timeout=10)
        
        if response.status_code == 200:
            print("✅ Google Maps API key is valid!")
            return True
        else:
            print(f"❌ API call failed with status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Error testing API: {e}")
        return False

if __name__ == "__main__":
    test_google_maps_api() 