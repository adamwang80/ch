import torch
torch.backends.quantized.engine = 'qnnpack'  # Set quantization engine
import pytorch_lightning as pl
from inference import SSLAE

class SSLModule3(pl.LightningModule):
    def __init__(self, path, classify=True, map_location="cpu"):
        super().__init__()
        self.translation_invariant_mse_loss = False
        ckpt = torch.load(path, map_location=map_location)
        self.chm_module_ = SSLAE(classify=classify, huge=True).eval()
        self.chm_module_ = torch.quantization.quantize_dynamic(
            self.chm_module_,
            {torch.nn.Linear, torch.nn.Conv2d, torch.nn.ConvTranspose2d},
            dtype=torch.qint8,
        )
        self.chm_module_.load_state_dict(ckpt, strict=False)

    def predict(self, batch):
        device = next(self.chm_module_.parameters()).device
        x = batch["image"].to(device)
        outputs = self.chm_module_(x)
        pred = 10 * outputs + 0.001
        pred = pred.relu()
        return pred, outputs