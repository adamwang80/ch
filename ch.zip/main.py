from CanopyHeightEngine import CanopyHeightEngine
from ImageDownloadEngine import ImageDownloadEngine
from utils import overlay_canopy_on_image, side_by_side_canopy_image, generate_bbox_filename
from config import OUTPUT_DIR, OVERLAY_IMAGE_DIR, SIDE_BY_SIDE_IMAGE_DIR, GOOGLE_MAPS_IMAGE_DIR, LOCAL_CHM_DIR
import os
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """Main function to process canopy height data and create visualizations"""
    try:
        # Define bounding box coordinates
        bounding_box = [45.81420138779721, 9.071142020358453, 45.81325430419046, 9.073878784584062]
        # bounding_box = [37.73855299868556, 115.66015007630251, 37.73665035629727, 115.66423438588026]

        logger.info(f"Processing bounding box: {bounding_box}")

        # Initialize engines
        engine = CanopyHeightEngine()
        image_engine = ImageDownloadEngine()

        # Get canopy height data
        logger.info("Getting canopy height data...")
        engine.get_canopy_height(bounding_box, method="model", data_source="aws")

        # # Download satellite image
        # logger.info("Downloading satellite image...")
        # image_engine.download_image(bounding_box, overwrite=False)

        # # Generate filenames
        # bbox_filename = generate_bbox_filename(bounding_box)
        # canopy_height_file = f"{LOCAL_CHM_DIR}/{bbox_filename}_crop.tif"
        # satellite_image_file = f"{GOOGLE_MAPS_IMAGE_DIR}/{bbox_filename}.png"

        # # Create overlay image
        # logger.info("Creating overlay image...")
        # if not os.path.exists(OVERLAY_IMAGE_DIR):
        #     os.makedirs(OVERLAY_IMAGE_DIR, exist_ok=True)
        # output_file = f"{OVERLAY_IMAGE_DIR}/overlay_{bbox_filename}.png"
        # overlay_canopy_on_image(canopy_height_file, satellite_image_file, output_file)

        # # Create side-by-side comparison
        # logger.info("Creating side-by-side comparison...")
        # if not os.path.exists(SIDE_BY_SIDE_IMAGE_DIR):
        #     os.makedirs(SIDE_BY_SIDE_IMAGE_DIR, exist_ok=True)
        # output_file = f"{SIDE_BY_SIDE_IMAGE_DIR}/side_by_side_{bbox_filename}.png"
        # side_by_side_canopy_image(canopy_height_file, satellite_image_file, output_file)

        # logger.info("Processing completed successfully!")

    except Exception as e:
        logger.error(f"Error in main processing: {e}")
        raise

if __name__ == "__main__":
    main()