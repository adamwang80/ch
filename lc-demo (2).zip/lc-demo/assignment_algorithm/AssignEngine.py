from typing import List, Dict, Tuple
import pandas as pd
from model.Rep import Rep
from assignment_algorithm.strategy.vanilla_strategy import vanilla_strategy
from assignment_algorithm.strategy.round_robin_strategy import round_robin_strategy
from assignment_algorithm.strategy.highest_score_first_strategy import highest_score_first_strategy
from assignment_algorithm.scoring_system.scoring_algorithm import ScoringAlgorithm
from config.config import STRATEGY
from config.config import ASSIGNMENT_LOWERBOUND, ASSIGNMENT_LOWERBOUND_KA

class AssignEngine:
    def __init__(self, rep_dict: Dict[str, Rep], task_pool: pd.DataFrame, strategy: str = STRATEGY):
        self.rep_dict = self.filter_rep_dict(rep_dict)
        self.task_pool = task_pool
        self.strategy = strategy
        self.scoring_algorithm = ScoringAlgorithm()

    def run(self) -> Dict[str, List[str]]:
        rep_scores = self.generate_score()
        assignment_result = self.run_strategy(rep_scores)

        return assignment_result
        
    def generate_score(self):
        rep_scores: Dict[str, List[Tuple[str, float, List[Tuple[float, float]]]]] = {}

        for rep_id, rep_info in self.rep_dict.items():
            rep_scores[rep_id] = []

            for _, row in self.task_pool.iterrows():
                task_id = row["task_id"]
                final_score, sub_scores = self.scoring_algorithm.run(rep_info, row)
                rep_scores[rep_id].append((task_id, final_score, sub_scores))

            rep_scores[rep_id].sort(key=lambda x: x[1], reverse=True)
        
        return rep_scores

    def run_strategy(self, rep_scores):
        if self.strategy == "vanilla":
            return vanilla_strategy(rep_scores, self.rep_dict)
        elif self.strategy == "round_robin":
            return round_robin_strategy(rep_scores, self.rep_dict) 
        elif self.strategy == "highest_score_first":
            return highest_score_first_strategy(rep_scores, self.rep_dict)    
        raise ValueError(f"Unknown strategy: {self.strategy}")
    
    def filter_rep_dict(self, rep_dict: Dict[str, Rep]) -> Dict[str, Rep]:
        filtered_rep_dict = {
            rep_id: rep for rep_id, rep in rep_dict.items()
            if (rep.key_account and rep.current_task_count < ASSIGNMENT_LOWERBOUND_KA) or
               (not rep.key_account and rep.current_task_count < ASSIGNMENT_LOWERBOUND)
        }
        return filtered_rep_dict

