# config/config.py
MAX_TASK_PER_REP = 20
ASSIGNMENT_LOWERBOUND = 15

MAX_TASK_PER_REP_KA = 15
ASSIGNMENT_LOWERBOUND_KA = 10

DIFFERENT_REGION_PENALTY = 100
LOAD_PERCENTAGE_LAMBDA = 2
VIRTUAL_TASK_DISTANCE_WEIGHT_DISCOUNT_FACTOR = 0.9

SOURCES = {
    "CLD_MATRIX_PACKAGE": {
        "FROM_DATE": "2025/10/1",
        "TO_DATE": "2025/11/30",
        "TABLE_NAME": "tblLossControl_Matrix_RCT",
        "INSPECTION_PERIOD": 30,
        "SQL_SERVER_NAME": "CORPSC3HQPCF007.Cinfin.com\\HQ3,4793",
        "DATABASE_NAME": "cld_apps",
        "INCLUDED": True,
        "SOURCE_NAME": "CLD Matrix Package"
    },
    "CLD_MATRIX_WC": {
        "FROM_DATE": "2025/10/1",
        "TO_DATE": "2025/11/30",
        "TABLE_NAME": "LossControlWCMatrix",
        "INSPECTION_PERIOD": 9,
        "SQL_SERVER_NAME": "CORPSC3HQPCF007.Cinfin.com\\HQ3,4793",
        "DATABASE_NAME": "cld_apps",
        "INCLUDED": True,
        "SOURCE_NAME": "CLD Matrix Workers Comp"
    }
}

STRATEGY = "highest_score_first" # ["vanilla", "round_robin", "highest_score_first"]

SCORING_WEIGHTS = {
    "distance": 2,
    "risk_level": 3,
    "due_date": 4,
    "agency": 1,
    "balance": 0
}
