import pandas as pd
from datetime import date, timedelta, datetime
from data_loader.task_source.TaskSource import TaskSource
from model.Task import Task
from config.config import SOURCES
import uuid
from sqlalchemy import create_engine


class CLDPackage(TaskSource):
    def __init__(self):
        self.from_date = datetime.strptime(SOURCES["CLD_MATRIX_PACKAGE"]["FROM_DATE"], "%Y/%m/%d").date()
        self.to_date = datetime.strptime(SOURCES["CLD_MATRIX_PACKAGE"]["TO_DATE"], "%Y/%m/%d").date()
        self.inspection_period = SOURCES["CLD_MATRIX_PACKAGE"]["INSPECTION_PERIOD"]
        self.source_name = "CLD_MATRIX_PACKAGE"
        super().__init__()
        
    def load_data(self) -> pd.DataFrame:
        server = SOURCES["CLD_MATRIX_PACKAGE"]["SQL_SERVER_NAME"]
        database = SOURCES["CLD_MATRIX_PACKAGE"]["DATABASE_NAME"]
        query = "SELECT * FROM " + database + ".dbo." + SOURCES["CLD_MATRIX_PACKAGE"]["TABLE_NAME"]
        connection_string = f'mssql+pyodbc://{server}/{database}?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'   
        engine = create_engine(connection_string)
        df_pkg = pd.read_sql(query, engine)
        df_pkg['task_id'] = [str(uuid.uuid4()) for _ in range(len(df_pkg))]

        return df_pkg

    def filter_valid_tasks(self) -> pd.DataFrame:

        # Ensure date columns are in datetime format
        self.raw_df['Last_Insp_Date'] = pd.to_datetime(self.raw_df['Last_Insp_Date'], errors='coerce')
        self.raw_df['Due_Date'] = pd.to_datetime(self.raw_df['Due_Date'], errors='coerce')

        def is_valid(row) -> bool:
            last_insp = row.get('Last_Insp_Date')
            due = row.get('Due_Date')
            if pd.isna(due):
                return False
            
            # Return False if the 'UW_Unit' column is "Commercial Key General Business" or "Commercial Key Construction"
            if row.get('UW_Unit') in ["Commercial Key General Business", "Commercial Key Construction"]:
                return False
            
            

            month_diff = (due.year - last_insp.year) * 12 + (due.month - last_insp.month)
            # if Due_Date - Last_Insp_Date > inspection_period and Due_Date is within lookahead_days from today, it is valid
            if (pd.isna(last_insp) or month_diff > self.inspection_period) and self.from_date <= due.date() <= self.to_date:
                return True
            # if Due_Date is before today, it is valid
            # if due.date() < today:
            #     return True
            return False

        # Filter out rows where "UW_Unit" is "Commercial Key General Business" or "Commercial Key Construction"
        # self.raw_df = self.raw_df[~self.raw_df['UW_Unit'].isin(["Commercial Key General Business", "Commercial Key Construction"])]

        return self.raw_df[self.raw_df.apply(is_valid, axis=1)]

    def to_task_pool(self):
        df = self.filter_valid_tasks()
        task_list = []
        returned_task_list = []

        for _, row in df.iterrows():
            lat, lon = self.zip_to_lat_lon(row.get('ZIP'))
            try:
                task = Task(
                    task_id=row.get('task_id', str(uuid.uuid4())),
                    policy_number=row.get('Policy_Symbol') + str(row.get('Policy_number')),
                    due_date=row['Due_Date'],
                    au_risk_level=row.get('AU_Risk_Level') if row.get('AU_Risk_Level') in ['1', '2', '3'] else None,
                    gl_risk_level=row.get('GL_Risk_Level') if row.get('GL_Risk_Level') in ['1', '2', '3'] else None,
                    pr_risk_level=row.get('PR_Risk_Level') if row.get('PR_Risk_Level') in ['1', '2', '3'] else None,
                    pl_risk_level=row.get('PL_Risk_Level') if row.get('PL_Risk_Level') in ['1', '2', '3'] else None,
                    wc_risk_level=row.get('WC_Risk_Level') if row.get('WC_Risk_Level') in ['1', '2', '3'] else None,
                    agency_code=row.get('Agency_Code'),
                    last_inspection_group=row.get('Last_Insp_Group'),
                    inspection_type=row.get('Inspection_Frequency', '').split()[-1],
                    address=row.get('Address'),
                    city=row.get('City'),
                    state=row.get('ST'),
                    zip_code=row.get('ZIP'),
                    county=row.get('COUNTY'),
                    latitude=lat,
                    longitude=lon,
                    source=self.source_name,
                    region=self.state_county_to_region(row.get('ST'), row.get('COUNTY')),
                    agency_based_assigned_rep=row.get('LC_Rep'),
                    loc_num=row.get('Loc_Num', None)
                )
                task_list.append(task.model_dump())
                returned_task_list.append(task)
            except Exception as e:
                print(f"[WARN] Skipped row due to error: {e}")

        return pd.DataFrame(task_list), returned_task_list
    
    def get_raw_df(self):
        return self.raw_df
    
    
