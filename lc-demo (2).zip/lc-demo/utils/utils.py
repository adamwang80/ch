import math
import pandas as pd
from typing import Dict, List, Tuple

def compute_distance(lat1, lon1, lat2, lon2):
    # return the distance in miles
    R = 3958.8  # Radius of Earth in miles
    try:
        lat1_rad = math.radians(lat1)
        lon1_rad = math.radians(lon1)
        lat2_rad = math.radians(lat2)
        lon2_rad = math.radians(lon2)

        dlat = lat2_rad - lat1_rad
        dlon = lon2_rad - lon1_rad

        a = math.sin(dlat / 2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        return R * c
    except Exception as e:
        print(lat1, lon1, lat2, lon2, e)


def convert_to_output_format_pandas(assignment_result: Dict[str, List[Tuple[str, float, List[float]]]], rep_dict, task_pool) -> pd.DataFrame:
    output_data = []
    for rep_id, tasks in assignment_result.items():
        rep = rep_dict[rep_id]
        task_assignment_count = len(tasks)
        for task_id, score, sub_scores in tasks:
            task_row = task_pool[task_pool["task_id"] == task_id].iloc[0]
            output_data.append({
                "employee_id": rep_id,
                "rep_name": rep.name,
                "old_assignment": task_row['agency_based_assigned_rep'],
                "rep_task_count": rep.current_task_count,
                "task_count_after_assignment": rep.current_task_count + task_assignment_count,
                "task_due_date": task_row["due_date"],

                "score": score,
                "distance_score": sub_scores[0][0],
                "distance_weight": sub_scores[0][1],
                "risk_level_score": sub_scores[1][0],
                "risk_level_weight": sub_scores[1][1],
                "due_date_score": sub_scores[2][0],
                "due_date_weight": sub_scores[2][1],
                "agency_score": sub_scores[3][0],
                "agency_weight": sub_scores[3][1],
                "balance_score": sub_scores[4][0],
                "balance_weight": sub_scores[4][1],

                "rep_au_level": str(rep.au_level),
                "task_au_risk_level": task_row["au_risk_level"],
                "rep_gl_level": str(rep.gl_level),
                "task_gl_risk_level": task_row["gl_risk_level"],
                "rep_pl_level": str(rep.pl_level),
                "task_pl_risk_level": task_row["pl_risk_level"],
                "rep_pr_level": str(rep.pr_level),
                "task_pr_risk_level": task_row["pr_risk_level"],
                "rep_wc_level": str(rep.wc_level),
                "task_wc_risk_level": task_row["wc_risk_level"],
                "rep_familiar_agencies": rep.familiar_agencies,
                "familiar_agency_count": len(rep.familiar_agencies),
            
                "rep_region": rep.region,
                "rep_team": rep.team,
                "is_rep_key_account": rep.key_account,
                "task_region": task_row["region"],
                
                "rep_address": rep.address,
                "rep_city": rep.city,
                "rep_state": rep.state,
                "rep_zip_code": rep.zip_code,
                "rep_latitude": rep.latitude,
                "rep_longitude": rep.longitude,

                "task_address": task_row["address"],
                "task_city": task_row["city"],
                "task_state": task_row["state"],
                "task_zip_code": task_row["zip_code"],
                "task_county": task_row["county"],
                "task_latitude": task_row["latitude"],
                "task_longitude": task_row["longitude"],
                "distance": compute_distance(rep.latitude, rep.longitude, task_row["latitude"], task_row["longitude"]),

                "task_source": task_row["source"],
                
                "task_agency_code": task_row["agency_code"],
                "task_last_inspection_group": task_row["last_inspection_group"],
                "task_inspection_type": task_row["inspection_type"],              
            })

    return pd.DataFrame(output_data)


def get_rep_assignment_summary(output_result: pd.DataFrame) -> pd.DataFrame:
    assignment_summary = output_result.groupby("rep_name").agg(
        key_account=("is_rep_key_account", "first"),
        rep_team=("rep_team", "first"),
        task_count=("rep_task_count", "first"),
        task_count_after_assignment=("task_count_after_assignment", "first"),
        average_distance=("distance", "mean"),
        average_distance_onsite=("distance", lambda x: x[output_result.loc[x.index, "task_inspection_type"] == "On-Site"].mean()),
        average_distance_virtual=("distance", lambda x: x[output_result.loc[x.index, "task_inspection_type"] == "Virtual"].mean()),
        number_of_active_requirements=("rep_name", lambda x: output_result.loc[
            (output_result.index.isin(x.index)) & (
                (output_result["task_au_risk_level"].notna()) | 
                (output_result["task_gl_risk_level"].notna()) | 
                (output_result["task_pl_risk_level"].notna()) | 
                (output_result["task_pr_risk_level"].notna()) | 
                (output_result["task_wc_risk_level"].notna())
            )
        ].shape[0]),
        number_of_overqualified_by_one=("rep_name", lambda x: output_result.loc[
            (output_result.index.isin(x.index)) & (
                ((output_result["rep_au_level"].astype(float) == output_result["task_au_risk_level"].astype(float) + 1) & output_result["task_au_risk_level"].notna()) |
                ((output_result["rep_gl_level"].astype(float) == output_result["task_gl_risk_level"].astype(float) + 1) & output_result["task_gl_risk_level"].notna()) |
                ((output_result["rep_pl_level"].astype(float) == output_result["task_pl_risk_level"].astype(float) + 1) & output_result["task_pl_risk_level"].notna()) |
                ((output_result["rep_pr_level"].astype(float) == output_result["task_pr_risk_level"].astype(float) + 1) & output_result["task_pr_risk_level"].notna()) |
                ((output_result["rep_wc_level"].astype(float) == output_result["task_wc_risk_level"].astype(float) + 1) & output_result["task_wc_risk_level"].notna())
            )
        ].shape[0]),
        number_of_overqualified_by_two=("rep_name", lambda x: output_result.loc[
            (output_result.index.isin(x.index)) & (
                ((output_result["rep_au_level"].astype(float) == output_result["task_au_risk_level"].astype(float) + 2) & output_result["task_au_risk_level"].notna()) |
                ((output_result["rep_gl_level"].astype(float) == output_result["task_gl_risk_level"].astype(float) + 2) & output_result["task_gl_risk_level"].notna()) |
                ((output_result["rep_pl_level"].astype(float) == output_result["task_pl_risk_level"].astype(float) + 2) & output_result["task_pl_risk_level"].notna()) |
                ((output_result["rep_pr_level"].astype(float) == output_result["task_pr_risk_level"].astype(float) + 2) & output_result["task_pr_risk_level"].notna()) |
                ((output_result["rep_wc_level"].astype(float) == output_result["task_wc_risk_level"].astype(float) + 2) & output_result["task_wc_risk_level"].notna())
            )
        ].shape[0]),
        number_of_underqualified_by_one=("rep_name", lambda x: output_result.loc[
            (output_result.index.isin(x.index)) & (
                ((output_result["rep_au_level"].astype(float) + 1 == output_result["task_au_risk_level"].astype(float)) & output_result["task_au_risk_level"].notna()) |
                ((output_result["rep_gl_level"].astype(float) + 1 == output_result["task_gl_risk_level"].astype(float)) & output_result["task_gl_risk_level"].notna()) |
                ((output_result["rep_pl_level"].astype(float) + 1 == output_result["task_pl_risk_level"].astype(float)) & output_result["task_pl_risk_level"].notna()) |
                ((output_result["rep_pr_level"].astype(float) + 1 == output_result["task_pr_risk_level"].astype(float)) & output_result["task_pr_risk_level"].notna()) |
                ((output_result["rep_wc_level"].astype(float) + 1 == output_result["task_wc_risk_level"].astype(float)) & output_result["task_wc_risk_level"].notna())
            )
        ].shape[0]),
        number_of_qualification_match=("rep_name", lambda x: output_result.loc[
            (output_result.index.isin(x.index)) & (
                ((output_result["rep_au_level"].astype(float) == output_result["task_au_risk_level"].astype(float)) & output_result["task_au_risk_level"].notna()) |
                ((output_result["rep_gl_level"].astype(float) == output_result["task_gl_risk_level"].astype(float)) & output_result["task_gl_risk_level"].notna()) |
                ((output_result["rep_pl_level"].astype(float) == output_result["task_pl_risk_level"].astype(float)) & output_result["task_pl_risk_level"].notna()) |
                ((output_result["rep_pr_level"].astype(float) == output_result["task_pr_risk_level"].astype(float)) & output_result["task_pr_risk_level"].notna()) |
                ((output_result["rep_wc_level"].astype(float) == output_result["task_wc_risk_level"].astype(float)) & output_result["task_wc_risk_level"].notna())
            )
        ].shape[0]),
        average_risk_level_score=("risk_level_score", "mean"),
        average_distance_to_due_date=("task_due_date", lambda x: (pd.to_datetime(x) - pd.Timestamp.now()).dt.days.mean()),
        past_due_count=("task_due_date", lambda x: (pd.to_datetime(x) < pd.Timestamp.now()).sum()),
        due_within_five_days_count=("task_due_date", lambda x: ((pd.to_datetime(x) - pd.Timestamp.now()).dt.days <= 5).sum()),
        average_due_date_score=("due_date_score", "mean"),
        average_agency_score=("agency_score", "mean"),
        average_score=("score", "mean"),
    ).reset_index()

    return assignment_summary

def convert_to_test_output_format_pandas(assignment_result: Dict[str, List[Tuple[str, float, List[float]]]], rep_dict, task_pool) -> pd.DataFrame:
    output_data = []
    for rep_id, tasks in assignment_result.items():
        rep = rep_dict[rep_id]
        task_assignment_count = len(tasks)
        for task_id, score, sub_scores in tasks:
            task_row = task_pool[task_pool["task_id"] == task_id].iloc[0]
            output_data.append({
                "engine_assignment": rep.name,
                "engine_assignment_employee_id": rep_id,
                "task_due_date": task_row["due_date"],

                "policy_number": task_row["policy_number"],
                "task_id": task_row["task_id"],

                "task_loc_num": task_row["loc_num"],

                "engine_score": score,
                "engine_distance_score": sub_scores[0][0],
                "engine_risk_level_score": sub_scores[1][0],
                "engine_due_date_score": sub_scores[2][0],
                "engine_agency_score": sub_scores[3][0],
                "engine_balance_score": sub_scores[4][0],
            
                "engine_assigned_rep_region": rep.region,
                "engine_assigned_rep_team": rep.team,
                "is_rep_key_account": rep.key_account,
                "task_region": task_row["region"],

                "distance": compute_distance(rep.latitude, rep.longitude, task_row["latitude"], task_row["longitude"]),
                
                "engine_assigned_rep_au_level": str(rep.au_level),
                "task_au_risk_level": task_row["au_risk_level"],
                "engine_assigned_rep_gl_level": str(rep.gl_level),
                "task_gl_risk_level": task_row["gl_risk_level"],
                "engine_assigned_rep_pl_level": str(rep.pl_level),
                "task_pl_risk_level": task_row["pl_risk_level"],
                "engine_assigned_rep_pr_level": str(rep.pr_level),
                "task_pr_risk_level": task_row["pr_risk_level"],
                "engine_assigned_rep_wc_level": str(rep.wc_level),
                "task_wc_risk_level": task_row["wc_risk_level"],

                "task_source": task_row["source"],
                "task_address": task_row["address"],
                "task_city": task_row["city"],
                "task_state": task_row["state"],
                "task_zip_code": task_row["zip_code"],
                "task_county": task_row["county"],
                "task_latitude": task_row["latitude"],
                "task_longitude": task_row["longitude"],
                "engine_assignment_distance": compute_distance(rep.latitude, rep.longitude, task_row["latitude"], task_row["longitude"]),

                "task_last_inspection_group": task_row["last_inspection_group"],
                "task_inspection_type": task_row["inspection_type"],              
            })

    return pd.DataFrame(output_data)