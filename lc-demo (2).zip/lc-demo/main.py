from engine.Engine import Engine
import pandas as pd
import re

def main():
    engine = Engine()
    engine.load_task_data_sources()

    # 保存 CSV 文件
    engine.task_pool.to_csv("task_pool.csv", index=False)

    if "CLD_MATRIX_WC" in engine.task_raw_data:
        engine.task_raw_data["CLD_MATRIX_WC"].to_csv("cld_matrix_wc.csv", index=False)

    if "CLD_MATRIX_PACKAGE" in engine.task_raw_data:
        engine.task_raw_data["CLD_MATRIX_PACKAGE"].to_csv("cld_matrix_package.csv", index=False)

    # 清理非法字符后保存 Excel 文件
    if "CLD_MATRIX_PACKAGE" in engine.task_raw_data:
        df_cleaned_package = remove_illegal_chars(engine.task_raw_data["CLD_MATRIX_PACKAGE"])
        df_cleaned_package.to_excel("cld_matrix_package.xlsx", index=False)

    if "CLD_MATRIX_WC" in engine.task_raw_data:
        df_cleaned_wc = remove_illegal_chars(engine.task_raw_data["CLD_MATRIX_WC"])
        df_cleaned_wc.to_excel("cld_matrix_wc.xlsx", index=False)


def remove_illegal_chars(df):
    # 定义非法字符的正则表达式（ASCII 控制字符范围）
    illegal_chars = re.compile(r'[\x00-\x1F\x7F]')
    return df.applymap(lambda x: illegal_chars.sub('', x) if isinstance(x, str) else x)



    # result = engine.output_result

    # # output result to output.csv
    # result.to_csv("output.csv", index=False)
   
    

if __name__ == "__main__":
    main()


