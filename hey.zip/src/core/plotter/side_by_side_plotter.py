from core.plotter.base_plotter import BasePlotter
import numpy as np
from PIL import Image
import rasterio
from matplotlib import cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
import os
from matplotlib.gridspec import GridSpec
import logging
from typing import List, Tuple, Optional, Union
from config import VisualizationConfig, DataProcessingConfig, BUILDING_IMAGE_DIR, CANOPY_HEIGHT_IMAGE_DIR, CHM_LOCAL_CROP_FILES_DIR, ARTIFACTS_DIR, SIDE_BY_SIDE_IMAGE_DIR, MODEL_OUTPUT_DIR

# Set up logging
logger = logging.getLogger(__name__)

class SideBySidePlotter(BasePlotter):

    def __init__(self):
        self.directories = [
            SIDE_BY_SIDE_IMAGE_DIR
        ]
        super().__init__()

    def run(self, bounding_box: list, method: str, building_image_source:str, canopy_threshold: float = None, dpi: int = None, model_id: str = None) -> None:
        """
        Create overlay image combining satellite image with canopy height data
        
        Args:
            canopy_threshold: Minimum canopy height to display
            alpha: Transparency level for overlay (0-1)
        
        Returns:
            Path to the created overlay image
        """
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        satellite_image_file = f"{BUILDING_IMAGE_DIR}/{building_image_source}/{bbox_filename}.png"
        output_file = f"{SIDE_BY_SIDE_IMAGE_DIR}/{method}_{building_image_source}_{bbox_filename}_side_by_side.png"

        if method == "chm":
            canopy_height_file = f"{ARTIFACTS_DIR}/{method}/canopy_height_outputs/{bbox_filename}.tif"
        elif method == "model":
            canopy_height_file = f"{MODEL_OUTPUT_DIR}/{model_id}/{bbox_filename}.tif"

        if canopy_threshold is None:
            canopy_threshold = VisualizationConfig.DEFAULT_CANOPY_THRESHOLD
        if dpi is None:
            dpi = VisualizationConfig.DPI

        logger.info(f"Creating overlay image: {output_file}")

        # Read satellite image - keep original quality
        satellite_img = Image.open(satellite_image_file)
        satellite_img = satellite_img.convert('RGB')

        # Load canopy height data
        with rasterio.open(canopy_height_file) as src:
            canopy_data = src.read(1)
            bounds = src.bounds

        # Clean and normalize canopy data
        canopy_data = self.clean_canopy_data(canopy_data)
        canopy_data = np.where(canopy_data >= canopy_threshold, canopy_data, np.nan)

        # Resize canopy data to match satellite image size
        canopy_img = Image.fromarray(np.nan_to_num(canopy_data).astype(np.float32))
        canopy_img = canopy_img.resize(satellite_img.size, Image.BICUBIC)
        canopy_array = np.array(canopy_img).astype(float)
        canopy_array[canopy_array > VisualizationConfig.CANOPY_NODATA_THRESHOLD] = np.nan

        # Create figure with GridSpec
        fig = plt.figure(figsize=VisualizationConfig.FIGURE_SIZE)
        gs = GridSpec(1, 3, width_ratios=[1, 1, 0.05], wspace=0.05)

        # Plot satellite image
        ax1 = fig.add_subplot(gs[0])
        ax1.imshow(satellite_img)
        ax1.set_title("Satellite Image")
        ax1.axis('off')

        # Plot canopy height with colormap
        ax2 = fig.add_subplot(gs[1])
        im = ax2.imshow(
            canopy_array, 
            cmap=VisualizationConfig.CANOPY_COLORMAP, 
            vmax=np.nanpercentile(canopy_array, 98)
        )
        ax2.set_title("Canopy Height")
        ax2.axis('off')

        # Add colorbar
        cax = fig.add_subplot(gs[2])
        cbar = fig.colorbar(im, cax=cax)
        cbar.set_label("Canopy Height [meters]")

        # Ensure output directory exists and save
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        plt.savefig(output_file, dpi=dpi, bbox_inches='tight')
        plt.close()

        logger.info(f"Side-by-side comparison saved: {output_file}")
        return output_file

    