from core.model_image_downloader.base_model_image_downloader import BaseModelImageDownloader
from config import MODEL_IMAGE_DIR
import os
import requests
from PIL import Image
import numpy as np
import rasterio
from rasterio.transform import from_origin
import logging
from typing import List, Tuple
from dotenv import load_dotenv
import io
import math

load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class GoogleMapsModelImageDownloader(BaseModelImageDownloader):
    MAX_SIZE = 640

    def __init__(self):
        self.directories = [f"{MODEL_IMAGE_DIR}/google_maps"]
        super().__init__()

    def _latlon_to_world_pixels(self, lat: float, lon: float, zoom: int) -> Tuple[float, float]:
        """Converts lat/lon degrees to world pixel coordinates at a given zoom level."""
        world_dim = 256 * (2**zoom)
        sin_lat = math.sin(math.radians(lat))
        x = (lon + 180) * (world_dim / 360)
        # The y-coordinate is based on the Mercator projection.
        y = (0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * world_dim
        return x, y

    def _world_pixels_to_latlon(self, x: float, y: float, zoom: int) -> Tuple[float, float]:
        """Converts world pixel coordinates to lat/lon degrees at a given zoom level."""
        world_dim = 256 * (2**zoom)
        lon = (x / world_dim) * 360 - 180
        n = math.pi - (2 * math.pi * y) / world_dim
        lat = math.degrees(math.atan(math.sinh(n)))
        return lat, lon

    def run(self, bounding_box: List[float], zoom_level: int) -> str:
        """
        Downloads a satellite image for a given bounding box and zoom level.
        If the required image size exceeds API limits, it automatically
        downloads and stitches tiles seamlessly.
        """
        top_lat, left_lon = max(bounding_box[0], bounding_box[2]), min(bounding_box[1], bounding_box[3])
        bottom_lat, right_lon = min(bounding_box[0], bounding_box[2]), max(bounding_box[1], bounding_box[3])

        # Get the pixel coordinates of the bounding box corners
        top_left_px_x, top_left_px_y = self._latlon_to_world_pixels(top_lat, left_lon, zoom_level)
        bottom_right_px_x, bottom_right_px_y = self._latlon_to_world_pixels(bottom_lat, right_lon, zoom_level)

        # Calculate the total required image size in pixels
        total_width = int(round(bottom_right_px_x - top_left_px_x))
        total_height = int(round(bottom_right_px_y - top_left_px_y))

        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        filename = f"{bbox_filename}_z{zoom_level}_{total_width}x{total_height}.tif"
        output_path = os.path.join(self.directories[0], filename)
        
        if os.path.exists(output_path):
            logger.info(f"Image already exists: {output_path}")
            return output_path
        
        os.makedirs(self.directories[0], exist_ok=True)

        if total_width <= self.MAX_SIZE and total_height <= self.MAX_SIZE:
            # Download as a single image if within size limits
            center_px_x = top_left_px_x + total_width / 2
            center_px_y = top_left_px_y + total_height / 2
            center_lat, center_lon = self._world_pixels_to_latlon(center_px_x, center_px_y, zoom_level)
            img = self._download_image(center_lat, center_lon, zoom_level, total_width, total_height)
        else:
            # Download and stitch tiles if size limit is exceeded
            logger.info(f"Required image size ({total_width}x{total_height}) exceeds {self.MAX_SIZE}px limit. Tiling requests.")
            img = self._download_and_stitch_tiles(top_left_px_x, top_left_px_y, total_width, total_height, zoom_level)
            
        return self._save_as_geotiff(img, bounding_box, output_path)

    def _download_and_stitch_tiles(self, top_left_px_x: float, top_left_px_y: float, total_width: int, total_height: int, zoom_level: int) -> Image.Image:
        """Downloads and stitches tiles based on world pixel coordinates."""
        stitched_image = Image.new('RGB', (total_width, total_height))

        num_tiles_x = math.ceil(total_width / self.MAX_SIZE)
        num_tiles_y = math.ceil(total_height / self.MAX_SIZE)

        for i in range(num_tiles_y):
            for j in range(num_tiles_x):
                # Calculate the size of the current tile
                tile_width = min(self.MAX_SIZE, total_width - j * self.MAX_SIZE)
                tile_height = min(self.MAX_SIZE, total_height - i * self.MAX_SIZE)

                if tile_height <= 0 or tile_width <= 0:
                    continue

                # Calculate the center of the tile in world pixel coordinates
                center_px_x = top_left_px_x + j * self.MAX_SIZE + tile_width / 2
                center_px_y = top_left_px_y + i * self.MAX_SIZE + tile_height / 2

                # Convert the tile center back to lat/lon for the API request
                tile_center_lat, tile_center_lon = self._world_pixels_to_latlon(center_px_x, center_px_y, zoom_level)

                logger.info(f"Downloading tile ({i},{j}) of size {tile_width}x{tile_height}")
                tile_img = self._download_image(tile_center_lat, tile_center_lon, zoom_level, tile_width, tile_height)
                
                # Paste the tile into the final image at the correct position
                x_paste = j * self.MAX_SIZE
                y_paste = i * self.MAX_SIZE
                stitched_image.paste(tile_img, (x_paste, y_paste))

        return stitched_image

    def _download_image(self, center_lat: float, center_lon: float, zoom_level: int, width: int, height: int) -> Image.Image:
        """Downloads a single image from the Google Maps API."""
        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")

        params = {
            'center': f"{center_lat},{center_lon}",
            'zoom': zoom_level,
            'size': f"{width}x{height}",
            'maptype': 'satellite',
            'key': api_key,
            'style': 'feature:all|element:labels|visibility:off' # No labels
        }

        response = requests.get("https://maps.googleapis.com/maps/api/staticmap", params=params, timeout=60)
        response.raise_for_status()
        
        return Image.open(io.BytesIO(response.content)).convert("RGB")

    def _save_as_geotiff(self, img: Image.Image, bounding_box: List[float], output_path: str) -> str:
        """Saves the final image as a georeferenced TIFF."""
        img_np = np.array(img)
        height, width, _ = img_np.shape
        
        lat1, lon1, lat2, lon2 = bounding_box
        top_lat = max(lat1, lat2)
        left_lon = min(lon1, lon2)
        
        lon_span = abs(lon1 - lon2)
        lat_span = abs(lat1 - lat2)
        
        # Create a transform using the bounding box and final image size
        transform = from_origin(left_lon, top_lat, lon_span / width, lat_span / height)
        
        with rasterio.open(
            output_path,
            'w',
            driver='GTiff',
            height=height,
            width=width,
            count=3,
            dtype=img_np.dtype,
            transform=transform,
            crs='EPSG:4326' # WGS84
        ) as dst:
            for i in range(3):
                dst.write(img_np[:, :, i], i + 1)
        
        logger.info(f"Successfully saved GeoTIFF: {output_path}")
        return output_path
