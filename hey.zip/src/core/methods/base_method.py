from abc import ABC, abstractmethod
import logging
import os

logger = logging.getLogger(__name__)

class BaseMethodEngine(ABC):
    """
    Abstract base class for all methods.
    """

    @abstractmethod
    def __init__(self, *args, **kwargs):
        self._ensure_directories()

    @abstractmethod
    def run(self, *args, **kwargs):
        pass
    
    def _ensure_directories(self) -> None:
        if self.directories:        
            for directory in self.directories:
                if not os.path.exists(directory):
                    os.makedirs(directory, exist_ok=True)
                    logger.info(f"Created directory: {directory}")