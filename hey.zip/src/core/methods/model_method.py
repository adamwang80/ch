import logging
import numpy as np
import matplotlib.pyplot as plt
import os
from tqdm.notebook import tqdm

import boto3
from botocore import UNSIGNED
from botocore.config import Config

import rasterio
from rasterio.windows import Window

import torch
from torch.utils.data import DataLoader, Dataset
torch.backends.quantized.engine = 'qnnpack'
import pytorch_lightning as pl

from typing import List, Tuple, Optional, Dict, Any

#local modules
import sys
# sys.path.append('../')
# import src.transforms as transforms
# import src.raster_utils as raster_utils
# from inference import SSLAE
from core.utils.model_utils.inference import SSLAE
import core.utils.model_utils.src.transforms as transforms
import core.utils.model_utils.src.raster_utils as raster_utils


from config import (MODEL_ID, LOCAL_MODEL_DIR, S3_MODEL_DIR, S3_MODEL_BUCKET, MODEL_OUTPUT_DIR, MODEL_SIDE_BY_SIDE_IMAGE_DIR)
from core.methods.base_method import BaseMethodEngine
from core.model_image_downloader.google_maps_model_image_downloader import GoogleMapsModelImageDownloader

logger = logging.getLogger(__name__)

class CustomImageDataset(Dataset):
    def __init__(self, stack, transform=None) -> None:
        self.len = stack.shape[0]
        self.transform = transform
        self.stack = stack
        self.im_shape = stack.shape[1:]

    def __len__(self):
        return self.len

    def __getitem__(self, idx):
        self.idx = idx
        im = self.stack[idx]
        if self.transform:
            im = self.transform(im)

        data = {"image": im}
        return data

class SSLModule3(pl.LightningModule):
    def __init__(self, path, classify=True, map_location="cpu"):
        super().__init__()
        self.translation_invariant_mse_loss = False
        ckpt = torch.load(path, map_location=map_location)
        self.chm_module_ = SSLAE(classify=classify, huge=True).eval()
        self.chm_module_ = torch.quantization.quantize_dynamic(
            self.chm_module_,
            {torch.nn.Linear, torch.nn.Conv2d, torch.nn.ConvTranspose2d},
            dtype=torch.qint8,
        )
        self.chm_module_.load_state_dict(ckpt, strict=False)

    def predict(self, batch):
        device = next(self.chm_module_.parameters()).device
        x = batch["image"].to(device)
        outputs = self.chm_module_(x)
        pred = 10 * outputs + 0.001
        pred = pred.relu()
        return pred, outputs

class ModelMethodEngine(BaseMethodEngine):
    def __init__(self, image_vendor: str = "google_maps", model_id: str = MODEL_ID):
        self.directories = [LOCAL_MODEL_DIR, f"{MODEL_OUTPUT_DIR}/{model_id}", MODEL_SIDE_BY_SIDE_IMAGE_DIR]
        super().__init__()
        self.image_vendor = image_vendor
        self.model_id = model_id
        self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))

        self.model_image_downloader = GoogleMapsModelImageDownloader()

    def run(self, bounding_box: list, window_size: int = 448, zoom_level: int = 19) -> None:

        self.get_model()
        local_rgb_file = self.model_image_downloader.run(
            bounding_box=bounding_box,
            zoom_level=zoom_level
        )

        local_model_file = f"{LOCAL_MODEL_DIR}/{self.model_id}.pth"
        model=SSLModule3(local_model_file)
        model.eval()

        model_output_file = f"{MODEL_OUTPUT_DIR}/{self.model_id}/{'_'.join(map(str, bounding_box))}.tif"

        chm_path=self.windowed_infer_loop(local_rgb_file, model, window_size=window_size, out_path=model_output_file)

        side_by_side_file = f"{MODEL_SIDE_BY_SIDE_IMAGE_DIR}/{self.model_id}_{self.image_vendor}_{local_rgb_file.split('/')[-1].replace('.png', '')}_side_by_side.png"
        #save result to file
        with rasterio.open(local_rgb_file) as src:
            data = src.read()
            image = np.moveaxis(data[0:3], 0, -1)
        with rasterio.open(chm_path) as src:
            chm = src.read().squeeze()
        
        fig, ax = plt.subplots(1, 2, figsize=(16, 6))
        ax[0].imshow(image)
        ax[0].set_title('input RGB')
        ax[1].imshow(chm, vmin=0, vmax=15)
        ax[1].set_title('Canopy Height')
        
        plt.savefig(side_by_side_file)
        plt.close(fig)
    
    def get_center_lat_lon(self, bounding_box: List[float]) -> Tuple[float, float]:
        """Get the center latitude and longitude from bounding box"""
        lat1, lon1, lat2, lon2 = bounding_box
        center_lat = (lat1 + lat2) / 2
        center_lon = (lon1 + lon2) / 2
        return center_lat, center_lon
    
    def get_model(self):
        bucket='dataforgood-fb-data'
        localdir='data'
        s3file=f"{S3_MODEL_DIR}/{self.model_id}.pth"
        local_model_file=f"{LOCAL_MODEL_DIR}/{self.model_id}.pth"
        if not os.path.exists(local_model_file):
            self.s3_client.download_file(S3_MODEL_BUCKET, s3file, local_model_file)

    
    def run_inference_blocks(self, img, model, winsize=256):
    
        print(f"Running inference on image block of shape: {img.shape}")

        h, w = img.shape[:2]
        pad_h = (winsize - h % winsize) % winsize
        pad_w = (winsize - w % winsize) % winsize
        
        if pad_h > 0 or pad_w > 0:
            img_padded = np.pad(img, ((0, pad_h), (0, pad_w), (0, 0)), mode='reflect')
            print(f"Padded image shape: {img_padded.shape}")
        else:
            img_padded = img

        #this is how we breakup large images into batches for model inference
        step = int(winsize * 3 / 4)
        print(f"Blocking with window size: {winsize}, step: {step}")
        stack, vx, vy = raster_utils.blocking(img_padded, (winsize, winsize, 3), step)

        transform = transforms.SSLNorm().Trans

        data = CustomImageDataset(stack, transform=transform)
        dl = DataLoader(data, shuffle=False, batch_size=stack.shape[0])
        batch = next(iter(dl))
        
        output, _ = model.predict(batch)
        weight = raster_utils.create_apodization((winsize, winsize))

        pred_stack = output.detach().numpy().squeeze()
        pred_stack = np.expand_dims(pred_stack, -1)
        out_size = img_padded.shape[0:2]
        pred_im, weights = raster_utils.inverse_blocking(
            pred_stack, out_size, winsize, weight, step, vx, vy
        )
        
        # if original image was padded, crop back to original size
        if pad_h > 0 or pad_w > 0:
            pred_im = pred_im[:h, :w]
        
        pred_im = pred_im.squeeze()
        return pred_im


    def windowed_infer_loop(self, image_path, model, out_path=None, window_size=448):
        #suggested window sizes: 448, 1024
        if not out_path:
            out_path=image_path.replace('.tif', '_chm.tif')
        with rasterio.open(image_path) as src:
            print(f"Image size: {src.width} x {src.height}")
            meta=src.meta
            meta.update({'count':1,
                        "dtype": np.float32,
                        "driver":'GTiff',
                        "nodata": np.nan,
                        })
            with rasterio.open(out_path, 'w', **meta) as dst:
                # Generate coordinates for windowed processing.
                # This logic robustly handles images smaller than the window size.
                if src.height > window_size:
                    row_coords = list(np.arange(0, src.height - window_size, window_size)) + [src.height - window_size]
                else:
                    row_coords = [0]

                if src.width > window_size:
                    col_coords = list(np.arange(0, src.width - window_size, window_size)) + [src.width - window_size]
                else:
                    col_coords = [0]

                # Ensure coordinates are unique and sorted to prevent redundant processing
                row_coords = sorted(list(set(row_coords)))
                col_coords = sorted(list(set(col_coords)))

                for row in tqdm(row_coords, desc="inference_progress", position=0):
                    for col in col_coords:
                        # Define window, ensuring it doesn't exceed raster bounds
                        win_height = min(window_size, src.height - row)
                        win_width = min(window_size, src.width - col)
                        
                        window = Window(col, row, win_width, win_height)
                        
                        data = src.read(window=window)
                        mask = src.read_masks(1, window=window)
                        image = np.moveaxis(data, 0, -1)
                        
                        # run_inference_blocks can handle non-square images due to its internal padding
                        chm_block = self.run_inference_blocks(image, model)
                        chm_block = chm_block.astype(meta['dtype'])
                        
                        # The mask from rasterio is 0 for nodata, 255 for data.
                        chm_block[mask == 0] = meta['nodata']
                        
                        dst.write(chm_block, window=window, indexes=1)
                
        return out_path