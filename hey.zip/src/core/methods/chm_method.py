from core.methods.base_method import BaseMethodEngine
from config import (
    CHM_METHOD_ARTIFACTS_DIR,
    TARGET_PLOY_FILE_DIR,
    LOCAL_CHM_DIR,
    CHM_LOCAL_CROP_FILES_DIR,
    LOCAL_TIF_DIR,
    LOCAL_MSK_DIR,
    LOCAL_META_DIR,
    S3_CHM_PATH,
    S3_MSK_PATH,
    S3_META_PATH,
    S3_TILE_DATA_PATH,
    S3_BUCKET,
    S3_MAX_RETRIES,
    S3_RETRY_DELAY,
    LOCAL_TILES_DATA_PATH,
    DataProcessingConfig
)
import logging
from typing import List, Tuple, Optional, Dict, Any
import json
import geopandas as gp
import shutil
import os
import time
import boto3
from botocore import UNSIGNED
from botocore.config import Config
import rasterio
from rasterio.merge import merge
import rasterio.mask


logger = logging.getLogger(__name__)

class CHMMethodEngine(BaseMethodEngine):

    def __init__(self):
        self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
        self.directories = [
            CHM_METHOD_ARTIFACTS_DIR,
            TARGET_PLOY_FILE_DIR,
            LOCAL_CHM_DIR,
            CHM_LOCAL_CROP_FILES_DIR
        ]
        super().__init__()
        self._initialize_tiles()
    
    def _initialize_tiles(self) -> None:
        """Initialize tile data from S3 or local file"""
        if not os.path.exists(LOCAL_TILES_DATA_PATH):
            self._download_s3_file(S3_TILE_DATA_PATH, LOCAL_TILES_DATA_PATH)
        
        self.tiles = gp.read_file(LOCAL_TILES_DATA_PATH)
        self.tiles = self.tiles.set_crs(DataProcessingConfig.DEFAULT_CRS)
        logger.info(f"Loaded {len(self.tiles)} tiles")
    
    def run(self, bounding_box: List[float], data_source: str = "aws") -> str:
        self.get_crop_file(bounding_box, data_source)

    def get_crop_file(self, bounding_box: List[float], data_source: str = "aws") -> str:
        # Create target polygon file
        target_polyfile = self._create_target_polyfile(bounding_box)
        
        # Get intersecting tiles
        target_tiles = self._get_intersecting_tiles(target_polyfile)
        
        # Download and process tiles
        tifs = self._process_tiles(target_tiles, data_source)
        
        # Merge tiles
        mergefile = self._merge_tiles(tifs, target_tiles)
        
        # Crop to bounding box
        cropfile = self._crop_to_bounding_box(mergefile, target_polyfile, bounding_box)
        
        return cropfile
    
    def _create_target_polyfile(self, bounding_box: List[float]) -> str:
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        target_polyfile = f"{TARGET_PLOY_FILE_DIR}/{bbox_filename}.geojson"

        geojson = self.bounding_box_to_geojson(bounding_box)
        with open(target_polyfile, 'w') as f:
            json.dump(geojson, f)
        logger.info(f"Created target polygon file: {target_polyfile}")
        
        return target_polyfile
    
    def _get_intersecting_tiles(self, target_polyfile: str) -> gp.GeoDataFrame:
        """Get tiles that intersect with target area"""
        target = gp.read_file(target_polyfile)
        target = target.set_crs(DataProcessingConfig.DEFAULT_CRS)
        target_tiles = gp.sjoin(self.tiles, target)
        logger.info(f"Found {len(target_tiles)} intersecting tiles")
        return target_tiles

    def bounding_box_to_geojson(self, bbox: List[float]) -> Dict[str, Any]:
        lat1, lon1, lat2, lon2 = bbox
        south, north, west, east = min(lat1, lat2), max(lat1, lat2), min(lon1, lon2), max(lon1, lon2)

        coordinates = [[
            [west, south],
            [east, south],
            [east, north],
            [west, north],
            [west, south]
        ]]

        geojson = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": coordinates
            },
            "properties": {}
        }

        return geojson

    def _process_tiles(self, target_tiles: gp.GeoDataFrame, data_source: str) -> List[str]:
        """Download and process tiles based on data source"""
        tifs = []
        tile_numbers = []
        
        for ii, row in target_tiles.iterrows():
            tile_numbers.append(row.tile)
            
            if data_source == "aws":
                tif_file = self._process_aws_tile(row)
            elif data_source == "local":
                tif_file = self._process_local_tile(row)
            else:
                raise ValueError(f"Unsupported data source: {data_source}")
            
            tifs.append(tif_file)
        
        logger.info(f"Processed {len(tifs)} tiles")
        return tifs
    
    def _process_aws_tile(self, row: Any) -> str:
        """Process a single AWS tile"""
        tile = row.tile
        
        # Download CHM file
        s3file = f"{S3_CHM_PATH}/{tile}.tif"
        localfile = f"{LOCAL_CHM_DIR}/{os.path.basename(s3file)}"
        self._download_s3_file(s3file, localfile)
        
        # Download cloud mask
        mskfile = f"{S3_MSK_PATH}/{tile}.tif.msk"
        localmskfile = f"{LOCAL_CHM_DIR}/{os.path.basename(mskfile)}"
        self._download_s3_file(mskfile, localmskfile)
        
        # Download metadata
        jsonfile = f"{S3_META_PATH}/{tile}.geojson"
        localjsonfile = f"{LOCAL_CHM_DIR}/{os.path.basename(jsonfile)}"
        self._download_s3_file(jsonfile, localjsonfile)
        
        # Apply mask
        outfile = localfile.replace('.tif', 'masked.tif')
        if not os.path.exists(outfile):
            self.enforce_mask(localfile, outfile)
        
        return outfile
    
    def _process_local_tile(self, row: Any) -> str:
        """Process a single local tile"""
        tile = row.tile
        
        # Copy CHM file
        localfile = f"{LOCAL_CHM_DIR}/{tile}.tif"
        if not os.path.exists(localfile):
            logger.info(f"Copying {tile}.tif to {localfile}")
            shutil.copy(f"{LOCAL_TIF_DIR}/{tile}.tif", localfile)
        
        # Copy cloud mask
        localmskfile = f"{LOCAL_CHM_DIR}/{tile}.tif.msk"
        if not os.path.exists(localmskfile):
            logger.info(f"Copying {tile}.tif.msk to {localmskfile}")
            shutil.copy(f"{LOCAL_MSK_DIR}/{tile}.tif.msk", localmskfile)
        
        # Copy metadata
        localjsonfile = f"{LOCAL_CHM_DIR}/{tile}.geojson"
        if not os.path.exists(localjsonfile):
            logger.info(f"Copying {tile}.geojson to {localjsonfile}")
            shutil.copy(f"{LOCAL_META_DIR}/{tile}.geojson", localjsonfile)
        
        # Apply mask
        outfile = f"{LOCAL_CHM_DIR}/{tile}masked.tif"
        if not os.path.exists(outfile):
            self.enforce_mask(localfile, outfile)
        
        return outfile
    
    def _download_s3_file(self, s3_key: str, local_path: str) -> None:
        """Download file from S3 with retry logic"""
        if not os.path.exists(local_path):
            print(f"File {local_path} does not exist, downloading from S3...")
            logger.info(f"Downloading {s3_key} to {local_path}")
            for attempt in range(S3_MAX_RETRIES):
                try:
                    self.s3_client.download_file(S3_BUCKET, s3_key, local_path)
                    return
                except Exception as e:
                    logger.warning(f"Failed to download {s3_key} (attempt {attempt + 1}): {e}")
                    if attempt == S3_MAX_RETRIES - 1:
                        raise
                    time.sleep(S3_RETRY_DELAY)
    
    def _merge_tiles(self, tifs: List[str], target_tiles: gp.GeoDataFrame) -> str:
        """Merge multiple tile files into one"""
        tile_numbers = [row.tile for _, row in target_tiles.iterrows()]
        tile_numbers_str = '_'.join(tile_numbers)
        mergefile = f"{LOCAL_CHM_DIR}/{tile_numbers_str}_alltiles.tif"
        
        if not os.path.exists(mergefile):
            logger.info(f"Merging {len(tifs)} tiles into {mergefile}")
            self.merge_rasters(tifs, outfile=mergefile)
        
        return mergefile

    def _crop_to_bounding_box(self, mergefile: str, target_polyfile: str, bounding_box: List[float]) -> str:
        """Crop merged file to bounding box"""
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        cropfile = f"{CHM_LOCAL_CROP_FILES_DIR}/{bbox_filename}.tif"
        
        if not os.path.exists(cropfile):
            logger.info(f"Cropping to bounding box: {cropfile}")
            self.crop_raster(mergefile, target_polyfile, cropfile)
        
        return cropfile
    
    def merge_rasters(self, files: List[str], outfile: str = "test.tif") -> None:
        """
        Merge a list of geotiffs into one file
        """
        src_files_to_mosaic = []
        for fp in files:
            src = rasterio.open(fp)
            src_files_to_mosaic.append(src)

        crs = src.crs
        out_meta = src.meta.copy()
        mosaic, out_trans = merge(src_files_to_mosaic)

        # Update the metadata
        out_meta.update(
            {
                "driver": "GTiff",
                "height": mosaic.shape[1],
                "width": mosaic.shape[2],
                "transform": out_trans,
                "crs": crs,
            }
        )

        with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION, BIGTIFF=DataProcessingConfig.BIGTIFF) as dest:
            dest.write(mosaic)

    def crop_raster(self, rasterfile: str, aoifile: str, outfile: str = "test.tif", nodata: int = None) -> None:
        """Crop raster to area of interest"""
        if nodata is None:
            nodata = DataProcessingConfig.DEFAULT_NODATA
            
        gdf_aoi = gp.read_file(aoifile)
        with rasterio.open(rasterfile) as src:
            out_meta = src.meta.copy()
            if not src.crs == gdf_aoi.crs:
                gdf_aoi = gdf_aoi.to_crs(src.crs)
            aoi = gdf_aoi.iloc[0].geometry
            im, trans = rasterio.mask.mask(
                src, [aoi], crop=True, nodata=nodata, all_touched=True
            )
            # Update the metadata
            out_meta.update(
                {
                    "driver": "GTiff",
                    "height": im.shape[1],
                    "width": im.shape[2],
                    "transform": trans,
                    "crs": src.crs,
                    "nodata": nodata,
                }
            )
        with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION, BIGTIFF=DataProcessingConfig.BIGTIFF) as dest:
            dest.write(im)

    def enforce_mask(self, file: str, outfile: Optional[str] = None, nodata: int = None) -> None:
        """Apply cloud mask to raster file"""
        if not outfile:
            outfile = file.replace('.tif', 'masked.tif')
        if nodata is None:
            nodata = DataProcessingConfig.DEFAULT_NODATA
            
        with rasterio.open(file) as src:
            mask = src.read_masks()
            data = src.read()
            # nodata has been assigned as 255 in the S3 .msk files
            data[mask == 255] = nodata
            out_meta = src.meta
            out_meta.update({"nodata": nodata})
            with rasterio.open(outfile, "w", **out_meta, compress=DataProcessingConfig.COMPRESSION) as dest:
                dest.write(data)