from core.building_image_downloader.base_downloader import BaseImageDownloader
from config import GOOGLE_MAPS_IMAGE_DIR, VisualizationConfig
import os
import requests
from PIL import Image
from dotenv import load_dotenv
import logging
from typing import List, Tuple
import time
import math
import io

load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class GoogleImageDownloader(BaseImageDownloader):
    MAX_SIZE = 640

    def __init__(self, *args, **kwargs):
        self.directories = [
            GOOGLE_MAPS_IMAGE_DIR
        ]
        super().__init__(*args, **kwargs)
    
    def run(self, bounding_box: List[float], overwrite: bool = False) -> str:
        output_filename = self._get_output_filename(bounding_box)
        if not overwrite and os.path.exists(output_filename):
            logger.info(f"Image already exists: {output_filename}")
            return output_filename
        return self.download_google_static_maps(bounding_box) 

    def _get_output_filename(self, bounding_box: List[float]) -> str:
        """Generate output filename from bounding box"""
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        return f"{GOOGLE_MAPS_IMAGE_DIR}/{bbox_filename}.png"
    
    def _latlon_to_world_pixels(self, lat: float, lon: float, zoom: int) -> Tuple[float, float]:
        """Converts lat/lon degrees to world pixel coordinates at a given zoom level."""
        world_dim = 256 * (2**zoom)
        sin_lat = math.sin(math.radians(lat))
        x = (lon + 180) * (world_dim / 360)
        y = (0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * world_dim
        return x, y

    def _world_pixels_to_latlon(self, x: float, y: float, zoom: int) -> Tuple[float, float]:
        """Converts world pixel coordinates to lat/lon degrees at a given zoom level."""
        world_dim = 256 * (2**zoom)
        lon = (x / world_dim) * 360 - 180
        n = math.pi - (2 * math.pi * y) / world_dim
        lat = math.degrees(math.atan(math.sinh(n)))
        return lat, lon

    def _calculate_zoom_level(self, bounding_box: List[float]) -> int:
        """Calculate appropriate zoom level based on area size"""
        lat1, lon1, lat2, lon2 = bounding_box
        max_diff = max(abs(lat2 - lat1), abs(lon2 - lon1))
        
        for threshold, zoom in VisualizationConfig.ZOOM_LEVELS.values():
            if max_diff > threshold:
                return zoom
        
        return VisualizationConfig.ZOOM_LEVELS['precise'][1]
    
    def _get_api_key(self) -> str:
        """Get Google Maps API key from environment variables"""
        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")
        return api_key
    
    def _make_api_request(self, params: dict) -> requests.Response:
        """Make API request with retry logic"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    "https://maps.googleapis.com/maps/api/staticmap", 
                    params=params, 
                    timeout=VisualizationConfig.REQUEST_TIMEOUT
                )
                response.raise_for_status()
                logger.info(f"Successfully downloaded image from Google Maps API (attempt {attempt + 1})")
                return response
            except requests.exceptions.RequestException as e:
                logger.warning(f"API request failed (attempt {attempt + 1}): {e}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(1)

    def _download_and_stitch_tiles(self, top_left_px_x: float, top_left_px_y: float, total_width: int, total_height: int, zoom_level: int) -> Image.Image:
        """Downloads and stitches tiles based on world pixel coordinates."""
        stitched_image = Image.new('RGB', (total_width, total_height))

        num_tiles_x = math.ceil(total_width / self.MAX_SIZE)
        num_tiles_y = math.ceil(total_height / self.MAX_SIZE)

        for i in range(num_tiles_y):
            for j in range(num_tiles_x):
                tile_width = min(self.MAX_SIZE, total_width - j * self.MAX_SIZE)
                tile_height = min(self.MAX_SIZE, total_height - i * self.MAX_SIZE)

                if tile_height <= 0 or tile_width <= 0:
                    continue

                center_px_x = top_left_px_x + j * self.MAX_SIZE + tile_width / 2
                center_px_y = top_left_px_y + i * self.MAX_SIZE + tile_height / 2
                tile_center_lat, tile_center_lon = self._world_pixels_to_latlon(center_px_x, center_px_y, zoom_level)

                logger.info(f"Downloading tile ({i},{j}) of size {tile_width}x{tile_height}")
                params = {
                    'center': f"{tile_center_lat},{tile_center_lon}",
                    'zoom': zoom_level,
                    'size': f"{tile_width}x{tile_height}",
                    'maptype': VisualizationConfig.GOOGLE_MAPS_MAPTYPE,
                    'key': self._get_api_key(),
                    'format': VisualizationConfig.GOOGLE_MAPS_FORMAT
                }
                response = self._make_api_request(params)
                tile_img = Image.open(io.BytesIO(response.content))
                
                x_paste = j * self.MAX_SIZE
                y_paste = i * self.MAX_SIZE
                stitched_image.paste(tile_img, (x_paste, y_paste))

        return stitched_image

    def download_google_static_maps(self, bounding_box: List[float]) -> str:
        output_filename = self._get_output_filename(bounding_box)
        os.makedirs(os.path.dirname(output_filename), exist_ok=True)
        
        zoom = self._calculate_zoom_level(bounding_box)

        top_lat, left_lon = max(bounding_box[0], bounding_box[2]), min(bounding_box[1], bounding_box[3])
        bottom_lat, right_lon = min(bounding_box[0], bounding_box[2]), max(bounding_box[1], bounding_box[3])
        top_left_px_x, top_left_px_y = self._latlon_to_world_pixels(top_lat, left_lon, zoom)
        bottom_right_px_x, bottom_right_px_y = self._latlon_to_world_pixels(bottom_lat, right_lon, zoom)

        total_width = int(round(bottom_right_px_x - top_left_px_x))
        total_height = int(round(bottom_right_px_y - top_left_px_y))

        if total_width <= self.MAX_SIZE and total_height <= self.MAX_SIZE:
            center_px_x = top_left_px_x + total_width / 2
            center_px_y = top_left_px_y + total_height / 2
            center_lat, center_lon = self._world_pixels_to_latlon(center_px_x, center_px_y, zoom)
            
            params = {
                'center': f"{center_lat},{center_lon}",
                'zoom': zoom,
                'size': f"{total_width}x{total_height}",
                'maptype': VisualizationConfig.GOOGLE_MAPS_MAPTYPE,
                'key': self._get_api_key(),
                'format': VisualizationConfig.GOOGLE_MAPS_FORMAT
            }
            response = self._make_api_request(params)
            final_image = Image.open(io.BytesIO(response.content))
        else:
            logger.info(f"Required image size ({total_width}x{total_height}) exceeds {self.MAX_SIZE}px limit. Tiling requests.")
            final_image = self._download_and_stitch_tiles(top_left_px_x, top_left_px_y, total_width, total_height, zoom)

        final_image.save(output_filename, 'PNG', quality=VisualizationConfig.IMAGE_QUALITY)
        logger.info(f"Successfully created satellite image: {output_filename}")
        return output_filename