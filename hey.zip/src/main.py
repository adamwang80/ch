import logging
from core.methods.chm_method import CHMMethodEngine
from core.building_image_downloader.google_downloader import GoogleImageDownloader
from core.plotter.meta_canopy_height_plotter import MetaCanopyHeightPlotter
from core.plotter.overlay_plotter import OverlayPlotter
from core.plotter.side_by_side_plotter import SideBySidePlotter
from core.methods.model_method import ModelMethodEngine

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    try:
        bounding_box = [39.32019181293791, -84.34100151269304, 39.321016371485804, -84.33919806998401]
        method = "chm"

        # engine = ModelMethodEngine()
        # engine.run(bounding_box, zoom_level=19)

        logger.info(f"Processing bounding box: {bounding_box}")
        engine = CHMMethodEngine()

        # Get canopy height data
        logger.info("Getting canopy height data...")
        engine.run(bounding_box, data_source="aws")

        building_downloader = GoogleImageDownloader()
        building_downloader.run(bounding_box, overwrite=True)

        canopy_height_plotter = MetaCanopyHeightPlotter()
        canopy_height_plotter.run(
            bounding_box=bounding_box,
            method=method,
            model_id="compressed_SSLhuge_aerial"
        )

        overlay_plotter = OverlayPlotter()
        overlay_plotter.run(
            bounding_box=bounding_box,
            method=method,
            model_id="compressed_SSLhuge_aerial",
            building_image_source=f"google_maps"
        )

        side_by_side_plotter = SideBySidePlotter()
        side_by_side_plotter.run(
            bounding_box=bounding_box,
            method=method,
            model_id="compressed_SSLhuge_aerial",
            building_image_source=f"google_maps"
        )

    except Exception as e:
        logger.error(f"Error in main processing: {e}")
        raise

if __name__ == "__main__":
    main()