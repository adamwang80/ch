from CanopyHeightEngine import CanopyHeightEngine
from ImageDownloadEngine import ImageDownloadEngine
from utils import overlay_canopy_on_image, side_by_side_canopy_image
from config import OUTPUT_DIR, OVERLAY_IMAGE_DIR, SIDE_BY_SIDE_IMAGE_DIR, GOOGLE_MAPS_IMAGE_DIR
import os

bounding_box = [45.81420138779721, 9.071142020358453, 45.81325430419046, 9.073878784584062]
bounding_box = [39.30076705472572, -84.5023961988198, 39.30029432276294, -84.50183394864057]

engine = CanopyHeightEngine()
engine.get_canopy_height(bounding_box, method="chm", data_source="local")

image_engine = ImageDownloadEngine()
image_engine.download_image(bounding_box, overwrite=False)

bbox_filename = '_'.join([str(coord) for coord in bounding_box])
canopy_height_file = f"data/chm/{bbox_filename}_crop.tif"
satellite_image_file = f"{GOOGLE_MAPS_IMAGE_DIR}/{bbox_filename}.png"

if not os.path.exists(OVERLAY_IMAGE_DIR):
    os.makedirs(OVERLAY_IMAGE_DIR, exist_ok=True)
output_file = f"{OVERLAY_IMAGE_DIR}/overlay_{bbox_filename}.png"

overlay_canopy_on_image(canopy_height_file, satellite_image_file, output_file)

if not os.path.exists(SIDE_BY_SIDE_IMAGE_DIR):
    os.makedirs(SIDE_BY_SIDE_IMAGE_DIR, exist_ok=True)
output_file = f"{SIDE_BY_SIDE_IMAGE_DIR}/side_by_side_{bbox_filename}.png"

side_by_side_canopy_image(canopy_height_file, satellite_image_file, output_file)