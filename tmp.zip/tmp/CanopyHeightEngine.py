from config import TILE_DATA_PATH, LOCAL_CHM_DIR, S3_CHM_PATH, S3_MSK_PATH, S3_META_PATH, S3_BUCKET, TARGET_PLOY_FILE_DIR, S3_TILE_DATA_PATH, CANOPY_HEIGHT_IMAGE_DIR, LOCAL_TIF_DIR, LOCAL_MSK_DIR, LOCAL_META_DIR
import geopandas as gp
import matplotlib.pyplot as plt
import os
import shutil
import boto3
from botocore import UNSIGNED
from botocore.config import Config
import json
import numpy as np
import rasterio
from PIL import Image
from shapely.geometry import box
from pyproj import Transformer
from rasterio.merge import merge
import rasterio.mask
from shapely.geometry import GeometryCollection, MultiPolygon, shape, polygon

class CanopyHeightEngine:
    def __init__(self):        
        self.local_dir = LOCAL_CHM_DIR
        self.s3chmpath = S3_CHM_PATH
        self.s3mskpath = S3_MSK_PATH
        self.s3metapath = S3_META_PATH
        self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
        self.bucket = S3_BUCKET
        self.target_polyfile_dir = TARGET_PLOY_FILE_DIR
        self.s3_tile_data_path = S3_TILE_DATA_PATH
        self.canopy_height_image_dir = CANOPY_HEIGHT_IMAGE_DIR
        self.tile_data_path = TILE_DATA_PATH
        self.tile_data_dir = os.path.dirname(self.tile_data_path)
        self.local_tif_dir = LOCAL_TIF_DIR
        self.local_msk_dir = LOCAL_MSK_DIR
        self.local_meta_dir = LOCAL_META_DIR
    

        # create local_dir if it does not exist
        if not os.path.exists(self.local_dir):
            os.makedirs(self.local_dir, exist_ok=True)
        if not os.path.exists(self.target_polyfile_dir):
            os.makedirs(self.target_polyfile_dir, exist_ok=True)
        if not os.path.exists(self.canopy_height_image_dir):
            os.makedirs(self.canopy_height_image_dir, exist_ok=True)
        if not os.path.exists(self.tile_data_dir):
            os.makedirs(self.tile_data_dir, exist_ok=True)
        
        if not os.path.exists(TILE_DATA_PATH):
            self.s3_client.download_file(self.bucket, self.s3_tile_data_path, self.tile_data_path)
        
        self.tiles = gp.read_file(self.tile_data_path)
        self.tiles = self.tiles.set_crs('EPSG:4326')

    def get_canopy_height(self, bounding_box, method="chm", data_source="aws"):
        if method == "chm":
            return self.get_canopy_height_chm(bounding_box, data_source)
    
    def get_canopy_height_chm(self, bounding_box, data_source="aws"):
        cropfile = self.get_crop_file(bounding_box, data_source)

        with rasterio.open(cropfile) as src:
            canopy_height_data = src.read(1)  # Read the first band
            # Optionally, you can apply any additional processing to the data here
            print(f"Canopy height data shape: {canopy_height_data.shape}")
            output_file = os.path.join(self.local_dir, 'output.txt')
            np.savetxt(output_file, canopy_height_data, fmt='%.2f')

        
        
        # Generate plot
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        title = f"canopy_height_{bbox_filename}"
        self.plot_canopy_height(cropfile, title=title, output_dir=self.canopy_height_image_dir)
        return cropfile
    
    
    def get_crop_file(self, bounding_box, data_source="aws"):
        """Process bounding box and return cropped file path"""
        tifs = []
        metas = []
        tile_numbers = []
        
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        target_polyfile = f"{self.target_polyfile_dir}/{bbox_filename}.geojson"
        
        if not os.path.exists(target_polyfile):
            os.makedirs(self.target_polyfile_dir, exist_ok=True)
            geojson = self.bounding_box_to_geojson(bounding_box)
            with open(target_polyfile, 'w') as f:
                json.dump(geojson, f)
        
        target = gp.read_file(target_polyfile)
        target = target.set_crs('EPSG:4326')
        target_tiles = gp.sjoin(self.tiles, target)
        
        if data_source == "aws":
            for ii, row in target_tiles.iterrows():
                tile_numbers.append(row.tile)

                # Download CHM
                s3file = f"{self.s3chmpath}/{row.tile}.tif"
                localfile = f"{self.local_dir}/{os.path.basename(s3file)}"
                if not os.path.exists(localfile):
                    print(f"Downloading {s3file} to {localfile}")
                    self.s3_client.download_file(self.bucket, s3file, localfile)

                # Download cloud masks
                mskfile = f"{self.s3mskpath}/{row.tile}.tif.msk"
                localmskfile = f"{self.local_dir}/{os.path.basename(mskfile)}"
                if not os.path.exists(localmskfile):
                    print(f"Downloading {mskfile} to {localmskfile}")
                    self.s3_client.download_file(self.bucket, mskfile, localmskfile)

                # Download metadata
                jsonfile = f"{self.s3metapath}/{row.tile}.geojson"
                localjsonfile = f"{self.local_dir}/{os.path.basename(jsonfile)}"
                if not os.path.exists(localjsonfile):
                    print(f"Downloading {jsonfile} to {localjsonfile}")
                    self.s3_client.download_file(self.bucket, jsonfile, localjsonfile)
                metas.append(localjsonfile)
                    
                # Apply mask
                outfile = localfile.replace('.tif', 'masked.tif')
                if not os.path.exists(outfile):
                    self.enforce_mask(localfile, outfile)
                tifs.append(outfile)
        elif data_source == "local":
            for ii, row in target_tiles.iterrows():
                tile = row.tile
                tile_numbers.append(tile)

                localfile=f"{self.local_dir}/{tile}.tif"
                if not os.path.exists(localfile):
                    print(f"Copying {tile}.tif to {localfile}")
                    shutil.copy(f"{self.local_tif_dir}/{tile}.tif", localfile)

                localmskfile=f"{self.local_dir}/{tile}.tif.msk"
                if not os.path.exists(localmskfile):
                    print(f"Copying {tile}.tif.msk to {localmskfile}")
                    shutil.copy(f"{self.local_msk_dir}/{tile}.tif.msk", localmskfile)

                localjsonfile=f"{self.local_dir}/{tile}.geojson"
                if not os.path.exists(localjsonfile):
                    print(f"Copying {tile}.geojson to {localjsonfile}")
                    shutil.copy(f"{self.local_meta_dir}/{tile}.geojson", localjsonfile)


                outfile=f"{self.local_dir}/{tile}masked.tif"
                if not os.path.exists(outfile):
                    self.enforce_mask(localfile, outfile)
                tifs.append(outfile)
        
        tile_numbers_str = '_'.join(tile_numbers)
        mergefile = f"{self.local_dir}/{tile_numbers_str}_alltiles.tif"
        if not os.path.exists(mergefile):
            self.merge_rasters(tifs, outfile=mergefile)
                
        # Use bounding box coordinates for crop file name
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        cropfile = f"{self.local_dir}/{bbox_filename}_crop.tif"
        if not os.path.exists(cropfile):
            self.crop_raster(mergefile, target_polyfile, cropfile)
        
        return cropfile

    def bounding_box_to_geojson(self, bbox):
        """
        Convert a bounding box [lat1, lon1, lat2, lon2] to a GeoJSON Polygon.
        Assumes lat1/lon1 is one corner, lat2/lon2 is the opposite corner.
        """
        lat1, lon1, lat2, lon2 = bbox

        # Ensure correct ordering: south, west, north, east
        south = min(lat1, lat2)
        north = max(lat1, lat2)
        west = min(lon1, lon2)
        east = max(lon1, lon2)

        # Define the polygon coordinates (must be closed: first point == last point)
        coordinates = [[
            [west, south],
            [east, south],
            [east, north],
            [west, north],
            [west, south]
        ]]

        geojson = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": coordinates
            },
            "properties": {}
        }

        return geojson

    # a few raster functions

    def merge_rasters(self, files, outfile: str = "test.tif") -> None:
        """
        Merge a list of geotiffs into one file
        """
        src_files_to_mosaic = []
        for fp in files:
            src = rasterio.open(fp)
            src_files_to_mosaic.append(src)

        crs = src.crs
        out_meta = src.meta.copy()
        mosaic, out_trans = merge(src_files_to_mosaic)

        # Update the metadata
        out_meta.update(
            {
                "driver": "GTiff",
                "height": mosaic.shape[1],
                "width": mosaic.shape[2],
                "transform": out_trans,
                "crs": crs,
            }
        )

        with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE", BIGTIFF='YES') as dest:
            dest.write(mosaic)

    def crop_raster(self, rasterfile: str, aoifile:str, outfile: str = "test.tif", nodata=255):
        gdf_aoi=gp.read_file(aoifile)
        with rasterio.open(rasterfile) as src:
                out_meta = src.meta.copy()
                if not src.crs == gdf_aoi.crs:
                    gdf_aoi=gdf_aoi.to_crs(src.crs)
                aoi=gdf_aoi.iloc[0].geometry
                im, trans = rasterio.mask.mask(
                    src, [aoi], crop=True, nodata=nodata, all_touched=True
                )
                # Update the metadata
                out_meta.update(
                {
                    "driver": "GTiff",
                    "height": im.shape[1],
                    "width": im.shape[2],
                    "transform": trans,
                    "crs": src.crs,
                    "nodata": nodata,
                }
                )
        with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE", BIGTIFF='YES') as dest:
            dest.write(im)


    def enforce_mask(self, file, outfile=None, nodata=255):
        if not outfile:
            outfile=file.replace('.tif', 'masked.tif')
        with rasterio.open(file) as src:
            mask=src.read_masks()
            data=src.read()
            #nodata has been assigned as 255 in the S3 .msk files
            data[mask==255]=nodata
            out_meta=src.meta
            out_meta.update(
                {"nodata":nodata}
            )
            with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE") as dest:
                dest.write(data)
                
    #a few functions for nice looking plots

    def mercator_to_latlon_ax(self, ax, dec=2):
        xt=ax.get_xticks()
        yt=ax.get_yticks()
        trans = Transformer.from_proj("epsg:3857", "epsg:4326")
        #can do this because 3857 has parrallel lat and lon
        zlon=[yt[0] for _ in range(len(xt))]
        zlat=[xt[0] for _ in range(len(yt))]
        _,lon=trans.transform(xt, zlon)
        lat,_=trans.transform(zlat, yt)
        lons=[]
        for l in lon:
            if l<0:
                hem='W'
            else:
                hem='E'
            lons.append(f"{np.abs(np.round(l,dec))}{chr(176)}{hem}")
        lats=[]
        for l in lat:
            if l<0:
                hem='S'
            else:
                hem='N'
            lats.append(f"{np.abs(np.round(l,dec))}{chr(176)}{hem}")

        ax.set_yticklabels(lats, fontsize=18, fontweight="bold")
        ax.set_xticklabels(lons, fontsize=18, fontweight="bold")
        ax.yaxis.set_tick_params(rotation=90)

    def geojson_to_poly(self, geojson):
        """
        Given a geojson with a polygon shape,
        return the shapely object
        """
        if len(geojson["features"]) > 1:
            poly = GeometryCollection(
                [shape(feature["geometry"]).buffer(0) for feature in geojson["features"]]
            )
        else:
            f = geojson["features"][0]
            poly = shape(f["geometry"]).buffer(0)
        if poly.geom_type != "Polygon":
            pps = []
            for pp in poly.geoms:
                pp = polygon.orient(pp)  # correct winding
                pps.append(pp)
            out_geom = MultiPolygon(pps)
        else:
            out_geom = polygon.orient(poly)  # correct winding
        return out_geom

    def plot_canopy_height(self, cropfile, title='canopy_height', output_dir='data/images/canopy_height', dpi=300):
        """
        Plot canopy height data from a cropped raster file
        
        Parameters:
        -----------
        cropfile : str
            Path to the cropped raster file
        title : str
            Title for the plot and output filename
        output_dir : str
            Directory to save the output image
        dpi : int
            Resolution for the output image
        """
        with rasterio.open(cropfile) as src:
            data = src.read().squeeze()
            bounds = src.bounds
            width = src.width
            height = src.height

        factor = 1
        new_width = int(width/factor)
        new_height = int(height/factor)
        xx = Image.fromarray(data).resize(
            (new_width, new_height), Image.BICUBIC
        )
        chm = np.array(xx).astype('float')
        # set nodata (with interp fuzziness)
        chm[chm > 200] = np.nan
        
        fig, ax = plt.subplots(1, 1, figsize=[14, 10])
        bbox = box(*bounds)
        extent = (bbox.bounds[0], bbox.bounds[2], bbox.bounds[1], bbox.bounds[3])
        colors = ax.imshow(chm, vmax=np.nanpercentile(chm, 99.5), extent=extent)
        tt = ax.get_xticks()[1:-1]
        ax.set_xticks(tt[::3])
        tt = ax.get_yticks()[1:-1]
        ax.set_yticks(tt[::3])
        self.mercator_to_latlon_ax(ax, dec=2)
        cax = plt.gca().inset_axes([1.05, 0.3, 0.03, 0.4])
        plt.colorbar(colors, cax=cax, label='canopy height [meters]')
        ax.set_title(title)
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        plt.savefig(f'{output_dir}/{title}.png', dpi=dpi, bbox_inches='tight')
        plt.close()  # Close the figure to free memory
        
        return fig, ax