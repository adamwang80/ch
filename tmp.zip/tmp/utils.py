import numpy as np
from PIL import Image
import rasterio
from matplotlib import cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
import os
from matplotlib import gridspec


def overlay_canopy_on_image(canopy_height_file, satellite_image_file, output_file, 
                             canopy_threshold=0, alpha=0.3):
    """
    Simple PIL overlay: satellite + canopy height
    """

    # Read satellite image - keep original quality
    satellite_img = Image.open(satellite_image_file)
    satellite_img = satellite_img.convert('RGB')

    # Read canopy height and convert to image
    with rasterio.open(canopy_height_file) as src:
        canopy_data = src.read(1)
        canopy_data = np.where(canopy_data < 0, 0, canopy_data)

    # Set values > 200 to NaN
    canopy_data = np.where(canopy_data > 200, np.nan, canopy_data)

    # Normalize canopy data to 0-255, ignoring NaNs
    canopy_max = np.nanmax(canopy_data)
    if canopy_max > 0:
        canopy_normalized = (canopy_data / canopy_max * 255)
    else:
        canopy_normalized = canopy_data

    # Apply threshold - only show areas above threshold
    tree_mask = canopy_data >= canopy_threshold
    canopy_normalized = np.where(tree_mask, canopy_normalized, 0)

    # Replace NaNs with 0 for visualization
    canopy_normalized = np.nan_to_num(canopy_normalized, nan=0).astype(np.uint8)

    # Create colored canopy image (bright red for trees)
    canopy_height, canopy_width = canopy_normalized.shape
    canopy_colored = np.zeros((canopy_height, canopy_width, 3), dtype=np.uint8)

    # Set red color based on canopy height
    canopy_colored[:, :, 0] = canopy_normalized  # Red channel
    canopy_colored[:, :, 1] = 0  # Green channel (0 for red)
    canopy_colored[:, :, 2] = 0  # Blue channel (0 for red)

    # Create canopy image
    canopy_img = Image.fromarray(canopy_colored, mode='RGB')

    # Resize canopy to match satellite (don't resize satellite!)
    if canopy_img.size != satellite_img.size:
        canopy_img = canopy_img.resize(satellite_img.size, Image.Resampling.LANCZOS)

    # Create overlay
    overlay_img = Image.blend(satellite_img, canopy_img, alpha)

    # Save
    overlay_img.save(output_file, 'PNG', quality=95)

    print(f"Simple overlay saved: {output_file}")
    return output_file




import os
import numpy as np
import rasterio
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from PIL import Image

def side_by_side_canopy_image(canopy_height_file, satellite_image_file, output_file, canopy_threshold=0, dpi=300):
    """
    Display satellite image and canopy height image side by side with colorbar.
    """

    # Load satellite image
    satellite_img = Image.open(satellite_image_file).convert('RGB')

    # Load canopy height data
    with rasterio.open(canopy_height_file) as src:
        canopy_data = src.read(1)
        bounds = src.bounds

    # Clean and normalize canopy data
    canopy_data = np.where(canopy_data < 0, 0, canopy_data)
    canopy_data = np.where(canopy_data > 200, np.nan, canopy_data)
    canopy_data = np.where(canopy_data >= canopy_threshold, canopy_data, np.nan)

    # Resize canopy data to match satellite image size
    canopy_img = Image.fromarray(np.nan_to_num(canopy_data).astype(np.float32))
    canopy_img = canopy_img.resize(satellite_img.size, Image.BICUBIC)
    canopy_array = np.array(canopy_img).astype(float)
    canopy_array[canopy_array > 200] = np.nan

    # Create figure with GridSpec
    fig = plt.figure(figsize=(14, 7))
    gs = GridSpec(1, 3, width_ratios=[1, 1, 0.05], wspace=0.05)

    # Plot satellite image
    ax1 = fig.add_subplot(gs[0])
    ax1.imshow(satellite_img)
    ax1.set_title("Satellite Image")
    ax1.axis('off')

    # Plot canopy height with colormap
    ax2 = fig.add_subplot(gs[1])
    im = ax2.imshow(canopy_array, cmap='viridis', vmax=np.nanpercentile(canopy_array, 98))
    ax2.set_title("Canopy Height")
    ax2.axis('off')

    # Add colorbar
    cax = fig.add_subplot(gs[2])
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Canopy Height [meters]")

    # Save the figure
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    plt.savefig(output_file, dpi=dpi, bbox_inches='tight')
    plt.close()

    print(f"Side-by-side image saved: {output_file}")
    return output_file





