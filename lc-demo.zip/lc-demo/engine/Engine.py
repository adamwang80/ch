from config.config import SOURCES, STRATEGY, MAX_TASK_PER_REP, SCORING_WEIGHTS
from data_loader.task_source.TaskSourceFactory import TaskSourceFactory
from data_loader.rep.RepBuilder import RepBuilder
import pandas as pd
from assignment_algorithm.AssignEngine import AssignEngine
from utils.utils import convert_to_output_format_pandas, get_rep_assignment_summary, convert_to_test_output_format_pandas
import matplotlib.pyplot as plt
from model.Task import Task

class Engine:
    def __init__(self, strategy=STRATEGY):
        self.task_pool = pd.DataFrame()
        self.rep_dict = {}
        self.strategy = strategy
        self.raw_data = {}

        self.assignment_result = None
        self.output_result = None
        self.rep_assignment_summary = None
        self.test_output_result = None
        self.task_list = []

    def run(self):
        # load data sources
        for source_name, source_config in SOURCES.items():
            if source_config["INCLUDED"]:
                inputs = self.get_inputs(source_name)
                task_source = TaskSourceFactory.create_task_sources(source_name, inputs)
                self.raw_data[source_name] = task_source.get_raw_df()
                task_pool, task_list = task_source.to_task_pool()
                self.task_pool = pd.concat([self.task_pool, task_pool], ignore_index=True)
                self.task_list.extend(task_list)
        
        # load rep info and task count
        rep_builder = RepBuilder()
        self.rep_dict = rep_builder.run()

        # run assignment algorithm
        assign_engine = AssignEngine(self.rep_dict, self.task_pool, self.strategy)
        self.assignment_result = assign_engine.run()
        
        self.output_result = convert_to_output_format_pandas(self.assignment_result, self.rep_dict, self.task_pool)
        self.rep_assignment_summary = get_rep_assignment_summary(self.output_result)
        self.test_output_result = convert_to_test_output_format_pandas(self.assignment_result, self.rep_dict, self.task_pool)
        
    def get_inputs(self, source):
        if source == "CLD_MATRIX_WC":
            cld_pkg = TaskSourceFactory.create_task_sources("CLD_MATRIX_PACKAGE")
            inputs = {
                'pkg_df': cld_pkg.get_raw_df()
            }
            return inputs
        return None
    
    def get_task(self, task_id: str):
        for task in self.task_list:
            if task.task_id == task_id:
                return task
        return None
    
    def get_result_summary(self):
        result = self.output_result
        summary = self.rep_assignment_summary
        # print the average of score column
        print("Average score:", result['score'].mean())
        # print average distance_score, risk_level_score, due_date_score, and agency_score
        print("Average distance_score:", result['distance_score'].mean(), "Weight:", SCORING_WEIGHTS["distance"])
        print("Average risk_level_score:", result['risk_level_score'].mean(), "Weight:", SCORING_WEIGHTS["risk_level"])
        print("Average due_date_score:", result['due_date_score'].mean(), "Weight:", SCORING_WEIGHTS["due_date"])
        print("Average agency_score:", result['agency_score'].mean(), "Weight:", SCORING_WEIGHTS["agency"])
        print("Average balance_score:", result['balance_score'].mean(), "Weight:", SCORING_WEIGHTS["balance"])

        # plot the distribution of all 5 scores using histograms in one figure
        scores = ['score', 'distance_score', 'risk_level_score', 'due_date_score', 'agency_score']
        fig, axes = plt.subplots(1, len(scores), figsize=(20, 5))
        for ax, score in zip(axes, scores):
            ax.hist(result[score], bins=20, alpha=0.7)
            ax.set_title(f'Distribution of {score}')
            ax.set_xlabel(score)
            ax.set_ylabel('Frequency')
        plt.tight_layout()
        plt.show()

        # print the average distance for the rows with task_inspection_type = On-Site
        onsite_avg_distance = result[result['task_inspection_type'] == 'On-Site']['distance'].mean()
        print("Average distance for On-Site inspections:", onsite_avg_distance)
        # plot the distribution of distance for the rows with task_inspection_type = On-Site
        # Filter rows where task_inspection_type is "On-Site"
        on_site_df = result[result['task_inspection_type'] == "On-Site"]

        # Plot the distance distribution
        plt.figure(figsize=(5, 3))
        plt.hist(on_site_df['distance'], bins=30, color='blue', alpha=0.7)
        plt.title('Distance Distribution for On-Site Inspections')
        plt.xlabel('Distance')
        plt.ylabel('Frequency')
        plt.grid(True)
        plt.show()

        # Calculate the difference in task counts
        task_count_diff = summary['task_count_after_assignment'] - summary['task_count']

        # Plot the distribution of task count differences
        plt.figure(figsize=(5, 3))
        plt.hist(task_count_diff, bins=30, color='green', alpha=0.7)
        plt.title('Task Count Assigned Distribution')
        plt.xlabel('Task Assigned')
        plt.ylabel('Frequency')
        plt.grid(True)
        plt.show()
        
        print("Reps with no tasks assigned:", len(summary[summary['task_count'] == summary['task_count_after_assignment']]))

        print("Tasks not assigned:", len(self.task_pool) - len(result))

        # return the plot
        return fig