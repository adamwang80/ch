from pydantic import BaseModel
from typing import Optional, Literal
from datetime import date

class Task(BaseModel):

    # Required fields
    task_id: str # Generated id, only used in this engine
    policy_number: Optional[str] = None
    due_date: date

    # Risk levels (required skill levels)
    au_risk_level: Optional[str] = None
    gl_risk_level: Optional[str] = None
    pr_risk_level: Optional[str] = None
    pl_risk_level: Optional[str] = None
    wc_risk_level: Optional[str] = None

    agency_code: Optional[str] = None
    last_inspection_group: Optional[str] = None

    inspection_type: Literal["Virtual", "On-Site"] = "On-Site"

    insured_name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    county: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    region: Optional[str] = None

    source: str

    agency_based_assigned_rep: Optional[str] = None

    loc_num: Optional[float] = None
    

