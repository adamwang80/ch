from pydantic import BaseModel
from typing import Optional

class Rep(BaseModel):
    
    employee_id: str
    name: str
    email: str

    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    au_level: Optional[int] = None
    cn_level: Optional[int] = None
    gl_level: Optional[int] = None
    pl_level: Optional[int] = None
    pr_level: Optional[int] = None
    wc_level: Optional[int] = None

    familiar_agencies: Optional[list[str]] = None
    region: Optional[str] = None
    team: Optional[str] = None

    key_account: Optional[bool] = False

    current_task_count: int = 0