import pandas as pd
from typing import Dict
from model.Rep import Rep
from config.config import SOURCES
from sqlalchemy import create_engine


class RepBuilder:
    def __init__(self):
        self.rep_info_df = self.load_rep_info()
        self.task_count_df = self.load_rep_task_count()
        self.agency_df = self.load_agency_info()

    def run(self) -> Dict[str, Rep]:
        return self.build_reps()

    def build_reps(self) -> Dict[str, Rep]:

        common_names = set(self.rep_info_df["HR Associate"]) & set(self.task_count_df["HR Associate"])
        self.rep_info_df = self.rep_info_df[self.rep_info_df["HR Associate"].isin(common_names)]

        # Filter out rows where "Status" is "Inactive" and "Job Title" is "Intern"
        self.rep_info_df = self.rep_info_df[
            (self.rep_info_df["Status"] != "Inactive") & (self.rep_info_df["Job Title"] != "Intern")
        ]

        self.task_count_df = self.task_count_df[self.task_count_df["HR Associate"].isin(common_names)]

        task_count_lookup = dict(
            zip(self.task_count_df["HR Associate"], self.task_count_df["Total"])
        )

        

        reps = {}

        for _, row in self.rep_info_df.iterrows():
            name = row["HR Associate"]
            employee_id = row["Emp ID"]
            familiar_agencies = self.find_familiar_agencies(name)
            rep = Rep(
                employee_id=row["Emp ID"],
                name=name,
                email=row.get("Email"),
                address=row.get("Street"),
                city=row.get("City"),
                state=row.get("State"),
                zip_code=row.get("Zip"),
                latitude=row.get("Latitude"),
                longitude=row.get("Longitude"),
                au_level=row.get("AU") if row.get("AU") in ['1', '2', '3'] else '-1',
                cn_level=row.get("CN") if row.get("CN") in ['1', '2', '3'] else '-1',
                gl_level=row.get("GL") if row.get("GL") in ['1', '2', '3'] else '-1',
                pl_level=row.get("PL") if row.get("PL") in ['1', '2', '3'] else '-1',
                pr_level=row.get("PR") if row.get("PR") in ['1', '2', '3'] else '-1',
                wc_level=row.get("WC") if row.get("WC") in ['1', '2', '3'] else '-1',
                current_task_count=task_count_lookup[name],
                region=row.get("Team"),
                team=row.get("RTD"),
                familiar_agencies=familiar_agencies,
                key_account = not pd.isna(row.get("KAGB Standup")) or not pd.isna(row.get("KAC Standup"))
            )
            reps[employee_id] = rep

        reps = {
            emp_id: rep
            for emp_id, rep in reps.items()
        }

        return reps
    
    def load_rep_info(self):
        df_rep = pd.read_csv("data/rep_data_dev/rep_info.csv")
        return df_rep

    def load_rep_task_count(self):
        df_rep = pd.read_csv("data/rep_data_dev/rep_task_count.csv")
        return df_rep
    
    def load_agency_info(self):
        server = SOURCES["CLD_MATRIX_PACKAGE"]["SQL_SERVER_NAME"]
        database = SOURCES["CLD_MATRIX_PACKAGE"]["DATABASE_NAME"]
        query = "SELECT * FROM " + database + ".cld_user.Agency"
        connection_string = f'mssql+pyodbc://{server}/{database}?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'   
        engine = create_engine(connection_string)
        df_agency = pd.read_sql(query, engine)
        return df_agency
    
    def find_familiar_agencies(self, name: str) -> list[str]:
        agency_info = self.agency_df
        familiar_agencies = []
        
        familiar_agency_info = agency_info[agency_info["LC_NAME"].str.upper() == name.upper()]
        for _, row in familiar_agency_info.iterrows():
            familiar_agencies.append(row["AGENT"])
        return familiar_agencies