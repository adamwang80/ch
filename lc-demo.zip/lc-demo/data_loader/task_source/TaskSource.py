from abc import ABC, abstractmethod
import pandas as pd


class TaskSource(ABC):
    """
    Abstract base class for any task source.
    Subclasses must implement logic to convert raw data
    into a standardized task pool DataFrame.
    """
    def __init__(self):
        self.raw_df = self.load_data()
        self.df_zip = pd.read_csv("data/zip_info.csv", encoding='ISO-8859-1')
        self.df_region = pd.read_csv("data/region.csv")

    @abstractmethod
    def load_data(self) -> pd.DataFrame:
        """
        Load raw data from the source.
        Returns:
            pd.DataFrame: Raw data DataFrame.
        """
        pass

    @abstractmethod
    def to_task_pool(self):
        """
        Convert raw source data into a standardized task pool DataFrame.
        Returns:
            pd.DataFrame: A DataFrame with columns matching Task schema.
        """
        pass
    
    def zip_to_lat_lon(self, zip_code):
        try:
            lat = self.df_zip[self.df_zip['ZIP_CODE'] == int(zip_code)]['LAT'].values[0]/1000000
            lon = self.df_zip[self.df_zip['ZIP_CODE'] == int(zip_code)]['LONG'].values[0]/1000000
            return lat, lon
        except IndexError as e:
            print(f"[WARN] ZIP code not found in zip_info.csv: {zip_code}. Error: {e}")
            return None, None
        
    def state_county_to_region(self, state, county):
        try:
            # First make some preprocessing as follow:
            # if county == 'BALTIMORE CITY', make it 'Baltimore'
            # if county == 'ST. LOUIS CITY', make it 'Saint Louis'
            # if county == 'PRINCE GEORGE'S', make it 'Prince George'
            # if county == 'ST. CROIX', make it 'Saint Croix'
            # if county == 'ST. CLAIR', make it 'Saint Clair'
            # if county == 'ST. CHARLES', make it 'Saint Charles'
            # if county == 'DONA ANA', make it 'Doña Ana'
            # if county == 'ST. FRANCOIS', make it 'Saint Francois'
            # if county == 'ST. JOSEPH', make it 'Saint Joseph'

            if county == 'ST. CLAIR':
                county = 'Saint Clair'
            elif county == 'ST. CROIX':
                county = 'Saint Croix'
            elif county == 'ST. LUCIE':
                county = 'Saint Lucie'

            # if state not in ['OH', 'PA', 'WI', 'IL']

            if state not in ['OH', 'PA', 'WI', 'IL']:
                region = self.df_region[self.df_region['State'].str.capitalize() == state.capitalize()]['Region'].values[0]
            else:
                region = self.df_region[
                    (self.df_region['County'].str.capitalize() == county.capitalize()) &
                    (self.df_region['State'].str.capitalize() == state.capitalize())
                ]['Region'].values[0]
            return region
        except IndexError as e:
            print(f"[WARN] County not found in region.csv: {county} in state {state}. Error: {e}")
            return None