import pandas as pd
from datetime import date, timedelta, datetime
from data_loader.task_source.TaskSource import TaskSource
from model.Task import Task
from config.config import SOURCES
import uuid
from sqlalchemy import create_engine

class CLDWorkersComp(TaskSource):
    def __init__(self, pkg_df):
        self.from_date = datetime.strptime(SOURCES["CLD_MATRIX_WC"]["FROM_DATE"], "%Y/%m/%d").date()
        self.to_date = datetime.strptime(SOURCES["CLD_MATRIX_WC"]["TO_DATE"], "%Y/%m/%d").date()
        self.inspection_period = SOURCES["CLD_MATRIX_WC"]["INSPECTION_PERIOD"]
        self.source_name = "CLD_MATRIX_WC"
        self.pkg_df = pkg_df
        super().__init__()

    def load_data(self) -> pd.DataFrame:
        server = SOURCES["CLD_MATRIX_WC"]["SQL_SERVER_NAME"]
        database = SOURCES["CLD_MATRIX_WC"]["DATABASE_NAME"]
        query = "SELECT * FROM " + database + ".dbo." + SOURCES["CLD_MATRIX_WC"]["TABLE_NAME"]
        connection_string = f'mssql+pyodbc://{server}/{database}?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'   
        engine = create_engine(connection_string)
        df_wc = pd.read_sql(query, engine)
        df_wc['task_id'] = [str(uuid.uuid4()) for _ in range(len(df_wc))]
        return df_wc

    def filter_valid_tasks(self) -> pd.DataFrame:
        # TODO: Add some debug print throughout the function, when 'Last_Inspection_data" is None, I want to see some intermediate results
        # Ensure date columns are in datetime format

        self.raw_df['Last_Inspection_date'] = pd.to_datetime(self.raw_df['Last_Inspection_date'], errors='coerce')
        self.raw_df['Inspection_due_date'] = pd.to_datetime(self.raw_df['Inspection_due_date'], errors='coerce')

        def is_valid(row) -> bool:
            last_insp = row.get('Last_Inspection_date')
            due = row.get('Inspection_due_date')
            if pd.isna(due):
                return False
            
            if row.get('Trigger') != "Trigger":
                return False
            
            if row.get('pg_unit_desc') != "Commercial Lines":
                return False

            month_diff = (due.year - last_insp.year) * 12 + (due.month - last_insp.month)
            # if Due_Date - Last_Insp_Date > inspection_period and Due_Date is within lookahead_days from today, it is valid
            if (pd.isna(last_insp) or month_diff > self.inspection_period) and self.from_date <= due.date() <= self.to_date:
                return True
            # if Due_Date is before today, it is valid
            # if due.date() < today:
            #     return True
            return False

        return self.raw_df[self.raw_df.apply(is_valid, axis=1)]

    def to_task_pool(self):
        df = self.filter_valid_tasks()
        task_list = []
        returned_task_list = []

        for _, row in df.iterrows():
            try:
                pkg_row = self.get_pkg_row(self.pkg_df, row.get('PolicySymNum'))
                lat, lon = self.zip_to_lat_lon(row.get('MailingZip'))
                task = Task(
                    task_id=row.get('task_id', str(uuid.uuid4())),
                    policy_number=row.get('PolicySymNum'),
                    due_date=row['Inspection_due_date'],
                    # wc_risk_level= pkg_row.get('WC_Risk_Level') if pkg_row is not None and pkg_row.get('WC_Risk_Level') in ['1', '2', '3'] else None,
                    wc_risk_level = self.get_wc_risk_level(row.get('WCInforcePremium', 0)),
                    agency_code=row.get('Agency_Code'),
                    address=row.get('MailingAddress'),
                    city=row.get('MailingCity'),
                    state=row.get('MailingState'),
                    zip_code=row.get('MailingZip'),
                    county=row.get('MailingCounty'),
                    latitude=lat,
                    longitude=lon,
                    source=self.source_name,
                    region=self.state_county_to_region(row.get('MailingState'), row.get('MailingCounty')),
                    agency_based_assigned_rep=pkg_row.get('LC_Rep') if pkg_row is not None else None,
                )
                task_list.append(task.model_dump())
                returned_task_list.append(task)

            except Exception as e:
                print(f"[WARN] Skipped row due to error: {e}")

        return pd.DataFrame(task_list), returned_task_list
    
    def get_pkg_row(self, pkg_df, policy_num):
        pkg_row = pkg_df[pkg_df['WC_With_CIC'] == policy_num]
        if not pkg_row.empty:
            return pkg_row.iloc[0]
        return None
    
    def get_raw_df(self):
        return self.raw_df
    
    def get_wc_risk_level(self, wc_inforce_premium):
        if wc_inforce_premium < 50000:
            return '1'
        elif wc_inforce_premium > 100000:
            return '3'
        else:
            return '2'