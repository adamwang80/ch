from data_loader.task_source.CLDPackage import CLDPackage
from data_loader.task_source.CLDWorkersComp import CLDWorkersComp

class TaskSourceFactory:

    @staticmethod
    def create_task_sources(source_name: str, inputs: dict = None):
        if source_name == "CLD_MATRIX_PACKAGE":
            return CLDPackage()
        elif source_name == "CLD_MATRIX_WC":
            return CLDWorkersComp(inputs.get('pkg_df'))
        