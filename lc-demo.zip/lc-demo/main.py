from engine.Engine import Engine

def main():
    engine = Engine()
    engine.run()
    result = engine.output_result

    # output result to output.csv
    result.to_csv("output.csv", index=False)
   
    

if __name__ == "__main__":
    main()


