from typing import Dict, List, Tuple
from collections import defaultdict
from config.config import MAX_TASK_PER_REP, MAX_TASK_PER_REP_KA
from model.Rep import Rep

def round_robin_strategy(
    rep_scores: Dict[str, List[Tuple[str, float]]],
    rep_dict: Dict[str, Rep],
) -> Dict[str, List[Tuple[str, float, List[float]]]]:
    assigned_tasks = set()
    assignment_result = defaultdict(list)
    rep_ids = list(rep_scores.keys())

    while True:
        round_made_progress = False

        for rep_id in rep_ids:
            current_assigned = len(assignment_result[rep_id])
            current_total = rep_dict[rep_id].current_task_count + current_assigned
            is_key_account = rep_dict[rep_id].key_account
            if (not is_key_account and current_total >= MAX_TASK_PER_REP) or (is_key_account and current_total >= MAX_TASK_PER_REP_KA):
                continue

            for task_id, score, sub_scores in rep_scores[rep_id]:
                if task_id not in assigned_tasks:
                    if score >= 0:
                        assignment_result[rep_id].append((task_id, score, sub_scores))
                        assigned_tasks.add(task_id)
                        round_made_progress = True
                    break

        if not round_made_progress:
            break
    return assignment_result