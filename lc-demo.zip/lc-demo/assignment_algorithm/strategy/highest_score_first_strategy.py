from typing import Dict, List, Tuple
from collections import defaultdict
from config.config import MAX_TASK_PER_REP, MAX_TASK_PER_REP_KA, LOAD_PERCENTAGE_LAMBDA
from model.Rep import Rep

def highest_score_first_strategy(
    rep_scores: Dict[str, List[Tuple[str, float]]],
    rep_dict: Dict[str, Rep],
) -> Dict[str, List[Tuple[str, float, List[float]]]]:
    assigned_tasks = set()
    assignment_result = defaultdict(list)
    rep_ids = list(rep_scores.keys())

    top_list = [0 for _ in range(len(rep_ids))]
    top_index_list = [0 for _ in range(len(rep_ids))]
    for idx, rep_id in enumerate(rep_ids):
        top_list[idx] = rep_scores[rep_id][0][1] * get_balance_factor(rep_dict[rep_id], rep_dict[rep_id].current_task_count)
        
    while True:
        if max(top_list) == -1:
            break

        top_score = max(top_list)
        top_score_index = top_list.index(top_score)
        rep_with_top_score = rep_ids[top_score_index]
        task_index = top_index_list[top_score_index]

        current_assigned = len(assignment_result[rep_with_top_score])
        current_total = rep_dict[rep_with_top_score].current_task_count + current_assigned
        is_key_account = rep_dict[rep_with_top_score].key_account
        if (not is_key_account and current_total >= MAX_TASK_PER_REP) or (is_key_account and current_total >= MAX_TASK_PER_REP_KA):
            top_list[top_score_index] = -1
            top_index_list[top_score_index] = -1
            continue

        if rep_scores[rep_with_top_score][task_index][0] in assigned_tasks:
            task_index += 1

            if task_index >= len(rep_scores[rep_with_top_score]):
                top_list[top_score_index] = -1
                top_index_list[top_score_index] = -1
            else:
                top_list[top_score_index] = rep_scores[rep_with_top_score][task_index][1] * get_balance_factor(rep_dict[rep_with_top_score], current_total)
                top_index_list[top_score_index] = task_index
        
        else:
            assigned_tasks.add(rep_scores[rep_with_top_score][task_index][0])
            assignment_result[rep_with_top_score].append(rep_scores[rep_with_top_score][task_index])
            
    return assignment_result

def get_balance_factor(rep, current_task_count) -> float:
    max_task_count = MAX_TASK_PER_REP_KA if rep.key_account else MAX_TASK_PER_REP
    load_percentage = current_task_count / max_task_count

    return 1 - LOAD_PERCENTAGE_LAMBDA * load_percentage