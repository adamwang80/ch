from typing import Dict, List, Tuple
from collections import defaultdict
from config.config import MAX_TASK_PER_REP, MAX_TASK_PER_REP_KA
from model.Rep import Rep

def vanilla_strategy(
    rep_scores: Dict[str, List[Tuple[str, float]]],
    rep_dict: Dict[str, Rep],
) -> Dict[str, List[Tuple[str, float, List[float]]]]:
    assigned_tasks = set()
    assignment_result = defaultdict(list)

    for rep_id, scored_tasks in rep_scores.items():
        current_total = rep_dict[rep_id].current_task_count
        remaining_quota = MAX_TASK_PER_REP - current_total

        is_key_account = rep_dict[rep_id].key_account
        if (not is_key_account and current_total >= MAX_TASK_PER_REP) or (is_key_account and current_total >= MAX_TASK_PER_REP_KA):
            continue

        for task_id, score, sub_scores in scored_tasks:
            if score == -1:
                break
            if task_id not in assigned_tasks:
                assignment_result[rep_id].append((task_id, score, sub_scores))
                assigned_tasks.add(task_id)
            if len(assignment_result[rep_id]) >= remaining_quota:
                break

    return assignment_result