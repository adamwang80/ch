from model.Task import Task
from model.Rep import Rep
from config.config import SCORING_WEIGHTS, SOURCES, DIFFERENT_REGION_PENALTY, MAX_TASK_PER_REP, MAX_TASK_PER_REP_KA, VIRTUAL_TASK_DISTANCE_WEIGHT_DISCOUNT_FACTOR
from utils.utils import compute_distance
from datetime import datetime, timedelta
from typing import List, Tuple

class ScoringAlgorithm:
    def __init__(self):
        pass

    def run(self, rep: Rep, task: Task) -> Tuple[float, List[Tuple[float, float]]]:
        if not self.check_hard_requirements(rep, task):
            return -1, [(-1, 0), (-1, 0), (-1, 0), (-1, 0)]
        final_score, sub_scores = self.score_task(rep, task)      
        return final_score, sub_scores
        
    def check_hard_requirements(self, rep: Rep, task: Task) -> bool:
        # if self.different_region(rep, task):
        #     return False
        if self.underqualified_by_two_levels(rep, task):
            return False 
        return True

    def different_region(self, rep: Rep, task: Task) -> bool:
        if rep.region is None or task.region is None:
            return False
        if task.region != rep.region:
            return True
        return False
    
    def underqualified_by_two_levels(self, rep: Rep, task: Task) -> bool:
        if rep.au_level in [1, None] and task.au_risk_level == '3':
            return True
        if rep.gl_level in [1, None] and task.gl_risk_level == '3':  
            return True
        if rep.pr_level in [1, None] and task.pr_risk_level == '3':
            return True
        if rep.pl_level in [1, None] and task.pl_risk_level == '3':
            return True
        if rep.wc_level in [1, None] and task.wc_risk_level == '3':
            return True

        return False
    
    def score_task(self, rep: Rep, task: Task):

        distance_weight = SCORING_WEIGHTS["distance"] if task.inspection_type == "On-Site" else SCORING_WEIGHTS["distance"] * VIRTUAL_TASK_DISTANCE_WEIGHT_DISCOUNT_FACTOR
        risk_level_weight = SCORING_WEIGHTS["risk_level"]
        due_date_weight = SCORING_WEIGHTS["due_date"]
        agency_weight = SCORING_WEIGHTS["agency"]
        balance_weight = SCORING_WEIGHTS["balance"]

        distance_weight, risk_level_weight, due_date_weight, agency_weight, balance_weight = self.normalize_weights(distance_weight, risk_level_weight, due_date_weight, agency_weight, balance_weight)
            

        distance_score = self.score_distance(rep, task)
        risk_level_score = self.score_risk_level(rep, task)
        due_date_score = self.score_due_date(task.due_date, task.source)
        agency_score = self.score_agency(rep.familiar_agencies, task.agency_code)
        balance_score = self.score_task_count(rep)

        final_score = (distance_weight * distance_score) + \
                    (risk_level_weight * risk_level_score) + \
                    (due_date_weight * due_date_score) + \
                    (agency_weight * agency_score) + \
                    (balance_weight * balance_score)
        return final_score, [(distance_score, distance_weight), 
                             (risk_level_score, risk_level_weight), 
                             (due_date_score, due_date_weight), 
                             (agency_score, agency_weight),
                             (balance_score, balance_weight)]


    def score_distance(self, rep, task):
        rep_lat, rep_lon, task_lat, task_lon = rep.latitude, rep.longitude, task.latitude, task.longitude
        distance = compute_distance(rep_lat, rep_lon, task_lat, task_lon)

        score = 1.0

        if self.different_region(rep, task):
            distance += DIFFERENT_REGION_PENALTY
        
        # if idtance <= 75, score is 1
        if distance <= 75:
            score = 1.0
        else:
            score = 1/(1+0.018*(distance-75))
    
        return score
        
    def score_risk_level(self, rep: Rep, task: Task) -> float:
        try:
            score = 1
            for risk_level, rep_level in [
                (task.au_risk_level, rep.au_level),
                (task.gl_risk_level, rep.gl_level),
                (task.pr_risk_level, rep.pr_level),
                (task.pl_risk_level, rep.pl_level),
                (task.wc_risk_level, rep.wc_level),
            ]:
                if risk_level is not None:
                    rep_level = rep_level if rep_level is not None else 1  # Treat None as 1
                    if rep_level - int(risk_level) == 2:  # Overqualified by 2 levels
                        score *= 0.5
                    elif rep_level - int(risk_level) == 1:  # Overqualified by 1 level
                        score *= 0.75
                    elif int(risk_level) - rep_level == 1:  # Underqualified by 1 level
                        score *= 0.7
            return score
        except Exception as e:
            print(f"[ERROR] Error in scoring risk level: {e} {task}")
            return 0.0

    def score_due_date(self, due_date, task_source) -> float:
        from_date = datetime.strptime(SOURCES[task_source]["FROM_DATE"], "%Y/%m/%d").date()
        to_date = datetime.strptime(SOURCES[task_source]["TO_DATE"], "%Y/%m/%d").date()

        total_days = (to_date - from_date).days
        remaining_days = (to_date - due_date).days
        return remaining_days / total_days
        


    def score_agency(self, familiar_agencies, agency_code) -> float:
        if len(familiar_agencies) == 0:
            return 1.0
        if agency_code in familiar_agencies:
            return 1.0
        else:
            return 0.0
    
    def score_task_count(self, rep: Rep) -> float:
        max_task = MAX_TASK_PER_REP_KA if rep.key_account else MAX_TASK_PER_REP
        task_to_fill_percent = (max_task - rep.current_task_count) / max_task if max_task > 0 else 0
        return task_to_fill_percent

    def normalize_weights(self, distance_weight, risk_level_weight, due_date_weight, agency_weight, balance_weight) -> Tuple[float, float, float, float]:
        total_weight = distance_weight + risk_level_weight + due_date_weight + agency_weight + balance_weight
        if total_weight == 0:
            return 0, 0, 0, 0, 0
        return (distance_weight / total_weight), (risk_level_weight / total_weight), (due_date_weight / total_weight), (agency_weight / total_weight), (balance_weight / total_weight)