# Loss Control Workflow Automation

## Project Overview
This project aims to automate the manual task assignment workflow for the Loss Control department. As the starting point, we will be specifically focusing on CLD Matrix. Currently, tasks from CLD Matrix are updated roughly every two months and must be manually reviewed and assigned by RTDs (Regional Territory Directors) using an Excel dashboard, and then upload the assignments to RCT.

The long-term vision is to develop a robust, extensible automation engine that:
- Ingests task data from multiple evolving sources
- For reps who needs new tasks, asign most suitable tasks from the task pool
- Outputs structured assignment results ready for downstream systems (e.g., RCT)

---

## Inputs
1. **Tasks from Different Sources**
   - Currently, we only have CLD Matrix Package and CLD Matrix WC (treated as two individual sources).
   - In the future, the format of the task sources can vary significantly. We pull CLD Matrix data through SQL Server, but other tasks might be in Excel format or even in emails. The code design supports different implementations to load various task sources.

2. **Rep Information**
   - It is currently a CSV file downloaded from [LC Staff Track](https://cinfin.sharepoint.com/sites/LossControl/Lists/New%20LC%20Staff%20Track/Contact%20Info.aspx?viewid=d06a1656%2Dbfb1%2D4939%2D9275%2Da617a29bb8ba&isSPOFile=1&ovuser=0f087cc2%2Dbc5d%2D40bf%2D8db4%2D41f99d0d1619%2CYuchen%5FWang%40cinfin%2Ecom&OR=Teams%2DHL&CT=1746027584103&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiI0OS8yNTA0MDMxOTExMyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D).
   - It contains rep information like employee ID, location, email, skill levels, etc.

3. **Rep Task Count Information**
   - A CSV file provided by Ian Baker. In the future, we might be able to pull this information from Snowflake in real-time.
   - Contains rep-count pairs to show the length of the current rep queue for each rep.

## Additional Data
1. **Region Information**
   - A county-region conversion CSV file.

2. **Agency Information**
   - Pulled from a SQL Server that contains agency-rep matching for generating familiar agencies for each rep.

3. **Zip Information** 
   - Zip-to-latitude/longitude conversion for distance computation.
   
## Workflow
1. **Load Data from Different Sources into One Task Pool**
   - Only load task sources that we want to include in this run.
   - Filter the task sources (we only want the tasks that are between lookahead days and (lookahead days + due date windows) days from today; and have not been inspected in the last 900 days).
   - Get all the information we need; some require extra computation or additional data files (region, latitude, longitude, etc.).
   - Convert the tasks to a uniform format.
   - Combine the tasks from all sources into one task pool.

2. **Load the Rep Information**
   - Load information from all related data files and format it as designed.

3. **Run Score Algorithm on Each Rep-Task Pair**
   - First, check whether the rep-task pair satisfies the hard requirements. If any hard requirement is not satisfied, the score will return -1, and this pair will not be assigned in any situation.
      * Rep and task must be in the same region.
      * Rep level cannot be underqualified by two levels (rep level 1 working on risk level 3 is disallowed).
   - If the pair passes the hard requirement check, score them based on the weighted average of four sub-scores:
      * Distance Score (only for on-site tasks): Prefer reps located close to the task.
      * Risk Level Score: Prefer rep level and risk level to be as close as possible.
      * Due Date Score: Tasks that are due sooner receive a higher score.
      * Agency Score: Prefer reps with familiarity with the agency.

4. **Assign the Tasks Based on the Score**
   - Two strategies are implemented: vanilla and round-robin.
   - There are many possible strategies (e.g., first assign to the rep with the fewest tasks, etc.), and we can add more strategies based on business needs.

## Scoring Algorithm
The scoring algorithms should return a float from 0 to 1 (mostly).

1. **Score Distance**

   ![alt text](image.png)

2. **Score Risk Level**

   For all the risk levels that are not none:
   - Overqualified by 1 level: score *= 0.75
   - Overqualified by 2 levels: score *= 0.5
   - Underqualified by 1 level: score *= 0.7

3. **Score Due Date**

   - For tasks due in LOOKAHEAD days, return 2 (very urgent).
   - For other tasks, the score decreases linearly, and tasks due in LOOKAHEAD_DAYS+DUE_DATE_WINDOW from today have a score of 0.

4. **Score Agency**

   - If the task agency is familiar to the rep, return 1; otherwise, return 0.

We need business insight to modify/design better scoring algorithms.

## Configurable Parameters
- LOOKAHEAD_DAYS (60): Only include the tasks that due date after LOOKAHEAD_DAYS from today.
- DUE_DATE_WINDOW (60): 
- MAX_TASK_PER_REP (20): Try to assign up to MAX_TASK_PER_REP tasks to each rep.
- ASSIGNMENT_LOWERBOUND (15): Only run the assignment engine on reps whose current task count is below ASSIGNMENT_LOWERBOUND.
- STRATEGY: The assignment strategy ["vanilla", "round-robin"].
- SCORING_WEIGHTS: The weight of each sub-score. The engine normalizes the weights to ensure they add up to 1. For virtual tasks, the engine automatically sets the distance weight to 0.

   Example:

   ```python
   SCORING_WEIGHTS = {
      "distance": 0.5,
      "risk_level": 0.3,
      "due_date": 0.15,
      "agency": 0.05
   }
   ```

## UX Design

Although not implemented yet, we think a frontend is needed to allow users to select configuration options.

## Caveats
1. **The current system does not know which tasks are assigned in RCT but not yet finished.**
   - Ensure that the lookahead days align with the engine's running cadence.
   - To enable the engine to run at any cadence, we need information about which locations are assigned in RCT but have not yet been inspected.

2. **Distance Consideration for Virtual Tasks**
   - Currently, distance is not considered for virtual tasks.
   - Implementing this change should be relatively straightforward if needed.

