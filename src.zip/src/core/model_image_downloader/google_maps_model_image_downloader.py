from core.model_image_downloader.base_model_image_downloader import BaseModelImageDownloader
from config import MODEL_IMAGE_DIR
import os
import requests
from PIL import Image
import numpy as np
import rasterio
from rasterio.transform import from_origin
import logging
from dotenv import load_dotenv

load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class GoogleMapsModelImageDownloader(BaseModelImageDownloader):
    def __init__(self):
        self.directories = [f"{MODEL_IMAGE_DIR}/google_maps"]
        super().__init__()

    def run(self, lat: float, lon: float, zoom: int = 19, size: int = 768) -> str:
        output_dir = f"{MODEL_IMAGE_DIR}/google_maps"

        filename = f"{lat}_{lon}_z{zoom}_{size}x{size}.tif"
        output_path = os.path.join(output_dir, filename)

        if os.path.exists(output_path):
            return output_path

        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")

        params = {
            'center': f"{lat},{lon}",
            'zoom': zoom,
            'size': f"{size}x{size}",
            'scale': 1,
            'maptype': 'satellite',
            'key': api_key,
            'format': 'png'
        }

        response = requests.get("https://maps.googleapis.com/maps/api/staticmap", params=params, timeout=30)
        response.raise_for_status()

        temp_png_path = os.path.join(output_dir, f"temp_{lat}_{lon}.png")
        with open(temp_png_path, 'wb') as f:
            f.write(response.content)

        img = Image.open(temp_png_path).convert("RGB")
        img_np = np.array(img)

        height, width, channels = img_np.shape

        pixel_size = self.zoom_to_pixel_size(zoom)
        transform = from_origin(lon, lat, pixel_size, pixel_size)

        with rasterio.open(
            output_path,
            'w',
            driver='GTiff',
            height=height,
            width=width,
            count=3,
            dtype=img_np.dtype,
            transform=transform
        ) as dst:
            for i in range(3):
                dst.write(img_np[:, :, i], i + 1)

        os.remove(temp_png_path)
        return output_path

    def zoom_to_pixel_size(self, zoom_level):
        """
        Convert Google Maps zoom level to approximate pixel size in degrees.
        Assumes Web Mercator projection and 256 pixels per tile.
        """
        initial_resolution = 360 / 256  # degrees per pixel at zoom level 0
        resolution = initial_resolution / (2 ** zoom_level)
        return resolution
