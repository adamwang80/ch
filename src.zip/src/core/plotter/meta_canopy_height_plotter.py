from core.plotter.base_plotter import BasePlotter
import os
import logging
from config import CANOPY_HEIGHT_IMAGE_DIR, CHM_LOCAL_CROP_FILES_DIR, VisualizationConfig, DataProcessingConfig
import matplotlib.pyplot as plt
from typing import List, Tuple, Optional, Dict, Any
import rasterio
from PIL import Image
import numpy as np
from shapely.geometry import box
from pyproj import Transformer
from rasterio.merge import merge

logger = logging.getLogger(__name__)

class MetaCanopyHeightPlotter(BasePlotter):

    def __init__(self):
        pass

    def run(self, bounding_box: list, method: str,  cropfile: str = None) -> None:
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        title = f"{bbox_filename}"
        output_dir = f"{CANOPY_HEIGHT_IMAGE_DIR}/{method}"
        
        if method == "chm":
            cropfile = f"{CHM_LOCAL_CROP_FILES_DIR}/{bbox_filename}_crop.tif"

        # Ensure the output directory exists
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
            logger.info(f"Created directory: {output_dir}")

        self.plot_canopy_height(cropfile, title, output_dir)
    
    def mercator_to_latlon_ax(self, ax: plt.Axes, dec: int = 2) -> None:
        """Convert Mercator coordinates to lat/lon for axis labels"""
        xt = ax.get_xticks()
        yt = ax.get_yticks()
        trans = Transformer.from_proj(DataProcessingConfig.MERCATOR_CRS, DataProcessingConfig.DEFAULT_CRS)
        # can do this because 3857 has parallel lat and lon
        zlon = [yt[0] for _ in range(len(xt))]
        zlat = [xt[0] for _ in range(len(yt))]
        _, lon = trans.transform(xt, zlon)
        lat, _ = trans.transform(zlat, yt)
        lons = []
        for l in lon:
            if l < 0:
                hem = 'W'
            else:
                hem = 'E'
            lons.append(f"{np.abs(np.round(l, dec))}{chr(176)}{hem}")
        lats = []
        for l in lat:
            if l < 0:
                hem = 'S'
            else:
                hem = 'N'
            lats.append(f"{np.abs(np.round(l, dec))}{chr(176)}{hem}")

        ax.set_yticklabels(lats, fontsize=18, fontweight="bold")
        ax.set_xticklabels(lons, fontsize=18, fontweight="bold")
        ax.yaxis.set_tick_params(rotation=90)

    def geojson_to_poly(self, geojson: Dict[str, Any]) -> Any:
        """
        Given a geojson with a polygon shape,
        return the shapely object
        """
        if len(geojson["features"]) > 1:
            poly = GeometryCollection(
                [shape(feature["geometry"]).buffer(0) for feature in geojson["features"]]
            )
        else:
            f = geojson["features"][0]
            poly = shape(f["geometry"]).buffer(0)
        if poly.geom_type != "Polygon":
            pps = []
            for pp in poly.geoms:
                pp = polygon.orient(pp)  # correct winding
                pps.append(pp)
            out_geom = MultiPolygon(pps)
        else:
            out_geom = polygon.orient(poly)  # correct winding
        return out_geom

    def plot_canopy_height(
        self, 
        cropfile: str, 
        title: str, 
        output_dir: str, 
        dpi: int = None
    ) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot canopy height data from a cropped raster file
        
        Parameters:
        -----------
        cropfile : str
            Path to the cropped raster file
        title : str
            Title for the plot and output filename
        output_dir : str
            Directory to save the output image
        dpi : int
            Resolution for the output image
        """
        if dpi is None:
            dpi = VisualizationConfig.DPI
            
        with rasterio.open(cropfile) as src:
            data = src.read().squeeze()
            bounds = src.bounds
            width = src.width
            height = src.height

        factor = 1
        new_width = int(width/factor)
        new_height = int(height/factor)
        xx = Image.fromarray(data).resize(
            (new_width, new_height), Image.BICUBIC
        )
        chm = np.array(xx).astype('float')
        # set nodata (with interp fuzziness)
        chm[chm > VisualizationConfig.CANOPY_NODATA_THRESHOLD] = np.nan
        
        fig, ax = plt.subplots(1, 1, figsize=[14, 10])
        bbox = box(*bounds)
        extent = (bbox.bounds[0], bbox.bounds[2], bbox.bounds[1], bbox.bounds[3])
        colors = ax.imshow(chm, vmax=np.nanpercentile(chm, 99.5), extent=extent)
        tt = ax.get_xticks()[1:-1]
        ax.set_xticks(tt[::3])
        tt = ax.get_yticks()[1:-1]
        ax.set_yticks(tt[::3])
        self.mercator_to_latlon_ax(ax, dec=2)
        cax = plt.gca().inset_axes([1.05, 0.3, 0.03, 0.4])
        plt.colorbar(colors, cax=cax, label='canopy height [meters]')
        ax.set_title(title)
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        plt.savefig(f'{output_dir}/{title}.png', dpi=dpi, bbox_inches='tight')
        plt.close()  # Close the figure to free memory
        
        logger.info(f"Saved canopy height plot: {output_dir}/{title}.png")
        return fig, ax
        
