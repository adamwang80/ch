from abc import ABC, abstractmethod
import logging
import os
import numpy as np
from config import VisualizationConfig


logger = logging.getLogger(__name__)

class BasePlotter(ABC):
    """
    Abstract base class for all methods.
    """

    @abstractmethod
    def __init__(self, *args, **kwargs):
        self._ensure_directories()

    @abstractmethod
    def run(self, *args, **kwargs):
        pass
    
    def _ensure_directories(self) -> None:
        if self.directories:        
            for directory in self.directories:
                if not os.path.exists(directory):
                    os.makedirs(directory, exist_ok=True)
                    logger.info(f"Created directory: {directory}")
    
    def clean_canopy_data(self, data: np.ndarray, threshold: float = None) -> np.ndarray:
        """Clean canopy height data by removing invalid values"""
        if threshold is None:
            threshold = VisualizationConfig.CANOPY_NODATA_THRESHOLD
        
        # Remove negative values
        data = np.where(data < 0, 0, data)
        # Set values above threshold to NaN
        data = np.where(data > threshold, np.nan, data)
        return data

