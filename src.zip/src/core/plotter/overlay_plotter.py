from core.plotter.base_plotter import BasePlotter
import numpy as np
from PIL import Image
import rasterio
from matplotlib import cm
from matplotlib.colors import Normalize
import matplotlib.pyplot as plt
import os
from matplotlib.gridspec import GridSpec
import logging
from typing import List, Tuple, Optional, Union
from config import VisualizationConfig, DataProcessingConfig, BUILDING_IMAGE_DIR, CANOPY_HEIGHT_IMAGE_DIR, CHM_LOCAL_CROP_FILES_DIR, ARTIFACTS_DIR, OVERLAY_IMAGE_DIR

# Set up logging
logger = logging.getLogger(__name__)

class OverlayPlotter(BasePlotter):

    def __init__(self):
        self.directories = [
            OVERLAY_IMAGE_DIR
        ]
        super().__init__()

    def run(self, bounding_box: list, method: str, building_image_source:str, canopy_threshold: float = None, alpha: float = None) -> None:
        """
        Create overlay image combining satellite image with canopy height data
        
        Args:
            canopy_threshold: Minimum canopy height to display
            alpha: Transparency level for overlay (0-1)
        
        Returns:
            Path to the created overlay image
        """
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        satellite_image_file = f"{BUILDING_IMAGE_DIR}/{building_image_source}/{bbox_filename}.png"
        output_file = f"{OVERLAY_IMAGE_DIR}/{method}_{building_image_source}_{bbox_filename}_overlay.png"

        canopy_height_file = f"{ARTIFACTS_DIR}/{method}/crop_files/{bbox_filename}_crop.tif"

        if canopy_threshold is None:
            canopy_threshold = VisualizationConfig.DEFAULT_CANOPY_THRESHOLD
        if alpha is None:
            alpha = VisualizationConfig.DEFAULT_ALPHA

        logger.info(f"Creating overlay image: {output_file}")

        # Read satellite image - keep original quality
        satellite_img = Image.open(satellite_image_file)
        satellite_img = satellite_img.convert('RGB')

        # Read canopy height and convert to image
        with rasterio.open(canopy_height_file) as src:
            canopy_data = src.read(1)

        # Clean and process canopy data
        canopy_data = self.clean_canopy_data(canopy_data)
        canopy_normalized = self.normalize_canopy_data(canopy_data)

        # Apply threshold - only show areas above threshold
        tree_mask = canopy_data >= canopy_threshold
        canopy_normalized = np.where(tree_mask, canopy_normalized, 0)

        # Replace NaNs with 0 for visualization
        canopy_normalized = np.nan_to_num(canopy_normalized, nan=0).astype(np.uint8)

        # Create colored canopy image
        canopy_colored = self.create_canopy_colored_image(canopy_normalized)
        canopy_img = Image.fromarray(canopy_colored, mode='RGB')

        # Resize canopy to match satellite (don't resize satellite!)
        if canopy_img.size != satellite_img.size:
            canopy_img = canopy_img.resize(satellite_img.size, Image.Resampling.LANCZOS)

        # Create overlay
        overlay_img = Image.blend(satellite_img, canopy_img, alpha)

        # Ensure output directory exists
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Save with configured quality
        overlay_img.save(output_file, 'PNG', quality=VisualizationConfig.IMAGE_QUALITY)

        logger.info(f"Overlay image saved: {output_file}")
        return output_file

    def normalize_canopy_data(self, data: np.ndarray) -> np.ndarray:
        """Normalize canopy data to 0-255 range"""
        canopy_max = np.nanmax(data)
        if canopy_max > 0:
            return (data / canopy_max * 255)
        return data

    def create_canopy_colored_image(self, canopy_normalized: np.ndarray) -> np.ndarray:
        """Create colored canopy image using configured color"""
        canopy_height, canopy_width = canopy_normalized.shape
        canopy_colored = np.zeros((canopy_height, canopy_width, 3), dtype=np.uint8)
        
        # Set color channels based on configuration
        canopy_colored[:, :, 0] = canopy_normalized  # Red channel
        canopy_colored[:, :, 1] = 0  # Green channel
        canopy_colored[:, :, 2] = 0  # Blue channel
        
        return canopy_colored

    