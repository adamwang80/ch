import logging
from core.methods.chm_method import CHMMethodEngine
from core.building_image_downloader.google_downloader import GoogleImageDownloader
from core.plotter.meta_canopy_height_plotter import MetaCanopyHeightPlotter
from core.plotter.overlay_plotter import OverlayPlotter
from core.plotter.side_by_side_plotter import SideBySidePlotter
from core.methods.model_method import ModelMethodEngine

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    try:
        bounding_box = [39.3019021038481, -84.50299808277721, 39.301077957033286, -84.50198095909357]

        engine = ModelMethodEngine()
        engine.run(bounding_box)

        # logger.info(f"Processing bounding box: {bounding_box}")
        # engine = CHMMethodEngine()

        # # Get canopy height data
        # logger.info("Getting canopy height data...")
        # engine.run(bounding_box, data_source="aws")

        # building_downloader = GoogleImageDownloader()
        # building_downloader.run(bounding_box, overwrite=True)

        # canopy_height_plotter = MetaCanopyHeightPlotter()
        # canopy_height_plotter.run(
        #     bounding_box=bounding_box,
        #     method="chm"
        # )

        # overlay_plotter = OverlayPlotter()
        # overlay_plotter.run(
        #     bounding_box=bounding_box,
        #     method="chm",
        #     building_image_source=f"google_maps"
        # )

        # side_by_side_plotter = SideBySidePlotter()
        # side_by_side_plotter.run(
        #     bounding_box=bounding_box,
        #     method="chm",
        #     building_image_source=f"google_maps"
        # )

    except Exception as e:
        logger.error(f"Error in main processing: {e}")
        raise

if __name__ == "__main__":
    main()