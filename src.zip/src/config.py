from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Artifact Directory
ARTIFACTS_DIR = f"{PROJECT_ROOT}/data/artifacts"

# CHM Method Configuration
CHM_METHOD_ARTIFACTS_DIR = f"{ARTIFACTS_DIR}/chm"

LOCAL_TILES_DATA_PATH = f"{CHM_METHOD_ARTIFACTS_DIR}/tiles.geojson"
TARGET_PLOY_FILE_DIR = f"{CHM_METHOD_ARTIFACTS_DIR}/target_polyfiles"
LOCAL_CHM_DIR = f"{CHM_METHOD_ARTIFACTS_DIR}/chm"
CHM_LOCAL_CROP_FILES_DIR = f"{CHM_METHOD_ARTIFACTS_DIR}/crop_files"
LOCAL_TIF_DIR= "/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/chm"
LOCAL_MSK_DIR= "/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/msk"
LOCAL_META_DIR= "/home/azureuser/cloudfiles/code/Users/Ruixu_Liu/GEDI/data/metadata"

S3_CHM_PATH = "forests/v1/alsgedi_global_v6_float/chm"
S3_MSK_PATH = "forests/v1/alsgedi_global_v6_float/msk"
S3_META_PATH = "forests/v1/alsgedi_global_v6_float/metadata"
S3_TILE_DATA_PATH = "forests/v1/alsgedi_global_v6_float/tiles.geojson"
S3_BUCKET = "dataforgood-fb-data"

S3_MAX_RETRIES = 3
S3_RETRY_DELAY = 1  # seconds

class DataProcessingConfig:
    """Configuration class for data processing settings"""
    # Raster processing
    DEFAULT_NODATA = 255
    COMPRESSION = "DEFLATE"
    BIGTIFF = 'YES'
    
    # Coordinate systems
    DEFAULT_CRS = 'EPSG:4326'
    MERCATOR_CRS = 'EPSG:3857'
    
    # File naming
    TILE_SEPARATOR = '_'
    COORD_SEPARATOR = '_'

# Building Image Downloader Configs
BUILDING_IMAGE_DIR = f"{PROJECT_ROOT}/data/images/building"
GOOGLE_MAPS_IMAGE_DIR = f"{PROJECT_ROOT}/data/images/building/google_maps"

class VisualizationConfig:
    """Configuration class for visualization settings"""
    # Color settings
    CANOPY_COLOR = [255, 0, 0]  # Red color for canopy overlay
    CANOPY_COLORMAP = 'viridis'  # Colormap for side-by-side visualization
    
    # Image quality settings
    IMAGE_QUALITY = 95
    DPI = 300
    FIGURE_SIZE = (14, 7)
    
    # Data processing thresholds
    CANOPY_NODATA_THRESHOLD = 200
    CANOPY_MIN_THRESHOLD = 0
    
    # Overlay settings
    DEFAULT_ALPHA = 0.3
    DEFAULT_CANOPY_THRESHOLD = 0
    
    # Google Maps API settings
    GOOGLE_MAPS_IMAGE_SIZE = '4096x4096'
    GOOGLE_MAPS_MAPTYPE = 'satellite'
    GOOGLE_MAPS_FORMAT = 'png'
    REQUEST_TIMEOUT = 30
    
    # Zoom level thresholds
    ZOOM_LEVELS = {
        'large': (0.1, 10),      # max_diff > 0.1
        'medium': (0.01, 15),    # max_diff > 0.01
        'small': (0.001, 18),    # max_diff > 0.001
        'precise': (0, 20)       # max_diff <= 0.001
    }

# Canopy Height Image Directory
CANOPY_HEIGHT_IMAGE_DIR = f"{PROJECT_ROOT}/data/images/canopy_height"

# Overlay Plotter Configs
OVERLAY_IMAGE_DIR = f"{PROJECT_ROOT}/data/images/overlay"

# Side-by-Side Plotter Configs
SIDE_BY_SIDE_IMAGE_DIR = f"{PROJECT_ROOT}/data/images/side_by_side"

# Model Method Configurations
MODEL_METHOD_ARTIFACTS_DIR = f"{ARTIFACTS_DIR}/model"

MODEL_ID = "compressed_SSLhuge_aerial" # ["compressed_SSLhuge", "compressed_SSLhuge_aerial", "compressed_SSLlarge", "SSLhuge_satellite"]
S3_MODEL_BUCKET = "dataforgood-fb-data"
LOCAL_MODEL_DIR = f"{MODEL_METHOD_ARTIFACTS_DIR}/models"
S3_MODEL_DIR = "forests/v1/models/saved_checkpoints"

MODEL_IMAGE_DIR = f"{MODEL_METHOD_ARTIFACTS_DIR}/model_images"

MODEL_OUTPUT_DIR = f"{MODEL_METHOD_ARTIFACTS_DIR}/model_outputs"

MODEL_SIDE_BY_SIDE_IMAGE_DIR = f"{MODEL_METHOD_ARTIFACTS_DIR}/side_by_side_results"