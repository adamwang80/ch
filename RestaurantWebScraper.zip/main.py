import pandas as pd
from AgencyWebScraper import AgencyWebScraper
import asyncio

df = pd.read_csv(r'C:\Users\YWANG1\OneDrive - The Cincinnati Insurance Company\Workspace\WebScraping\MVP_Webscraping_Websites(Sheet1).csv', header=1)
url_list = df['URL'].tolist()
# url_list = ['https://frostins.com/']

agency_scraper = AgencyWebScraper(url_list)
asyncio.run(agency_scraper.run())