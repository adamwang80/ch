import asyncio
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, BrowserConfig, LLMConfig
from crawl4ai.deep_crawling import BestFirstCrawlingStrategy
from crawl4ai.extraction_strategy import LLMExtractionStrategy
from crawl4ai.content_filter_strategy import PruningContentFilter
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator
from crawl4ai.deep_crawling.scorers import KeywordRelevanceScorer
from PyPDF2 import PdfMerger
import os
import litellm
from pydantic import BaseModel
from crawl4ai.deep_crawling.filters import (
    FilterChain,
    URLPatternFilter,
)

class ExtractedInfo(BaseModel):
    page_url: str
    page_title: str
    page_summary: str

#litellm._turn_on_debug()
async def run_advanced_crawler():
    llm_strategy = LLMExtractionStrategy(
        llm_config = LLMConfig(provider="azure/gpt-4o-mini", api_token=os.getenv('AZURE_API_KEY'), base_url= os.getenv('AZURE_API_BASE')),
        schema=ExtractedInfo.model_json_schema(), # Or use model_json_schema()
        extraction_type="schema",
        instruction="Get the important information.",
        chunk_token_threshold=3000,
        overlap_rate=0.0,
        apply_chunking=False,
        input_format="fit_markdown",   # or "html", "fit_markdown"
    )

    prune_filter = PruningContentFilter(
        # Lower → more content retained, higher → more content pruned
        threshold=0.45,           
        # "fixed" or "dynamic"
        threshold_type="dynamic",  
        # Ignore nodes with <5 words
        min_word_threshold=5      
    )

    # Create a sophisticated filter chain
    filter_chain = FilterChain([
        # URL patterns to include
        URLPatternFilter(patterns=["*career*", "*contact*", "*quote*", "*review*", "*claim*"], reverse=True),
    ])

    keyword_scorer = KeywordRelevanceScorer(
        keywords=["agency", "agent", "about", "insurance", "business", "financial", "health", "personal", "life", "auto", "commercial"],
        weight=0.7  # Importance of this scorer (0.0 to 1.0)
    )

    md_generator = DefaultMarkdownGenerator(content_filter=prune_filter)   

    # Set up the configuration
    config = CrawlerRunConfig(
        deep_crawl_strategy=BestFirstCrawlingStrategy(
            max_depth=2,
            include_external=False,
            filter_chain=filter_chain,
            url_scorer=keyword_scorer,
            max_pages=10
        ),
        stream=True,
        pdf=True,
        # verbose=True
        # extraction_strategy=llm_strategy,  # Use the LLM extraction strategy
        excluded_tags=["footer"],
        remove_overlay_elements=True,
        # exclude_external_links=True,
        # exclude_social_media_links=True,
        markdown_generator=md_generator,  # Use the Markdown generation strategy
    )

    browser_config = BrowserConfig(
        headless=False
    )

    # Execute the crawl
    results = []
    url = 'https://frostins.com/'
    async with AsyncWebCrawler(config=browser_config) as crawler:
        async for result in await crawler.arun(url, config=config):
            results.append(result)
    
    # Save the Markdown representation of each result into a single Markdown file
    url_identifier = url.replace("http://", "").replace("https://", "").replace("/", "_").replace(".", "_")
    markdown_filename = f"crawled_results_{url_identifier}.md"
    with open(markdown_filename, "w", encoding="utf-8") as markdown_file:
        for result in results:
            markdown_content = result.markdown
            markdown_file.write(markdown_content + "\n\n")
    print(f"Markdown results saved to '{markdown_filename}'")

    fit_markdown_filename = f"fit_crawled_results_{url_identifier}.md"
    with open(fit_markdown_filename, "w", encoding="utf-8") as markdown_file:
        for result in results:
            markdown_content = result.markdown.fit_markdown
            markdown_file.write(markdown_content + "\n\n")
    print(f"Fit Markdown results saved to '{fit_markdown_filename}'")

    # # Save the PDF representation of each result into individual PDF files
    # pdf_merger = PdfMerger()
    # pdf_paths = []
    # for i, result in enumerate(results):
    #     pdf_path = f"result_{i + 1}.pdf"
    #     with open(pdf_path, "wb") as pdf_file:
    #         pdf_file.write(result.pdf)
    #     pdf_merger.append(pdf_path)
    #     pdf_paths.append(pdf_path)

    # # Combine all individual PDFs into a single PDF file
    # combined_pdf_path = "combined_results.pdf"
    # pdf_merger.write(combined_pdf_path)
    # pdf_merger.close()
    # print(f"PDF results saved to '{combined_pdf_path}'")

    # # Delete the individual PDF files
    # for pdf_path in pdf_paths:
    #     os.remove(pdf_path)
    # print("Individual PDF files deleted.")


    # with open("output.txt", "w", encoding="utf-8") as output_file:
    #     for result in results:
    #         if result.success:
    #             data = result.extracted_content
    #             output_file.write(str(data) + "\n\n")
    # print("Extracted content saved to 'output.txt'")

    


if __name__ == "__main__":
    asyncio.run(run_advanced_crawler())
