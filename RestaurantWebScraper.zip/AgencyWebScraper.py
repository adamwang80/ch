import asyncio
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, BrowserConfig, LLMConfig
from crawl4ai.deep_crawling import BestFirstCrawlingStrategy
from crawl4ai.extraction_strategy import LLMExtractionStrategy
from crawl4ai.content_filter_strategy import PruningContentFilter
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator
from crawl4ai.deep_crawling.scorers import KeywordRelevanceScorer
from PyPDF2 import PdfMerger
import os
import litellm
from pydantic import BaseModel
from crawl4ai.deep_crawling.filters import (
    FilterChain,
    URLPatternFilter,
)
import aiohttp
from urllib.robotparser import RobotFileParser
from urllib.parse import urlparse, urljoin

class ExtractedInfo(BaseModel):
    page_url: str
    page_title: str
    page_summary: str

class AgencyWebScraper:
    def __init__(self, url_list, save_markdown=True, save_pdf=False):
        self.url_list = url_list
        self.save_markdown = save_markdown
        self.save_pdf = save_pdf
    
    async def run_advanced_crawler(self, url):

        browser_config = BrowserConfig(
            headless=False
        )

        llm_strategy = LLMExtractionStrategy(
            llm_config = LLMConfig(provider="azure/gpt-4o-mini", api_token=os.getenv('AZURE_API_KEY'), base_url= os.getenv('AZURE_API_BASE')),
            schema=ExtractedInfo.model_json_schema(), # Or use model_json_schema()
            extraction_type="schema",
            instruction="Get the important information.",
            chunk_token_threshold=3000,
            overlap_rate=0.0,
            apply_chunking=False,
            input_format="fit_markdown",   # or "html", "fit_markdown"
        )

        prune_filter = PruningContentFilter(
            # Lower → more content retained, higher → more content pruned
            threshold=0.45,           
            # "fixed" or "dynamic"
            threshold_type="dynamic",  
            # Ignore nodes with <5 words
            min_word_threshold=5      
        )

        # Create a sophisticated filter chain
        filter_chain = FilterChain([
            URLPatternFilter(patterns=["*career*", "*contact*", "*quote*", "*review*", "*claim*", "*payment*"], reverse=True),
        ])

        keyword_scorer = KeywordRelevanceScorer(
            keywords=["agency", "agent", "about", "insurance", "business", "financial", "health", "personal", "life", "auto", "commercial"],
            weight=0.7  # Importance of this scorer (0.0 to 1.0)
        )

        md_generator = DefaultMarkdownGenerator(content_filter=prune_filter)   

        crawler_run_config = CrawlerRunConfig(
            deep_crawl_strategy=BestFirstCrawlingStrategy(
                max_depth=3,
                include_external=False,
                filter_chain=filter_chain,
                url_scorer=keyword_scorer,
                max_pages=10
            ),
            stream=True,
            pdf=True,
            # verbose=True
            # extraction_strategy=llm_strategy,  # Use the LLM extraction strategy
            excluded_tags=["footer"],
            remove_overlay_elements=True,
            # exclude_external_links=True,
            # exclude_social_media_links=True,
            markdown_generator=md_generator,  # Use the Markdown generation strategy
        )

        results = []
        url_crawled = []
        async with AsyncWebCrawler(config=browser_config) as crawler:
            print("Initialized AsyncWebCrawler with browser configuration.")
            async for result in await crawler.arun(url, config=crawler_run_config):
                print(f"Processing result from URL: {result.url}")
                if result.url not in url_crawled and result.markdown:
                    url_crawled.append(result.url)
                    results.append(result)
        print(f"Finished crawling. Total results: {len(results)}")
        return results

    async def crawl(self, url: str):
        """
        Checks robots.txt and runs the crawler if allowed.
        """
        is_allowed = await self.check_robots_txt(url)
        if not is_allowed:
            print(f"Crawling not allowed for {url} as per robots.txt.")
            return
        results = await self.run_advanced_crawler(url)
        
        if self.save_markdown:
            self.save_to_markdown(results, url)
        # if self.save_pdf:
        #     self.save_to_pdf(results)
    
    def save_to_markdown(self, results, url):
        print("test")
        # Save the Markdown representation of each result into a single Markdown file
        parsed_url = urlparse(url)
        print(parsed_url)
        url_identifier = parsed_url.netloc.split('.')[-2]
        markdown_filename = f"crawled_results_{url_identifier}.md"
        print(markdown_filename)
        os.makedirs(f"./result/{url_identifier}", exist_ok=True)
        with open(f"./result/{url_identifier}/{markdown_filename}", "w", encoding="utf-8") as markdown_file:
            for result in results:
                # Write result.url to each page
                markdown_file.write(f"URL: {result.url}\n\n")
                markdown_content = result.markdown
                if markdown_content:
                    markdown_file.write(markdown_content + "\n\n")
        print(f"Markdown results saved to '{markdown_filename}'")

        fit_markdown_filename = f"fit_crawled_results_{url_identifier}.md"
        with open(f"./result/{url_identifier}/{fit_markdown_filename}", "w", encoding="utf-8") as markdown_file:
            for result in results:
                markdown_file.write(f"URL: {result.url}\n\n")
                markdown_content = result.markdown.fit_markdown
                markdown_file.write(markdown_content + "\n\n")
        print(f"Fit Markdown results saved to '{fit_markdown_filename}'")

        

    async def check_robots_txt(self, url: str) -> bool:
        """
        Checks if the given URL is allowed to be crawled based on robots.txt.
        """
        parsed_url = urlparse(url)
        robots_url = urljoin(f"{parsed_url.scheme}://{parsed_url.netloc}", "/robots.txt")

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(robots_url) as response:
                    if response.status != 200:
                        print(f"No robots.txt found at {robots_url}, assuming allowed.")
                        return True
                    robots_txt = await response.text()

            rp = RobotFileParser()
            rp.parse(robots_txt.splitlines())
            return rp.can_fetch("*", url)

        except Exception as e:
            print(f"Error checking robots.txt: {e}. Assuming allowed.")
            return True
        
    async def run(self):
        """
        Crawls each URL in the url_list.
        """
        for url in self.url_list:
            print(f"\nStarting crawl for: {url}")
            # try:
            await self.crawl(url)
            # except Exception as e:
            #     print(f"Error while crawling {url}: {e}")