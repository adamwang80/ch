TILE_DATA_PATH = "data/metadata/tiles.geojson"
LOCAL_CHM_DIR = "data/chm"
S3_CHM_PATH = 'forests/v1/alsgedi_global_v6_float/chm'
S3_MSK_PATH = 'forests/v1/alsgedi_global_v6_float/msk'
S3_META_PATH = 'forests/v1/alsgedi_global_v6_float/metadata'
S3_BUCKET = 'dataforgood-fb-data'
TARGET_PLOY_FILE_DIR = "data/target"
GOOGLE_MAPS_IMAGE_DIR = "data/images/building/google_maps_image"