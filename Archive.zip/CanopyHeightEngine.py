from config import TILE_DATA_PATH, LOCAL_CHM_DIR, S3_CHM_PATH, S3_MSK_PATH, S3_META_PATH, S3_BUCKET, TARGET_PLOY_FILE_DIR
from utils import bounding_box_to_geojson, enforce_mask, merge_rasters, crop_raster, plot_canopy_height
import geopandas as gp
import matplotlib.pyplot as plt
import os
import shutil
import boto3
from botocore import UNSIGNED
from botocore.config import Config
import json
import numpy as np
import rasterio
from PIL import Image
from shapely.geometry import box

class CanopyHeightEngine:
    def __init__(self):
        self.tiles = gp.read_file(TILE_DATA_PATH)
        # Set CRS to WGS84 (EPSG:4326) for tiles
        self.tiles = self.tiles.set_crs('EPSG:4326')
        self.local_dir = LOCAL_CHM_DIR
        self.s3chmpath = S3_CHM_PATH
        self.s3mskpath = S3_MSK_PATH
        self.s3metapath = S3_META_PATH
        self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
        self.bucket = S3_BUCKET
        self.target_polyfile_dir = TARGET_PLOY_FILE_DIR

    def get_canopy_height(self, bounding_box, method="chm", data_source="aws"):
        if method == "chm":
            return self.get_canopy_height_chm(bounding_box, data_source)
    
    def get_canopy_height_chm(self, bounding_box, data_source="aws"):
        cropfile = self.get_crop_file(bounding_box, data_source)
        
        # Generate plot
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        title = f"canopy_height_{bbox_filename}"
        plot_canopy_height(cropfile, title=title, output_dir='data')
        return cropfile
    
    
    def get_crop_file(self, bounding_box, data_source="aws"):
        """Process bounding box and return cropped file path"""
        tifs = []
        metas = []
        tile_numbers = []
        
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        target_polyfile = f"{self.target_polyfile_dir}/{bbox_filename}.geojson"
        
        if not os.path.exists(target_polyfile):
            os.makedirs(self.target_polyfile_dir, exist_ok=True)
            geojson = bounding_box_to_geojson(bounding_box)
            with open(target_polyfile, 'w') as f:
                json.dump(geojson, f)
        
        target = gp.read_file(target_polyfile)
        target = target.set_crs('EPSG:4326')
        target_tiles = gp.sjoin(self.tiles, target)
        
        if data_source == "aws":
            for ii, row in target_tiles.iterrows():
                tile_numbers.append(row.tile)

                # Download CHM
                s3file = f"{self.s3chmpath}/{row.tile}.tif"
                localfile = f"{self.local_dir}/{os.path.basename(s3file)}"
                if not os.path.exists(localfile):
                    self.s3_client.download_file(self.bucket, s3file, localfile)

                # Download cloud masks
                mskfile = f"{self.s3mskpath}/{row.tile}.tif.msk"
                localmskfile = f"{self.local_dir}/{os.path.basename(mskfile)}"
                if not os.path.exists(localmskfile):
                    self.s3_client.download_file(self.bucket, mskfile, localmskfile)

                # Download metadata
                jsonfile = f"{self.s3metapath}/{row.tile}.geojson"
                localjsonfile = f"{self.local_dir}/{os.path.basename(jsonfile)}"
                if not os.path.exists(localjsonfile):
                    self.s3_client.download_file(self.bucket, jsonfile, localjsonfile)
                metas.append(localjsonfile)
                    
                # Apply mask
                outfile = localfile.replace('.tif', 'masked.tif')
                if not os.path.exists(outfile):
                    enforce_mask(localfile, outfile)
                tifs.append(outfile)
        
        tile_numbers_str = '_'.join(tile_numbers)
        mergefile = f"{self.local_dir}/{tile_numbers_str}_alltiles.tif"
        if not os.path.exists(mergefile):
            merge_rasters(tifs, outfile=mergefile)
                
        # Use bounding box coordinates for crop file name
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        cropfile = f"{self.local_dir}/{bbox_filename}_crop.tif"
        if not os.path.exists(cropfile):
            crop_raster(mergefile, target_polyfile, cropfile)
        
        return cropfile