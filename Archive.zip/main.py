from CanopyHeightEngine import CanopyHeightEngine
from ImageDownloadEngine import ImageDownloadEngine
from utils import overlay_canopy_and_satellite

bounding_box = [39.30076705472572, -84.5023961988198, 39.30029432276294, -84.50183394864057]

engine = CanopyHeightEngine()
engine.get_canopy_height(bounding_box)

image_engine = ImageDownloadEngine()
image_engine.download_image(bounding_box)

bbox_filename = '_'.join([str(coord) for coord in bounding_box])
canopy_height_file = f"data/chm/{bbox_filename}_crop.tif"
satellite_image_file = f"data/images/building/google_maps_image/{bbox_filename}.png"
output_file = f"data/images/overlay/overlay_{bbox_filename}.png"

overlay_canopy_and_satellite(canopy_height_file, satellite_image_file, output_file)