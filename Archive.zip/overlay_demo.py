from utils import overlay_canopy_and_satellite
import os
import glob

def create_overlay(bounding_box, canopy_threshold=2.0, alpha=0.7):
    """Create overlay of canopy height and satellite image"""
    
    # File paths
    bbox_filename = '_'.join([str(coord) for coord in bounding_box])
    
    # Find canopy height crop file
    crop_files = glob.glob("data/chm/*_crop.tif")
    if not crop_files:
        print("No crop files found")
        return None
    canopy_height_data = crop_files[0]  # Use the first one found
    
    # Satellite image
    satellite_image = f"data/images/google_maps_image/{bbox_filename}.png"
    
    # Output file
    output_file = f"data/overlay_{bbox_filename}.png"
    
    # Check if files exist
    if not os.path.exists(canopy_height_data):
        print(f"Canopy height data not found: {canopy_height_data}")
        return None
        
    if not os.path.exists(satellite_image):
        print(f"Satellite image not found: {satellite_image}")
        return None
    
    print(f"Creating overlay...")
    print(f"Canopy data: {canopy_height_data}")
    print(f"Satellite image: {satellite_image}")
    print(f"Output: {output_file}")
    
    # Create overlay
    result = overlay_canopy_and_satellite(
        canopy_height_file=canopy_height_data,
        satellite_image_file=satellite_image,
        output_file=output_file,
        canopy_threshold=canopy_threshold,
        alpha=alpha
    )
    
    return result

if __name__ == "__main__":
    # Example usage
    bounding_box = [39.304083043961384, -84.49987615088783, 39.303768285158064, -84.49958991658588]
    result = create_overlay(bounding_box, canopy_threshold=2.0, alpha=0.7)
    if result:
        print(f"Success! Overlay created: {result}")
    else:
        print("Failed to create overlay") 