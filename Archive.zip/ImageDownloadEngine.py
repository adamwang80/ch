import os
import requests
from PIL import Image
from config import GOOGLE_MAPS_IMAGE_DIR
from dotenv import load_dotenv

load_dotenv()

class ImageDownloadEngine:
    def __init__(self):
        self.google_maps_image_dir = GOOGLE_MAPS_IMAGE_DIR
    
    def download_image(self, bounding_box, data_source="google_maps"):
        """Download satellite image using Google Static Maps API"""
        
        if data_source == "google_maps":
            return self.download_google_static_maps(bounding_box)
        else:
            raise ValueError(f"Unsupported data source: {data_source}")
    
    def download_google_static_maps(self, bounding_box):
        """Download and crop satellite image from Google Static Maps API"""
        lat1, lon1, lat2, lon2 = bounding_box
        center_lat = (lat1 + lat2) / 2
        center_lon = (lon1 + lon2) / 2
        
        # Calculate zoom level based on area size
        max_diff = max(abs(lat2 - lat1), abs(lon2 - lon1))
        if max_diff > 0.1:
            zoom = 10
        elif max_diff > 0.01:
            zoom = 15
        elif max_diff > 0.001:
            zoom = 18
        else:
            zoom = 20
        
        # Create filenames
        bbox_filename = '_'.join([str(coord) for coord in bounding_box])
        temp_filename = f"{self.google_maps_image_dir}/temp_{bbox_filename}.png"
        output_filename = f"{self.google_maps_image_dir}/{bbox_filename}.png"
        
        if os.path.exists(output_filename):
            return output_filename
        
        os.makedirs(self.google_maps_image_dir, exist_ok=True)
        
        api_key = os.getenv('GOOGLE_MAPS_API_KEY')
        if not api_key:
            raise ValueError("GOOGLE_MAPS_API_KEY not found in environment variables")
        
        # Request large image for cropping
        params = {
            'center': f"{center_lat},{center_lon}",
            'zoom': zoom,
            'size': '4096x4096',
            'maptype': 'satellite',
            'key': api_key,
            'format': 'png'
        }
        
        response = requests.get("https://maps.googleapis.com/maps/api/staticmap", 
                              params=params, timeout=30)
        response.raise_for_status()
        
        # Save original image
        with open(temp_filename, 'wb') as f:
            f.write(response.content)
        
        # Crop to exact bounding box
        img = Image.open(temp_filename)
        
        # Calculate pixel coordinates for cropping
        pixels_per_degree = 2 ** zoom * 256 / 360
        center_x = img.width // 2
        center_y = img.height // 2
        
        crop_width = int(abs(lon2 - lon1) * pixels_per_degree)
        crop_height = int(abs(lat2 - lat1) * pixels_per_degree)
        
        left = max(0, center_x - crop_width // 2)
        top = max(0, center_y - crop_height // 2)
        right = min(img.width, left + crop_width)
        bottom = min(img.height, top + crop_height)
        
        # Crop and save
        cropped_img = img.crop((left, top, right, bottom))
        cropped_img.save(output_filename, 'PNG', quality=95)
        
        # Clean up
        os.remove(temp_filename)
        
        return output_filename