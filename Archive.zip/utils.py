import json
import rasterio
from rasterio.merge import merge
import rasterio.mask
import geopandas as gp
import os
import numpy as np
from PIL import Image
from pyproj import Transformer
from shapely.geometry import GeometryCollection, MultiPolygon, shape, polygon
import matplotlib.pyplot as plt
from shapely.geometry import box

def bounding_box_to_geojson(bbox):
    """
    Convert a bounding box [lat1, lon1, lat2, lon2] to a GeoJSON Polygon.
    Assumes lat1/lon1 is one corner, lat2/lon2 is the opposite corner.
    """
    lat1, lon1, lat2, lon2 = bbox

    # Ensure correct ordering: south, west, north, east
    south = min(lat1, lat2)
    north = max(lat1, lat2)
    west = min(lon1, lon2)
    east = max(lon1, lon2)

    # Define the polygon coordinates (must be closed: first point == last point)
    coordinates = [[
        [west, south],
        [east, south],
        [east, north],
        [west, north],
        [west, south]
    ]]

    geojson = {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": coordinates
        },
        "properties": {}
    }

    return geojson

# a few raster functions

def merge_rasters(files, outfile: str = "test.tif") -> None:
    """
    Merge a list of geotiffs into one file
    """
    src_files_to_mosaic = []
    for fp in files:
        src = rasterio.open(fp)
        src_files_to_mosaic.append(src)

    crs = src.crs
    out_meta = src.meta.copy()
    mosaic, out_trans = merge(src_files_to_mosaic)

    # Update the metadata
    out_meta.update(
        {
            "driver": "GTiff",
            "height": mosaic.shape[1],
            "width": mosaic.shape[2],
            "transform": out_trans,
            "crs": crs,
        }
    )

    with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE", BIGTIFF='YES') as dest:
        dest.write(mosaic)

def crop_raster(rasterfile: str, aoifile:str, outfile: str = "test.tif", nodata=255):
    gdf_aoi=gp.read_file(aoifile)
    with rasterio.open(rasterfile) as src:
            out_meta = src.meta.copy()
            if not src.crs == gdf_aoi.crs:
                gdf_aoi=gdf_aoi.to_crs(src.crs)
            aoi=gdf_aoi.iloc[0].geometry
            im, trans = rasterio.mask.mask(
                src, [aoi], crop=True, nodata=nodata, all_touched=True
            )
            # Update the metadata
            out_meta.update(
            {
                "driver": "GTiff",
                "height": im.shape[1],
                "width": im.shape[2],
                "transform": trans,
                "crs": src.crs,
                "nodata": nodata,
            }
            )
    with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE", BIGTIFF='YES') as dest:
        dest.write(im)


def enforce_mask(file, outfile=None, nodata=255):
    if not outfile:
        outfile=file.replace('.tif', 'masked.tif')
    with rasterio.open(file) as src:
        mask=src.read_masks()
        data=src.read()
        #nodata has been assigned as 255 in the S3 .msk files
        data[mask==255]=nodata
        out_meta=src.meta
        out_meta.update(
            {"nodata":nodata}
        )
        with rasterio.open(outfile, "w", **out_meta, compress="DEFLATE") as dest:
            dest.write(data)
            
#a few functions for nice looking plots

def mercator_to_latlon_ax(ax, dec=2):
    xt=ax.get_xticks()
    yt=ax.get_yticks()
    trans = Transformer.from_proj("epsg:3857", "epsg:4326")
    #can do this because 3857 has parrallel lat and lon
    zlon=[yt[0] for _ in range(len(xt))]
    zlat=[xt[0] for _ in range(len(yt))]
    _,lon=trans.transform(xt, zlon)
    lat,_=trans.transform(zlat, yt)
    lons=[]
    for l in lon:
        if l<0:
            hem='W'
        else:
            hem='E'
        lons.append(f"{np.abs(np.round(l,dec))}{chr(176)}{hem}")
    lats=[]
    for l in lat:
        if l<0:
            hem='S'
        else:
            hem='N'
        lats.append(f"{np.abs(np.round(l,dec))}{chr(176)}{hem}")

    ax.set_yticklabels(lats, fontsize=18, fontweight="bold")
    ax.set_xticklabels(lons, fontsize=18, fontweight="bold")
    ax.yaxis.set_tick_params(rotation=90)

def geojson_to_poly(geojson):
    """
    Given a geojson with a polygon shape,
    return the shapely object
    """
    if len(geojson["features"]) > 1:
        poly = GeometryCollection(
            [shape(feature["geometry"]).buffer(0) for feature in geojson["features"]]
        )
    else:
        f = geojson["features"][0]
        poly = shape(f["geometry"]).buffer(0)
    if poly.geom_type != "Polygon":
        pps = []
        for pp in poly.geoms:
            pp = polygon.orient(pp)  # correct winding
            pps.append(pp)
        out_geom = MultiPolygon(pps)
    else:
        out_geom = polygon.orient(poly)  # correct winding
    return out_geom

def plot_canopy_height(cropfile, title='canopy_height', output_dir='data/images/canopy_height', dpi=300):
    """
    Plot canopy height data from a cropped raster file
    
    Parameters:
    -----------
    cropfile : str
        Path to the cropped raster file
    title : str
        Title for the plot and output filename
    output_dir : str
        Directory to save the output image
    dpi : int
        Resolution for the output image
    """
    with rasterio.open(cropfile) as src:
        data = src.read().squeeze()
        bounds = src.bounds
        width = src.width
        height = src.height

    factor = 1
    new_width = int(width/factor)
    new_height = int(height/factor)
    xx = Image.fromarray(data).resize(
        (new_width, new_height), Image.BICUBIC
    )
    chm = np.array(xx).astype('float')
    # set nodata (with interp fuzziness)
    chm[chm > 200] = np.nan
    
    fig, ax = plt.subplots(1, 1, figsize=[14, 10])
    bbox = box(*bounds)
    extent = (bbox.bounds[0], bbox.bounds[2], bbox.bounds[1], bbox.bounds[3])
    colors = ax.imshow(chm, vmax=np.nanpercentile(chm, 99.5), extent=extent)
    tt = ax.get_xticks()[1:-1]
    ax.set_xticks(tt[::3])
    tt = ax.get_yticks()[1:-1]
    ax.set_yticks(tt[::3])
    mercator_to_latlon_ax(ax, dec=2)
    cax = plt.gca().inset_axes([1.05, 0.3, 0.03, 0.4])
    plt.colorbar(colors, cax=cax, label='canopy height [meters]')
    ax.set_title(title)
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    plt.savefig(f'{output_dir}/{title}.png', dpi=dpi, bbox_inches='tight')
    plt.close()  # Close the figure to free memory
    
    return fig, ax

def overlay_canopy_and_satellite(canopy_height_file, satellite_image_file, output_file, 
                                canopy_threshold=0, alpha=0.3):
    """
    Simple PIL overlay: satellite + canopy height
    """
    import numpy as np
    from PIL import Image
    import rasterio
    
    # Read satellite image - keep original quality
    satellite_img = Image.open(satellite_image_file)
    satellite_img = satellite_img.convert('RGB')
    
    # Read canopy height and convert to image
    with rasterio.open(canopy_height_file) as src:
        canopy_data = src.read(1)
        canopy_data = np.where(canopy_data < 0, 0, canopy_data)
    
    # Normalize canopy data to 0-255
    canopy_max = np.max(canopy_data)
    if canopy_max > 0:
        canopy_normalized = (canopy_data / canopy_max * 255).astype(np.uint8)
    else:
        canopy_normalized = canopy_data.astype(np.uint8)
    
    # Apply threshold - only show areas above threshold
    tree_mask = canopy_data >= canopy_threshold
    canopy_normalized = np.where(tree_mask, canopy_normalized, 0)
    
    # Create colored canopy image (bright red for trees)
    canopy_height, canopy_width = canopy_normalized.shape
    canopy_colored = np.zeros((canopy_height, canopy_width, 3), dtype=np.uint8)
    
    # Set red color based on canopy height
    canopy_colored[:, :, 0] = canopy_normalized  # Red channel
    canopy_colored[:, :, 1] = 0  # Green channel (0 for red)
    canopy_colored[:, :, 2] = 0  # Blue channel (0 for red)
    
    # Create canopy image
    canopy_img = Image.fromarray(canopy_colored, mode='RGB')
    
    # Resize canopy to match satellite (don't resize satellite!)
    if canopy_img.size != satellite_img.size:
        canopy_img = canopy_img.resize(satellite_img.size, Image.Resampling.LANCZOS)
    
    # Create overlay
    overlay_img = Image.blend(satellite_img, canopy_img, alpha)
    
    # Save
    overlay_img.save(output_file, 'PNG', quality=95)
    
    print(f"Simple overlay saved: {output_file}")
    return output_file